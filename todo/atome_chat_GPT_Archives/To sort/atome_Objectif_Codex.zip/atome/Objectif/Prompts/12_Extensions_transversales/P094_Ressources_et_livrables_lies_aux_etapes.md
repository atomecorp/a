# P094 — Ressources et livrables liés aux étapes

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P093 — Réception finale du lot santé et remise utilisateur](../11_Recette_sante/P093_Reception_finale_du_lot_sante_et_remise_utilisateur.md)

## Mission et périmètre

- Relier fichiers, médias, objets atome et livrables aux étapes au moyen du Finder et des outils réels.
- Conserver source, droits, version et critères de validation d’une preuve sans créer un dépôt de fichiers concurrent.
- Une même ressource peut servir plusieurs objectifs selon les permissions.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [11_Personnes_ressources_budget.md](../../References/11_Personnes_ressources_budget.md)
- [01_Moteur_objectifs.md](../../References/01_Moteur_objectifs.md)

**Briques concernées (codes de spécification, pas API) :** Aucune brique supplémentaire : raccordement, catalogue, audit ou recette des modules cités.

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche visible.** Chaque panneau, matrice fille, réglage nouveau, variante modifiant la présentation et proposition de scénario doit être montré et approuvé avant intégration. La liste ci-dessous est un minimum à affiner après audit, pas une autorisation globale de tous les écrans.

## Unités à présenter et valider une par une

1. **P094-V01** — Sélection d’une ressource réelle depuis une étape.
2. **P094-V02** — Livrable présenté dans son outil natif.
3. **P094-V03** — Changement de version et effet sur la validation de l’étape.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Ressource absente, lien rompu et accès refusé.
- Une pièce jointe seule ne prouve pas la qualité finale du livrable.
- Permissions héritées explicitement, sans fuite interprojets.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P094/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
