# P058 — Musculation — Quadriceps

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P051 — Construction d’une séance de musculation composée](../06_Sport_socle/P051_Construction_dune_seance_de_musculation_composee.md), [P052 — Récupération et repos dans le budget commun](../06_Sport_socle/P052_Recuperation_et_repos_dans_le_budget_commun.md), [P008 — Référentiel de pictogrammes et validation des visuels](../01_Fondations/P008_Referentiel_de_pictogrammes_et_validation_des_visuels.md)

## Mission et périmètre

- Décliner les mouvements prévus dans la source : Presse à cuisses, squat adapté, squat guidé, extension de genou machine, fente, split squat, montée sur marche.
- Réutiliser les définitions de mouvements et leurs variantes, la fiche machine P050 et la séance P051 ; les groupes sont des index/facettes, pas des duplications.
- Associer le pictogramme réel ou faire produire et valider chaque ressource manquante. Présenter les mouvements un par un ; les variantes ayant un rendu nouveau demandent un nouvel accord.
- Un même squat ou fente peut appartenir à plusieurs groupes par relation, sans nouvelle logique d’exercice.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [08_Sports_et_machines.md](../../References/08_Sports_et_machines.md)

**Briques concernées (codes de spécification, pas API) :** Aucune brique supplémentaire : raccordement, catalogue, audit ou recette des modules cités.

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche visible.** Chaque panneau, matrice fille, réglage nouveau, variante modifiant la présentation et proposition de scénario doit être montré et approuvé avant intégration. La liste ci-dessous est un minimum à affiner après audit, pas une autorisation globale de tous les écrans.

## Unités à présenter et valider une par une

1. **P058-V01** — Matrice du groupe Quadriceps avec mouvements réellement disponibles.
2. **P058-V02** — Pour chaque mouvement retenu : pictogramme, variante/position et paramètres natifs ; une unité de validation par nouvelle présentation.
3. **P058-V03** — Exécution de série ou maintien, passage à la suite, correction et résultat.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Chaque variante garde un identifiant, une unité et un équipement explicites.
- Un même squat ou fente peut appartenir à plusieurs groupes par relation, sans nouvelle logique d’exercice.
- Suivi sans capteur, double appui, interruption/reprise et historique de la charge ou durée.
- Aucun chiffre du jeu d’essai présenté comme programme conseillé.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P058/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
