# P076 — OBJ-01 — Perdre du poids

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P075 — OBJ-09 — Améliorer sa condition physique](P075_OBJ_09_Ameliorer_sa_condition_physique.md), [P035 — Bilan alimentaire et contraintes pertinentes](../05_Briques_transversales/P035_Bilan_alimentaire_et_contraintes_pertinentes.md), [P036 — Repas, menus, variété et portions facultatives](../05_Briques_transversales/P036_Repas_menus_variete_et_portions_facultatives.md), [P037 — Protéines, fibres et apports énergétiques](../05_Briques_transversales/P037_Proteines_fibres_et_apports_energetiques.md), [P064 — Marche et mouvement du quotidien](../08_Disciplines_sportives/P064_Marche_et_mouvement_du_quotidien.md)

## Mission et périmètre

- Assembler OBJ-01 comme définition déclarative à partir des briques déjà acceptées ; ne pas recréer leurs panneaux ni leurs règles.
- Dérouler la référence métier jointe : intention, situation minimale, précautions pertinentes, effort, temps, choix/refus de briques, agenda, séance, résultat et adaptation.
- Insérer au début l’option Avec d’autres, facultative et propre à cet objectif ; aucun consentement social n’étend les droits sur les données de santé.
- Les repères de la référence ne deviennent pas des prescriptions par défaut. En l’absence de revue clinique, démontrer les fonctions neutres et marquer les conseils non publiables.
- Tester le scénario depuis Projets et la réutilisation d’au moins une brique depuis Activités ; conserver les résultats et versions.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [OBJ-01.md](../../References/Scenarios/OBJ-01.md)
- [03_Entree_effort_temps.md](../../References/03_Entree_effort_temps.md)
- [09_Preuve_et_securite.md](../../References/09_Preuve_et_securite.md)
- [52_Reseau_par_objectif.md](../../References/52_Reseau_par_objectif.md)

**Briques concernées (codes de spécification, pas API) :** [BR-NUT-01](../../Catalogue/BR-NUT-01.md), [BR-NUT-02](../../Catalogue/BR-NUT-02.md), [BR-NUT-03](../../Catalogue/BR-NUT-03.md), [BR-NUT-05](../../Catalogue/BR-NUT-05.md), [BR-ACT-01](../../Catalogue/BR-ACT-01.md), [BR-ACT-03](../../Catalogue/BR-ACT-03.md), [BR-SOM-02](../../Catalogue/BR-SOM-02.md), [BR-NUT-08](../../Catalogue/BR-NUT-08.md), [BR-SUI-03](../../Catalogue/BR-SUI-03.md)

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche visible.** Chaque panneau, matrice fille, réglage nouveau, variante modifiant la présentation et proposition de scénario doit être montré et approuvé avant intégration. La liste ci-dessous est un minimum à affiner après audit, pas une autorisation globale de tous les écrans.

## Unités à présenter et valider une par une

1. **P076-V01** — Intention et option sociale initiale : Oui / Non / Plus tard, une seule proposition à la fois.
2. **P076-V02** — Réglages et composition propres à cet objectif, avec variante faible effort et brique refusée.
3. **P076-V03** — Programme confirmé dans le projet Dashboard et occurrence correspondante dans le calendrier.
4. **P076-V04** — Exécution réelle puis bilan et proposition d’adaptation. Tout écran nouveau rencontré est une unité de validation supplémentaire.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Refuser Nutrition ne déclenche ni régime caché ni compensation sportive forcée.
- Poids non renseigné ou risque de restriction : conserver un parcours adapté/orienté, sans objectif chiffré imposé.
- Temps nul, donnée inconnue et permission de capteur refusée : parcours viable sans valeurs fictives.
- Une même activité reliée à deux objectifs ne double ni temps ni résultat.
- Accepter le social, refuser, puis retirer la visibilité : les données privées restent inaccessibles aux pairs.
- Réception humaine du scénario complet avant marquage terminé.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P076/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
