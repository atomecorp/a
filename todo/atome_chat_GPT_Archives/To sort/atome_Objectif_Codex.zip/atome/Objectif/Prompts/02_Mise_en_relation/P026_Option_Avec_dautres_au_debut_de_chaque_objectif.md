# P026 — Option Avec d’autres au début de chaque objectif

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P005 — Consentements et isolation des données](../01_Fondations/P005_Consentements_et_isolation_des_donnees.md), [P009 — Projets en matrice et création d’un objectif](../01_Fondations/P009_Projets_en_matrice_et_creation_dun_objectif.md), [P025 — Assistant et MCP raccordés au même moteur](../01_Fondations/P025_Assistant_et_MCP_raccordes_au_meme_moteur.md)

## Mission et périmètre

- Insérer une brique facultative après le choix de l’objectif, avant la composition ; elle reste retrouvable ensuite.
- Afficher dans la brique ouverte la question exacte du §52.1 et les choix Oui / Non / Plus tard, sans Oui présélectionné.
- Conserver la préférence par objectif ; Oui ouvre la configuration de mise en relation, sans publier ni envoyer de demande.
- Ne pas rendre le réseau public opérationnel avant les protections de P030. Les cas urgents accèdent d’abord à l’aide.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [52_Reseau_par_objectif.md](../../References/52_Reseau_par_objectif.md)
- [03_Entree_effort_temps.md](../../References/03_Entree_effort_temps.md)

**Briques concernées (codes de spécification, pas API) :** [BR-SOC-01](../../Catalogue/BR-SOC-01.md)

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche visible.** Chaque panneau, matrice fille, réglage nouveau, variante modifiant la présentation et proposition de scénario doit être montré et approuvé avant intégration. La liste ci-dessous est un minimum à affiner après audit, pas une autorisation globale de tous les écrans.

## Unités à présenter et valider une par une

1. **P026-V01** — Entrée d’un objectif avec brique Avec d’autres.
2. **P026-V02** — Brique ouverte avec les trois choix.
3. **P026-V03** — Continuation avec Non/Plus tard puis réactivation depuis le projet.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Tester les douze définitions d’objectif et un objectif libre.
- Deux objectifs d’une même personne ont des préférences indépendantes.
- Dupliquer un objectif ne copie pas une autorisation de visibilité.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P026/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
