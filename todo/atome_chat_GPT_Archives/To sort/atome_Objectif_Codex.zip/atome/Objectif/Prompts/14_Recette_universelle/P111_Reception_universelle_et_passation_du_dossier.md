# P111 — Réception universelle et passation du dossier

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P098 — EXT-01 — Créer une chanson](../13_Scenarios_generiques/P098_EXT_01_Creer_une_chanson.md), [P099 — EXT-02 — Créer un album](../13_Scenarios_generiques/P099_EXT_02_Creer_un_album.md), [P100 — EXT-03 — Préparer un concert](../13_Scenarios_generiques/P100_EXT_03_Preparer_un_concert.md), [P101 — EXT-04 — Réaliser un film](../13_Scenarios_generiques/P101_EXT_04_Realiser_un_film.md), [P102 — EXT-05 — Finaliser un MVP logiciel](../13_Scenarios_generiques/P102_EXT_05_Finaliser_un_MVP_logiciel.md), [P103 — EXT-06 — Créer une entreprise](../13_Scenarios_generiques/P103_EXT_06_Creer_une_entreprise.md), [P104 — EXT-07 — Lancer un produit](../13_Scenarios_generiques/P104_EXT_07_Lancer_un_produit.md), [P105 — EXT-08 — Organiser un événement](../13_Scenarios_generiques/P105_EXT_08_Organiser_un_evenement.md), [P106 — EXT-09 — Trouver un financement](../13_Scenarios_generiques/P106_EXT_09_Trouver_un_financement.md), [P107 — EXT-10 — Apprendre une compétence](../13_Scenarios_generiques/P107_EXT_10_Apprendre_une_competence.md), [P108 — EXT-11 — Préparer un marathon](../13_Scenarios_generiques/P108_EXT_11_Preparer_un_marathon.md), [P109 — EXT-12 — Organiser une grande randonnée](../13_Scenarios_generiques/P109_EXT_12_Organiser_une_grande_randonnee.md), [P110 — EXT-13 — Objectif libre et extension du catalogue](../13_Scenarios_generiques/P110_EXT_13_Objectif_libre_et_extension_du_catalogue.md)

## Mission et périmètre

- Rejouer album, marathon, film, entreprise, randonnée et objectif libre conformément à la source, puis vérifier les autres scénarios ajoutés.
- Prouver que les mêmes primitives et outils portent ces objectifs sans six moteurs distincts.
- Mettre à jour le catalogue réellement opérationnel, les limites, le mapping et les dossiers de validation.
- Remettre le lot final pour recette humaine. Toute publication ou déploiement reste une décision séparée.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [12_Recettes_originales.md](../../References/12_Recettes_originales.md)
- [01_Moteur_objectifs.md](../../References/01_Moteur_objectifs.md)
- [52_Reseau_par_objectif.md](../../References/52_Reseau_par_objectif.md)

**Briques concernées (codes de spécification, pas API) :** Aucune brique supplémentaire : raccordement, catalogue, audit ou recette des modules cités.

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche visible.** Chaque panneau, matrice fille, réglage nouveau, variante modifiant la présentation et proposition de scénario doit être montré et approuvé avant intégration. La liste ci-dessous est un minimum à affiner après audit, pas une autorisation globale de tous les écrans.

## Unités à présenter et valider une par une

1. **P111-V01** — Démonstrations des six parcours de référence, une à une.
2. **P111-V02** — Ajout d’un scénario inédit par données.
3. **P111-V03** — Version livrée et liste lisible des limites restantes.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Dépendances, budget, participants, pièces jointes, agenda, progression et maintien vérifiés.
- Aucune entrée du catalogue historique présentée comme achevée sans tâche et preuve.
- Tous les jalons techniques, visuels et utilisateur sont reliés à leur version réelle.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P111/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
