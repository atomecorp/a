# P002 — Revue des valeurs médicales et des sources héritées

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P001 — Audit du dépôt, des références et des outils réels](P001_Audit_du_depot_des_references_et_des_outils_reels.md)

## Mission et périmètre

- Construire un registre des valeurs, suggestions, contre-indications et ressources d’orientation présentes dans les sections 50 et 51.
- Vérifier les références primaires actuelles avant de les publier : titre, population, unité, date, limites et niveau de preuve ; ne pas reprendre la mention historique « vérifié » comme preuve actuelle.
- Séparer préférence, exemple UX, donnée de test, repère populationnel, conseil validé et recommandation d’un professionnel. Marquer toute valeur non revue comme non publiable en recommandation.
- Préparer la revue clinique humaine des conseils ; Codex vérifie le logiciel et la traçabilité, pas sa propre habilitation médicale. Les outils neutres peuvent continuer sans publier de conseils non validés.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [09_Preuve_et_securite.md](../../References/09_Preuve_et_securite.md)
- [04_Catalogue_briques.md](../../References/04_Catalogue_briques.md)

**Briques concernées (codes de spécification, pas API) :** Aucune brique supplémentaire : raccordement, catalogue, audit ou recette des modules cités.

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche sans nouveau panneau obligatoire.** Présente le livrable lisible et une démonstration dans les outils existants si pertinente ; fais valider le périmètre et l'absence de régression. N'invente pas une interface pour satisfaire artificiellement un jalon visuel. La recette humaine de la tâche reste nécessaire.

## Unités à présenter et valider une par une

1. **P002-V01** — Présenter le registre de preuve et les valeurs bloquées ; aucun nouveau panneau médical à inventer.
2. **P002-V02** — Faire valider la façon dont la provenance sera accessible dans une brique existante, sans surcharge permanente.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Aucun exemple de 10 kg/5×5 ou durée UX ne devient une prescription par défaut.
- Chaque source incertaine est signalée, chaque consigne retirée garde son historique.
- Les besoins de validation professionnelle restent distincts de l’accord visuel.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P002/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
