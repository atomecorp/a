# P045 — Temps personnel, loisirs, liens et limites

**Statut initial : A_FAIRE.** Ce fichier est un prompt d'exécution, pas une preuve de réalisation.

**Pilotage :** [prompt maître](../../Objectif.md) · [état réel](../../Pilotage/Etat_des_taches.md) · [ordre de travail](../../Pilotage/Ordre_des_taches.md).

**Prérequis techniques :** [P044 — Journal privé multimédia et analyse sélective](P044_Journal_prive_multimedia_et_analyse_selective.md), [P030 — Retrait, blocage, signalement et ouverture sûre du réseau](../02_Mise_en_relation/P030_Retrait_blocage_signalement_et_ouverture_sure_du_reseau.md)

## Mission et périmètre

- Réutiliser les activités réelles de création, repos, contact et organisation ; Ne rien faire est une activité valide.
- Prévoir créneaux personnels, pauses, limites de disponibilité et routines facultatives.
- Un lien social vers un proche reste distinct du réseau par objectif ; aucun contact réel sans action explicite.
- Chaque nouvelle matrice de choix est une unité visuelle séparée.

**Hors périmètre :** Ne pas traiter les autres tâches, ne pas refaire les outils natifs ni déployer à distance.

## Références à lire

- [53_Validation_progressive.md](../../References/53_Validation_progressive.md)
- [OBJ-06.md](../../References/Scenarios/OBJ-06.md)
- [OBJ-11.md](../../References/Scenarios/OBJ-11.md)

**Briques concernées (codes de spécification, pas API) :** [BR-VIE-01](../../Catalogue/BR-VIE-01.md), [BR-VIE-02](../../Catalogue/BR-VIE-02.md), [BR-VIE-04](../../Catalogue/BR-VIE-04.md), [BR-VIE-05](../../Catalogue/BR-VIE-05.md), [BR-VIE-06](../../Catalogue/BR-VIE-06.md), [BR-MEN-04](../../Catalogue/BR-MEN-04.md)

## Avant toute modification

Retrouve les composants, fichiers, symboles, connexions et tests réels. Décris la structure concrète de l'unité courante : outils affichés, mode de sélection, matrices et emplacement des options natives. Respecte atome/eVe, JavaScript, les SVG, couleurs, proportions et conventions vérifiés. Réutilise les outils ; pas d'UI parallèle. Une référence essentielle absente entraîne une question ciblée, pas une invention.

**Tâche visible.** Chaque panneau, matrice fille, réglage nouveau, variante modifiant la présentation et proposition de scénario doit être montré et approuvé avant intégration. La liste ci-dessous est un minimum à affiner après audit, pas une autorisation globale de tous les écrans.

## Unités à présenter et valider une par une

1. **P045-V01** — Choix d’une activité plaisante ou de repos.
2. **P045-V02** — Créneau protégé et limites de disponibilité.
3. **P045-V03** — Report volontaire et résultat subjectif facultatif.

Pour chaque unité, utilise une révision `r1`, `r2`… et les preuves de la version du code. Tout nouveau rendu non décrit ci-dessus devient une unité supplémentaire. Si le périmètre est encore trop large, propose un sous-prompt selon le modèle et attends l'accord sur ce découpage.

## Boucle obligatoire : démontrer → attendre → intégrer → tester

1. Prépare la seule unité courante dans une démonstration isolée avec les vrais composants ; fixtures clairement identifiées, aucun effet sur des utilisateurs réels.
2. Affiche-la dans l'application de test ; fournis chemin d'accès, gestes de reproduction, plateforme, révision et captures réelles. Privilégie l'iPad disponible pour iOS, avec l'outillage effectivement accessible.
3. **Arrête-toi et demande la validation visuelle de cette unité précise. Aucune intégration avant réponse.** Une validation d'une autre unité, un test automatique ou une capture non montrée ne compte pas.
4. Après accord explicite et correctement attribué, intègre uniquement cette unité et exécute les tests techniques. Si l'apparence change, représente-la pour nouvelle validation.
5. Procède de même pour les autres unités. Ne démarre pas une autre tâche en parallèle.

## Tests techniques à mener par Codex

- Pas de double facturation temporelle d’un loisir déjà planifié.
- Aucun envoi automatique au contact sélectionné.
- Un créneau reporté ne devient pas faute ou diagnostic.

Teste aussi erreurs, données manquantes, refus de permission, historique et régression des composants touchés. Les commandes et résultats doivent être réels ; distingue test unitaire avec fixture, essai d'intégration et essai sur appareil. Un service absent est bloqué/non testé, pas simulé puis déclaré opérationnel. Les valeurs médicales héritées restent soumises à la revue de preuve et au cadre clinique prévu.

## Recette utilisateur et sortie de tâche

Une fois les unités intégrées et les tests de Codex passés, fournis une version manipulable avec un parcours final correspondant aux unités ci-dessus. **Attends le test du porteur du projet sur la tâche entière.** Corrige ses retours avant clôture. Seule une recette réellement acceptée permet le statut TERMINEE. Attends ensuite une instruction explicite de poursuite : les tests réussis n'autorisent pas le prompt suivant.

Renseigne [les validations visuelles](../../Pilotage/Validations_visuelles.md), [les résultats techniques](../../Pilotage/Tests_techniques.md) et [la recette utilisateur](../../Pilotage/Recettes_utilisateur.md) avec la version testée. Conserve les preuves réelles dans `Pilotage/Preuves/P045/` lorsqu'elles existent.

**Livrables :** modifications limitées au périmètre approuvé, mapping réel actualisé, démonstration, résultats des tests, limites et procédure de retour arrière adaptée. Aucun déploiement distant ni opération sur les données de production par défaut.
