# Machine personnelle — modèle conceptuel extensible

Une machine est un équipement indépendant, pas un nouveau projet ou moteur d'exercice. La fiche se construit avec les vrais outils atome/eVe ; les informations facultatives inconnues restent inconnues.

Décrire : identifiant stable, nom choisi, type, mouvements associés, pictogramme ou photo autorisée, localisation facultative, source/utilisateur propriétaire, visibilité privée par défaut, version et archivage.

Paramètres propres : charge affichée et unité, assistance ou résistance, incréments réellement disponibles, réglages du siège/poignées/position, notes utiles et compatibilité éventuelle d'un connecteur **vérifié**. Ne pas inventer de connexion à une marque ni de conversion de résistance en puissance.

Les réglages se montrent dans les carrés extensibles. Les paramètres d'entraînement restent dans la brique du mouvement. Plusieurs machines peuvent servir un mouvement ; une machine peut servir plusieurs mouvements. Un classement musculaire ne duplique pas le mouvement.

Conserver machine/version dans les séances antérieures même après modification ou archivage. Ne pas comparer arbitrairement les charges affichées de machines différentes. Toute nouvelle présentation, photo ou pictogramme est montrée et validée avant intégration.
