# Fiche de scénario — modèle déclaratif

## Intention et frontières

Code stable, nom compréhensible, résultat souhaité, limites, population/contexte lorsqu'il s'agit de santé, critères qualitatifs et quantitatifs réellement justifiés.

## Entrée commune

Choix de l'objectif puis option **Avec d'autres** : Oui / Non / Plus tard, facultative, propre à cet objectif, sans publication implicite. Données minimales utiles, précautions pertinentes, Effort souhaité et Temps disponible. Les ressources d'aide urgente restent prioritaires si nécessaire.

## Composition

Références de briques existantes, variantes, prérequis, ordre/dépendances, briques facultatives, choix Accepter / Modifier / Refuser / Reporter. Temps total cohérent et activités multi-objectifs dédupliquées. Décrire la variante à très faible engagement, la donnée inconnue et le refus d'une famille.

## Parcours visible

Matrice racine, matrices filles, carrés étendus et commandes natives, programme accepté, projet Dashboard, occurrence, exécution, résultats, bilan et adaptation. Ne pas recopier un écran déjà porté par une brique. Identifier tous les assemblages et états nouveaux à faire approuver.

## Exécution, suivi et maintien

Actions réelles, séance ou autre outil pertinent, capteurs facultatifs, alternative manuelle, prévu/réalisé, origine des observations, confidentialité, historique, pause/reprise et critères de clôture/maintien.

## Sources et validations

Conseils/valeurs sourcés et revus avant publication ; test logiciel ≠ validation clinique. Pour chaque nouvelle unité : démonstration, arrêt pour accord visuel, intégration limitée et tests Codex. À la fin : recette du scénario complet par le porteur du projet et attente d'une instruction de poursuite.
