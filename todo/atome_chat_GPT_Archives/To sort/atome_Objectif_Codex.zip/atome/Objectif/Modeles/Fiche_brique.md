# Fiche de brique — modèle de spécification

Identifiant stable de **spécification**, version, nom court, domaine et finalité. Ne pas transformer l'identifiant en nom de méthode avant audit.

Préciser le véritable outil ou composant réutilisé, sa référence vérifiée, la matrice d'entrée, les sous-matrices et les paramètres natifs. Pour chaque paramètre : type, unité éventuelle, origine, choix facultatif/nécessaire, contrôle réel, bornes de saisie et statut de preuve d'une valeur proposée. Aucune valeur clinique par défaut sans cadre approprié.

Distinguer définition, activité configurée, séance, occurrence et résultat. Documenter les événements d'exécution, les états de pause/reprise, prévu/réalisé et les cas sans capteur. Une brique de choix/document n'a pas besoin d'un faux moteur de séance.

Identifier pictogramme/version/droits et nouvelle variante à faire approuver. Lister les objectifs qui composent la brique et son entrée autonome dans Activités. Les objectifs ne possèdent pas des copies du moteur.

Décrire permissions, données privées, partage sélectif, retrait et références de sources. L'option sociale d'un objectif n'autorise pas l'accès à cette brique par ses participants.

Rattacher un prompt responsable, des unités visuelles à montrer, des tests techniques et une recette utilisateur finale. Statut initial : spécification seulement, rien n'est implicitement réalisé.
