# Proposition à montrer — modèle de preuve

**Aucune approbation n'est contenue dans ce modèle.**

Tâche et unité : à renseigner. Révision : à renseigner. Version du code réellement montrée : à renseigner. Plateforme, appareil, orientation/thème et état : à renseigner.

Outils natifs visibles et références de design effectivement utilisées : à renseigner. Chemin dans l'application de test et gestes de manipulation : à renseigner. Captures/vidéo réellement produites et données de démonstration identifiées : à renseigner.

Ce qui est déjà connecté, ce qui est simulé et ce qui manque : à préciser sans ambiguïté. Périmètre exact qui sera intégré après accord : à préciser. Aucun élément voisin n'est inclus par défaut.

**Demande :** « Valides-tu visuellement cette proposition précise avant son intégration ? » Puis arrêt.

Après la réponse seulement : recopier la formulation réelle, sa date et sa portée dans le journal. Refus ou changement de rendu : nouvelle révision et nouvelle présentation. La recette finale de toute la tâche restera nécessaire après les tests techniques.
