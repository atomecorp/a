# Pxxx.01 — Titre d'une sous-tâche à valider

**Modèle non exécuté.** Remplacer les champs ci-dessous par les informations auditées. Ne pas ajouter cette tâche à l'ordre actif sans accord du porteur du projet.

## Rattachement

Tâche parente, besoin précis, référence du cahier, composants réels, dépendances déjà acceptées et limites. Expliquer pourquoi la sous-tâche ne peut pas être traitée comme une simple unité de sa tâche parente. Mettre à jour l'ordre, le registre et les références seulement après accord.

## Mission unique

Décrire un résultat vérifiable, les objets/outils à réutiliser, les seuls fichiers qui pourraient changer et ce qui reste hors périmètre. Aucun endpoint ou composant supposé ; JavaScript et architecture existante pour eVe.

## Structure visuelle concrète

Outils affichés, sélection, matrice parente/fille, contrôle natif à l'intérieur du carré étendu, retour et sauvegarde. Retrouver la référence de proportions, couleurs et pictogrammes. Une référence essentielle manquante bloque le choix visuel.

## Unités de proposition

Identifier chaque nouveau rendu `Pxxx.01-V01`, `V02`… avec révision, plateforme et code. Montrer une unité à la fois dans une démonstration isolée et manipulable. Aucun panneau ne peut être approuvé par l'existence d'un mock ou d'une image.

**Arrêt obligatoire avant intégration :** attendre la validation visuelle explicite de cette unité et de sa version. Refus : corriger puis représenter. Accord : intégrer uniquement l'unité concernée et tester. Nouvelle apparence après correction : nouvelle validation.

## Vérification technique de Codex

Spécifier les données de test, procédure, résultat attendu, erreurs/refus, persistance et régressions propres à cette sous-tâche. Conserver les commandes réellement exécutées et les preuves, sans les inventer. Aucune connexion simulée présentée comme opérationnelle.

## Recette finale humaine

Une fois toutes les unités intégrées et testées, fournir une version et un parcours final. Attendre le test du porteur du projet et son accord réel. Ne pas démarrer la sous-tâche ou tâche suivante sans autorisation explicite. Le statut de la tâche parente reste non terminé tant que ses autres unités et sa recette globale manquent.
