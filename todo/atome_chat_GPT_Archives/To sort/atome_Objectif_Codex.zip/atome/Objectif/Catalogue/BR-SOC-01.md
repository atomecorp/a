# BR-SOC-01 — option initiale et consentements par objectif

**Domaine :** Mise en relation par objectif. **État : spécifié, implémentation non vérifiée.**

**Prompt responsable :** [P026 — Option Avec d’autres au début de chaque objectif](../Prompts/02_Mise_en_relation/P026_Option_Avec_dautres_au_debut_de_chaque_objectif.md).

**Source :** section 52, avec détails métier : [52_Reseau_par_objectif.md](../References/52_Reseau_par_objectif.md).

## Fonction et réutilisation

Cette fiche désigne la fonction « option initiale et consentements par objectif », réutilisable par composition ; elle ne définit pas une API disponible. Les outils, symboles et connexions correspondants doivent être relevés dans [le mapping réel](../Pilotage/Mapping_composants.md). Aucun outil nouveau n'est nécessaire si une capacité existante suffit.

**Objectifs explicitement reliés dans le plan initial :** OBJ-01, OBJ-02, OBJ-03, OBJ-04, OBJ-05, OBJ-06, OBJ-07, OBJ-08, OBJ-09, OBJ-10, OBJ-11, OBJ-12

## Paramètres et données conceptuels

Objectif concerné, réponse Oui/Non/Plus tard/inconnue ; aucun accord implicite sur la visibilité.

Chaque valeur conserve son type, son unité lorsqu'elle en possède une et sa provenance. Les bornes de contrôle et valeurs initiales sont reprises des composants réels ou soumises à validation. Une donnée inconnue reste inconnue. Une valeur médicale n'est pas une préférence ni une valeur UX. Cette fiche n'impose aucune dose ou intensité.

## Présentation et exécution

Entrée depuis la matrice du projet ou le domaine pertinent d'Activités. Le carré ouvre une matrice fille, ou s'étend temporairement pour révéler **le contrôle natif** du paramètre. Le pictogramme reste à mapper/réutiliser et doit être approuvé si nouveau. Les outils gardent leurs options dans leur espace natif ; aucun formulaire parallèle.

Si la brique produit une activité : relier l'activité configurée, ses occurrences, étapes et observations aux modules communs. Si elle porte seulement un choix, un droit ou un document : ne pas fabriquer une séance pour ce besoin. Une même réalisation n'est jamais copiée pour plusieurs objectifs.

## Consentements, validation et tests

Accès aux données, analyse, capteurs, visibilité et partage restent distincts. L'opt-in social n'ouvre pas cette brique aux pairs. L'utilisateur peut refuser ou retirer les éléments facultatifs, sans effacer silencieusement les résultats passés.

Le prompt responsable précise les essais propres à la brique. Tester aussi la variante sans données, la sauvegarde/reprise et les refus de permission. Toute nouvelle présentation suit [la validation visuelle bloquante](../References/53_Validation_progressive.md). Le code et le pictogramme ne sont pas considérés réalisés par l'existence de cette fiche.
