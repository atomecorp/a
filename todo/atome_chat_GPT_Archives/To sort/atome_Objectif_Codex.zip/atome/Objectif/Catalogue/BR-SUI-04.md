# BR-SUI-04 — examens / prévention

**Domaine :** Santé et suivi. **État : spécifié, implémentation non vérifiée.**

**Prompt responsable :** [P040 — Consultations, examens et prévention planifiée](../Prompts/05_Briques_transversales/P040_Consultations_examens_et_prevention_planifiee.md).

**Source :** section 51.4, avec détails métier : [06_Resultats_moniteur.md](../References/06_Resultats_moniteur.md).

## Fonction et réutilisation

Cette fiche désigne la fonction « examens / prévention », réutilisable par composition ; elle ne définit pas une API disponible. Les outils, symboles et connexions correspondants doivent être relevés dans [le mapping réel](../Pilotage/Mapping_composants.md). Aucun outil nouveau n'est nécessaire si une capacité existante suffit.

**Objectifs explicitement reliés dans le plan initial :** À sélectionner selon le contexte ; disponible aussi depuis Activités, sans rendre la brique obligatoire.

## Paramètres et données conceptuels

Examen ou prévention proposé par source identifiée, indication/référence, date et statut.

Chaque valeur conserve son type, son unité lorsqu'elle en possède une et sa provenance. Les bornes de contrôle et valeurs initiales sont reprises des composants réels ou soumises à validation. Une donnée inconnue reste inconnue. Une valeur médicale n'est pas une préférence ni une valeur UX. Cette fiche n'impose aucune dose ou intensité.

## Présentation et exécution

Entrée depuis la matrice du projet ou le domaine pertinent d'Activités. Le carré ouvre une matrice fille, ou s'étend temporairement pour révéler **le contrôle natif** du paramètre. Le pictogramme reste à mapper/réutiliser et doit être approuvé si nouveau. Les outils gardent leurs options dans leur espace natif ; aucun formulaire parallèle.

Si la brique produit une activité : relier l'activité configurée, ses occurrences, étapes et observations aux modules communs. Si elle porte seulement un choix, un droit ou un document : ne pas fabriquer une séance pour ce besoin. Une même réalisation n'est jamais copiée pour plusieurs objectifs.

## Consentements, validation et tests

Accès aux données, analyse, capteurs, visibilité et partage restent distincts. L'opt-in social n'ouvre pas cette brique aux pairs. L'utilisateur peut refuser ou retirer les éléments facultatifs, sans effacer silencieusement les résultats passés.

Le prompt responsable précise les essais propres à la brique. Tester aussi la variante sans données, la sauvegarde/reprise et les refus de permission. Toute nouvelle présentation suit [la validation visuelle bloquante](../References/53_Validation_progressive.md). Le code et le pictogramme ne sont pas considérés réalisés par l'existence de cette fiche.
