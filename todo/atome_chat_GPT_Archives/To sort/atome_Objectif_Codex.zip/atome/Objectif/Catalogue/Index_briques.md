# Catalogue des 77 briques

72 codes explicitement définis en §51.4, complétés par 5 briques sociales en §52. Ce sont des identifiants de spécification, pas des API certifiées. Le prompt responsable réalise ou raccorde la brique ; les scénarios suivants la réutilisent.

## Démarrage

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-COM-01](BR-COM-01.md) | intention | [P009](../Prompts/01_Fondations/P009_Projets_en_matrice_et_creation_dun_objectif.md) |
| [BR-COM-02](BR-COM-02.md) | situation de départ | [P010](../Prompts/01_Fondations/P010_Recueil_initial_progressif_et_situation_de_depart.md) |
| [BR-COM-03](BR-COM-03.md) | effort souhaité | [P011](../Prompts/01_Fondations/P011_Curseur_dengagement_Effort_souhaite.md) |
| [BR-COM-04](BR-COM-04.md) | temps disponible | [P012](../Prompts/01_Fondations/P012_Budget_Temps_par_jour_ou_par_semaine.md) |
| [BR-COM-05](BR-COM-05.md) | contraintes/préférences | [P013](../Prompts/01_Fondations/P013_Contraintes_preferences_et_capacite_du_moment.md) |
| [BR-COM-06](BR-COM-06.md) | consentements | [P005](../Prompts/01_Fondations/P005_Consentements_et_isolation_des_donnees.md) |
| [BR-COM-07](BR-COM-07.md) | validation et adaptation | [P014](../Prompts/01_Fondations/P014_Composer_et_valider_un_programme_brique_par_brique.md) |

## Sommeil

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-SOM-01](BR-SOM-01.md) | journal sommeil | [P031](../Prompts/03_Briques_sommeil/P031_Journal_de_sommeil_et_observation_volontaire.md) |
| [BR-SOM-02](BR-SOM-02.md) | régularité lever/coucher | [P032](../Prompts/03_Briques_sommeil/P032_Rythme_environnement_rituel_et_stimulants.md) |
| [BR-SOM-03](BR-SOM-03.md) | lumière/rythme | [P032](../Prompts/03_Briques_sommeil/P032_Rythme_environnement_rituel_et_stimulants.md) |
| [BR-SOM-04](BR-SOM-04.md) | environnement/rituel | [P032](../Prompts/03_Briques_sommeil/P032_Rythme_environnement_rituel_et_stimulants.md) |
| [BR-SOM-05](BR-SOM-05.md) | stimulants et horaires | [P032](../Prompts/03_Briques_sommeil/P032_Rythme_environnement_rituel_et_stimulants.md) |
| [BR-SOM-06](BR-SOM-06.md) | orientation TCC-I / évaluation clinique | [P033](../Prompts/03_Briques_sommeil/P033_Orientation_sommeil_et_acces_au_professionnel.md) |

## Nutrition

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-NUT-01](BR-NUT-01.md) | habitudes / bilan alimentaire | [P035](../Prompts/05_Briques_transversales/P035_Bilan_alimentaire_et_contraintes_pertinentes.md) |
| [BR-NUT-02](BR-NUT-02.md) | choix de repas | [P036](../Prompts/05_Briques_transversales/P036_Repas_menus_variete_et_portions_facultatives.md) |
| [BR-NUT-03](BR-NUT-03.md) | qualité des aliments et variété | [P036](../Prompts/05_Briques_transversales/P036_Repas_menus_variete_et_portions_facultatives.md) |
| [BR-NUT-04](BR-NUT-04.md) | protéines | [P037](../Prompts/05_Briques_transversales/P037_Proteines_fibres_et_apports_energetiques.md) |
| [BR-NUT-05](BR-NUT-05.md) | légumes/fruits/fibres | [P037](../Prompts/05_Briques_transversales/P037_Proteines_fibres_et_apports_energetiques.md) |
| [BR-NUT-06](BR-NUT-06.md) | énergie/alimentation suffisante | [P037](../Prompts/05_Briques_transversales/P037_Proteines_fibres_et_apports_energetiques.md) |
| [BR-NUT-07](BR-NUT-07.md) | hydratation | [P038](../Prompts/05_Briques_transversales/P038_Hydratation_courses_et_preparation.md) |
| [BR-NUT-08](BR-NUT-08.md) | courses/préparation | [P038](../Prompts/05_Briques_transversales/P038_Hydratation_courses_et_preparation.md) |
| [BR-NUT-09](BR-NUT-09.md) | allergies, intolérances et adaptation | [P035](../Prompts/05_Briques_transversales/P035_Bilan_alimentaire_et_contraintes_pertinentes.md) |

## Activité physique

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-ACT-01](BR-ACT-01.md) | marche | [P064](../Prompts/08_Disciplines_sportives/P064_Marche_et_mouvement_du_quotidien.md) |
| [BR-ACT-02](BR-ACT-02.md) | endurance/course | [P065](../Prompts/08_Disciplines_sportives/P065_Course_tapis_piste_et_intervalles.md) |
| [BR-ACT-03](BR-ACT-03.md) | musculation | [P051](../Prompts/06_Sport_socle/P051_Construction_dune_seance_de_musculation_composee.md) |
| [BR-ACT-04](BR-ACT-04.md) | natation | [P066](../Prompts/08_Disciplines_sportives/P066_Natation_en_bassin_et_eau_libre.md) |
| [BR-ACT-05](BR-ACT-05.md) | rameur | [P067](../Prompts/08_Disciplines_sportives/P067_Rameur_interieur_et_aviron.md) |
| [BR-ACT-06](BR-ACT-06.md) | vélo | [P068](../Prompts/08_Disciplines_sportives/P068_Velo_exterieur_et_interieur.md) |
| [BR-ACT-07](BR-ACT-07.md) | mobilité/étirements | [P071](../Prompts/08_Disciplines_sportives/P071_Mobilite_et_etirements_par_zone_et_position.md) |
| [BR-ACT-08](BR-ACT-08.md) | yoga/pilates | [P072](../Prompts/08_Disciplines_sportives/P072_Yoga_Pilates_et_gymnastique_douce.md) |
| [BR-ACT-09](BR-ACT-09.md) | équilibre | [P073](../Prompts/08_Disciplines_sportives/P073_Equilibre_et_autonomie.md) |
| [BR-ACT-10](BR-ACT-10.md) | autres sports extensibles | [P049](../Prompts/06_Sport_socle/P049_Taxonomie_sportive_unites_et_activite_manuelle_extensible.md) |
| [BR-ACT-11](BR-ACT-11.md) | récupération/repos | [P052](../Prompts/06_Sport_socle/P052_Recuperation_et_repos_dans_le_budget_commun.md) |
| [BR-ACT-12](BR-ACT-12.md) | mouvement du quotidien | [P064](../Prompts/08_Disciplines_sportives/P064_Marche_et_mouvement_du_quotidien.md) |

## Calme et émotions

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-MEN-01](BR-MEN-01.md) | respiration confortable | [P042](../Prompts/05_Briques_transversales/P042_Respiration_confortable_et_relaxation.md) |
| [BR-MEN-02](BR-MEN-02.md) | relaxation | [P042](../Prompts/05_Briques_transversales/P042_Respiration_confortable_et_relaxation.md) |
| [BR-MEN-03](BR-MEN-03.md) | méditation/attention | [P043](../Prompts/05_Briques_transversales/P043_Meditation_et_attention_variantes_facultatives.md) |
| [BR-MEN-04](BR-MEN-04.md) | pauses et stress | [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) |
| [BR-MEN-05](BR-MEN-05.md) | repérage de l'humeur | [P046](../Prompts/05_Briques_transversales/P046_Humeur_volontaire_et_activites_aidantes.md) |
| [BR-MEN-06](BR-MEN-06.md) | activation comportementale | [P046](../Prompts/05_Briques_transversales/P046_Humeur_volontaire_et_activites_aidantes.md) |
| [BR-MEN-07](BR-MEN-07.md) | soutien et aide professionnelle | [P047](../Prompts/05_Briques_transversales/P047_Soutien_aide_professionnelle_et_plan_de_securite.md) |
| [BR-MEN-08](BR-MEN-08.md) | plan de sécurité personnalisé *avec professionnel lorsque nécessaire* | [P047](../Prompts/05_Briques_transversales/P047_Soutien_aide_professionnelle_et_plan_de_securite.md) |

## Vie personnelle

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-VIE-01](BR-VIE-01.md) | temps pour soi | [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) |
| [BR-VIE-02](BR-VIE-02.md) | loisirs/création | [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) |
| [BR-VIE-03](BR-VIE-03.md) | journal privé | [P044](../Prompts/05_Briques_transversales/P044_Journal_prive_multimedia_et_analyse_selective.md) |
| [BR-VIE-04](BR-VIE-04.md) | liens sociaux | [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) |
| [BR-VIE-05](BR-VIE-05.md) | limites/disponibilité | [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) |
| [BR-VIE-06](BR-VIE-06.md) | organisation des routines | [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) |

## Santé et suivi

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-SUI-01](BR-SUI-01.md) | symptômes | [P041](../Prompts/05_Briques_transversales/P041_Symptomes_douleur_et_orientation.md) |
| [BR-SUI-02](BR-SUI-02.md) | douleur | [P041](../Prompts/05_Briques_transversales/P041_Symptomes_douleur_et_orientation.md) |
| [BR-SUI-03](BR-SUI-03.md) | consultations/rendez-vous | [P040](../Prompts/05_Briques_transversales/P040_Consultations_examens_et_prevention_planifiee.md) |
| [BR-SUI-04](BR-SUI-04.md) | examens / prévention | [P040](../Prompts/05_Briques_transversales/P040_Consultations_examens_et_prevention_planifiee.md) |
| [BR-SUI-05](BR-SUI-05.md) | résultats multi-formats | [P021](../Prompts/01_Fondations/P021_Documents_originaux_et_reception_de_resultats.md) |
| [BR-SUI-06](BR-SUI-06.md) | mesures / capteurs | [P020](../Prompts/01_Fondations/P020_Capteurs_disponibles_et_suivi_manuel_equivalent.md) |
| [BR-SUI-07](BR-SUI-07.md) | traitements déclarés | [P039](../Prompts/05_Briques_transversales/P039_Complements_et_traitements_declares.md) |
| [BR-SUI-08](BR-SUI-08.md) | compléments déclarés/proposés | [P039](../Prompts/05_Briques_transversales/P039_Complements_et_traitements_declares.md) |
| [BR-SUI-09](BR-SUI-09.md) | suivi longitudinal | [P023](../Prompts/01_Fondations/P023_Moniteur_commun_bilan_et_adaptation_consentie.md) |
| [BR-SUI-10](BR-SUI-10.md) | orientation et signaux d'alerte | [P041](../Prompts/05_Briques_transversales/P041_Symptomes_douleur_et_orientation.md) |

## Prévention et vieillissement

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-AGE-01](BR-AGE-01.md) | prévention et suivi adapté | [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) |
| [BR-AGE-02](BR-AGE-02.md) | santé fonctionnelle/autonomie | [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) |
| [BR-AGE-03](BR-AGE-03.md) | peau et photoprotection | [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) |
| [BR-AGE-04](BR-AGE-04.md) | capacités cognitives / activités enrichissantes | [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) |
| [BR-AGE-05](BR-AGE-05.md) | santé bucco-dentaire | [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) |
| [BR-AGE-06](BR-AGE-06.md) | prévention chutes/équilibre | [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) |

## Orchestration (déjà unifiée conceptuellement)

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-SYS-01](BR-SYS-01.md) | matrice de sélection | [P006](../Prompts/01_Fondations/P006_Matrice_universelle_et_navigation_en_profondeur.md) |
| [BR-SYS-02](BR-SYS-02.md) | projet Dashboard | [P016](../Prompts/01_Fondations/P016_Projet_Dashboard_et_activites_du_jour.md) |
| [BR-SYS-03](BR-SYS-03.md) | calendrier/occurrences | [P017](../Prompts/01_Fondations/P017_Calendrier_commun_recurrences_et_conflits.md) |
| [BR-SYS-04](BR-SYS-04.md) | alarmes | [P018](../Prompts/01_Fondations/P018_Alarmes_et_ouverture_du_bon_contexte.md) |
| [BR-SYS-05](BR-SYS-05.md) | outil de séance | [P019](../Prompts/01_Fondations/P019_Moteur_commun_de_seance_et_progression_tactile.md) |
| [BR-SYS-06](BR-SYS-06.md) | Moniteur | [P023](../Prompts/01_Fondations/P023_Moniteur_commun_bilan_et_adaptation_consentie.md) |
| [BR-SYS-07](BR-SYS-07.md) | stockage/export | [P021](../Prompts/01_Fondations/P021_Documents_originaux_et_reception_de_resultats.md) |
| [BR-SYS-08](BR-SYS-08.md) | consentements/partage | [P005](../Prompts/01_Fondations/P005_Consentements_et_isolation_des_donnees.md) |

## Mise en relation par objectif

| Code | Fonction | Prompt responsable |
| --- | --- | --- |
| [BR-SOC-01](BR-SOC-01.md) | option initiale et consentements par objectif | [P026](../Prompts/02_Mise_en_relation/P026_Option_Avec_dautres_au_debut_de_chaque_objectif.md) |
| [BR-SOC-02](BR-SOC-02.md) | découverte de personnes par objectif déclaré | [P027](../Prompts/02_Mise_en_relation/P027_Visibilite_et_decouverte_par_objectif_declare.md) |
| [BR-SOC-03](BR-SOC-03.md) | contact réciproque et communication native | [P028](../Prompts/02_Mise_en_relation/P028_Contact_reciproque_et_communication_native.md) |
| [BR-SOC-04](BR-SOC-04.md) | partage sélectif et activités communes | [P029](../Prompts/02_Mise_en_relation/P029_Partage_cible_groupes_et_activites_communes.md) |
| [BR-SOC-05](BR-SOC-05.md) | retrait, blocage, signalement et modération | [P030](../Prompts/02_Mise_en_relation/P030_Retrait_blocage_signalement_et_ouverture_sure_du_reseau.md) |
