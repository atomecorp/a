# Matrice, projets et interface commune

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §0, lignes 3–18.

## 0. Contexte séparé : modes Liste / Matrice

Un chantier distinct restera à finaliser concernant les **modes de représentation et d’usage**, notamment pour l’audio et les médias :

- mode Liste ;
- mode Matrice ;
- comportement spécifique aux sons, morceaux, clips, pistes et autres médias ;
- règles de lecture, sélection, lancement, regroupement et navigation propres à chaque mode ;
- cohérence avec les vues Song / Structure / Piste et avec les outils temporels.

Ce sujet doit être traité dans un cahier des charges séparé après discussion détaillée afin de ne pas figer prématurément un comportement encore en réflexion.

**Décision complémentaire du 11 octobre 2026.** Ce chantier séparé concerne les comportements spécialisés Liste/Matrice des médias et de l’audio. Il ne remet pas en cause la décision désormais actée pour les **projets, les objectifs et les activités** : leur création, leur exploration et leurs réglages utilisent une **même grammaire de matrices de carrés imbriquées**. Les règles détaillées et les tests correspondants figurent en section 50.

---

---

Source : `Sources/objectives_original.md`, §33, lignes 1107–1144.

# 33. UX : création d’un objectif

L’expérience doit être très simple.

## Entrée principale

L’utilisateur peut écrire :

> Je veux sortir un album.

ou sélectionner :

> Musique → Créer un album

Le système affiche ensuite quelques questions essentielles seulement.

Ne jamais commencer par un formulaire de 40 champs.

Utiliser une révélation progressive.

**Règle de présentation actée le 11 octobre 2026 :** cette révélation progressive se fait par **matrices de carrés imbriquées** et **extension temporaire d’un carré** pour ses réglages (section 50), et non par un empilement de panneaux ou de formulaires rectangulaires sans cohérence avec la matrice.

### Exemple

**Objectif : créer un album**

Questions initiales :

- Combien de morceaux ?
- Les morceaux existent-ils déjà ?
- Seul ou en équipe ?
- Date cible ?
- Budget approximatif ?

À partir de ces réponses, le moteur construit le parcours.

---

---

Source : `Sources/objectives_original.md`, §34, lignes 1145–1175.

# 34. UX : écran principal d’un objectif

L’utilisateur doit voir en priorité :

1. objectif ;
2. progression ;
3. prochaine action ;
4. blocages ;
5. prochain jalon ;
6. date cible ;
7. actions urgentes.

Les détails complets doivent rester accessibles sans encombrer l’interface.

**Présentation commune :** les projets, les entrées d’activité et les composants consultables depuis cet écran restent organisés dans la matrice native d’atome ; les sous-niveaux et les paramètres suivent les interactions décrites en section 50. Les vues de travail spécialisées restent possibles si leur fonction le justifie, sans créer un second langage d’interface.

Vues possibles :

- Aujourd’hui ;
- Prochaines étapes ;
- Timeline ;
- Étapes ;
- Ressources ;
- Équipe ;
- Budget ;
- Notes ;
- Historique ;
- Maintien.

---

---

Source : `Sources/objectives_original.md`, §50.1, lignes 1567–1574.

## 50.1. Principe visuel universel : la matrice d'atome

- **Une même matrice, faite de carrés**, sert à présenter les projets, à créer un nouveau projet, à choisir un objectif, à sélectionner une brique, à explorer des sous-catégories et à accéder aux activités.
- Chaque **carré** correspond à un objet ou une action réelle et identifiable : projet, objectif, activité, brique réutilisable, choix ou réglage. Sa position suit la grille, pas un placement arbitraire de cartes, fenêtres ou rectangles.
- Les **mêmes carrés, proportions, teintes, icônes et composants natifs** sont réutilisés d'un contexte à l'autre. Le contenu change selon l'objectif, mais **pas la grammaire d'interface**.
- **Une sélection peut ouvrir une nouvelle matrice plus profonde** : objectif → briques proposées → catégorie → activité → paramètres. On doit pouvoir revenir au niveau précédent, reprendre une configuration et retrouver le contexte sans perdre les choix déjà validés.
- Il ne faut pas substituer une interface de gestion conventionnelle, des panneaux de réglages autonomes ou des formulaires rectangulaires hétérogènes à la matrice. Les autres modes d'affichage spécialisés (Liste, Timeline, etc.) peuvent exister lorsqu'ils remplissent un besoin fonctionnel précis ; **le flux commun de sélection, de composition et de configuration repose sur la matrice**.

---

Source : `Sources/objectives_original.md`, §50.2, lignes 1575–1596.

## 50.2. Interaction normalisée d'un carré : ouvrir, régler, refermer

Deux comportements complémentaires utilisent **le même élément de matrice**.

**A. Carré de navigation ou de composition**

1. À l'état de repos, l'élément est un **carré de la matrice**.
2. Un appui sur le carré ouvre la **matrice fille** liée à son véritable objet ou outil (par exemple Sport → Natation).
3. Les choix sont conservés pendant la navigation ; retour et validation ne créent pas de doublon.

**B. Carré portant une valeur ajustable** (par exemple **Effort souhaité / rythme**, **Temps disponible**, puis durée, fréquence et paramètres pertinents de l'activité)

1. À l'état de repos, le réglage est présenté par **un carré**, cohérent avec toutes les autres briques.
2. Au toucher/clic, **le carré lui-même s'agrandit dans la grille** et devient temporairement **rectangulaire** en occupant deux, voire **trois emplacements de carrés** selon l'espace nécessaire ; dimensions et alignements restent calculés en unités de la matrice, pas au pixel arbitraire.
3. **Le curseur (slider) natif** ou le réglage réellement disponible apparaît **à l'intérieur de cette brique agrandie**, sans ouvrir un panneau flottant, une fenêtre modale ni un duplicata du réglage.
4. L'utilisateur ajuste la valeur, puis valide/termine l'interaction. Le contrôle **enregistre la valeur sur le véritable objet concerné** et **se referme pour redevenir un carré** dans la matrice. La valeur retenue reste consultable lors d'une nouvelle ouverture ; un affichage synthétique peut être présent seulement s'il est utile.
5. Les autres carrés doivent se **repositionner proprement** lorsque la cellule s'étend et se referme, sans chevauchement, saut incohérent, perte de sélection ou déformation de la grille.

**Règle d'unification :** les carrés ne sont pas des icônes décoratives. Ils contiennent ou ouvrent **les outils et options réels d'atome**. Les paramètres natifs restent associés à leur outil, pas recréés dans une interface parallèle.

Pour un projet, les deux réglages transversaux de départ sont notamment **Effort souhaité / rythme** et **Temps disponible**. Ils emploient la même interaction d'extension du carré ; ne pas créer de troisième curseur obligatoire sans besoin validé. La correspondance exacte des valeurs, des unités (jour/semaine), des bornes et de l'effet du réglage doit être raccordée aux règles communes du projet, puis vérifiée.

---

Source : `Sources/objectives_original.md`, §50.3, lignes 1597–1603.

## 50.3. Entrée commune : voir ses projets et en créer un

- **Les projets existants sont présentés sous forme de carrés dans une matrice.** Le projet sélectionné permet d'entrer dans sa propre matrice.
- La **création d'un nouveau projet** emprunte la même matrice que les projets existants ; ses propositions, objectifs, paramètres initiaux et étapes de configuration ne sont pas dispersés en rectangles sur l'écran.
- La matrice reste la structure perceptible sur téléphone, tablette et ordinateur. L'extension d'un carré s'adapte à la largeur disponible sans abandonner les unités de grille. Les états sélectionné, ouvert, en cours et validé sont explicites sans surcharger l'écran.
- Navigation et réglages doivent rester accessibles via les moyens d'interaction pris en charge (toucher, souris, clavier et technologies d'assistance selon plateforme). Pas de fonctionnalité réservée à une animation purement visuelle.

---

Source : `Sources/objectives_original.md`, §50.5, lignes 1633–1641.

## 50.5. Entrée indépendante « Activités » : mêmes briques, même matrice

- Prévoir un **espace « Activités »** accessible directement, sans obligation de passer par un objectif ou son Dashboard.
- L'espace présente une **matrice de catégories de briques** : notamment **Sport**, **Nutrition**, **Compléments alimentaires**, **Méditation** et **Relaxation**, selon les activités réellement disponibles. Exemple : **Activités → Sport → Natation → Durée / paramètres → Démarrer**. « Compléments alimentaires » constitue une entrée explicite ; elle peut aussi être atteinte depuis Nutrition sans dupliquer la brique.
- Chaque niveau ouvre la matrice plus spécifique correspondante ; les valeurs se règlent dans les **carrés temporairement étendus** décrits en 50.2.
- L'activité **utilise exactement la même brique fonctionnelle** que dans le scénario Mieux dormir, Perdre du poids ou Condition physique. Ne pas créer de version « natation sommeil » et une autre « natation libre » avec deux implémentations.
- Elle peut être démarrée librement ou associée à un projet après accord. Le suivi et les éventuelles données personnelles suivent les autorisations de l'utilisateur, même hors projet.
- Les **compléments alimentaires** suivent ce même fonctionnement : choisir une proposition facultative ou **saisir manuellement** un complément, le configurer dans la matrice, puis l'utiliser de manière autonome ou le rattacher à un projet. Les modalités détaillées et les garde-fous figurent en **50.8**.

---

Source : `Sources/objectives_original.md`, §50.6, lignes 1642–1649.

## 50.6. Transversalité des briques et responsabilité des outils

- **Une bibliothèque de briques fonctionnelles réutilisables** est la source de vérité. Une brique peut servir plusieurs projets, et certaines briques peuvent contenir d'autres briques ; elle n'est jamais une collection de copies d'écrans indépendants.
- Les **scénarios** sélectionnent, configurent et assemblent ces briques ; la **matrice** les rend accessibles ; les **outils natifs** exécutent l'action ; le **calendrier** possède les occurrences ; le **Moniteur** interprète les observations. Ces responsabilités ne doivent pas être dupliquées.
- Une activité partagée n'est **réalisée ni comptée deux fois** ; ses relations à plusieurs projets sont explicites et révocables. Deux projets peuvent toutefois conserver des critères de réussite distincts. Ce principe vaut aussi pour le suivi d'un complément alimentaire utilisé dans plusieurs objectifs.
- Les modules de santé restent privés par défaut ; collecte de capteurs, partage et transmission nécessitent les permissions adaptées. Aucune suggestion d'IA ne vaut validation implicite d'une activité, d'un achat, d'un rendez-vous ou d'un partage.
- Conserver les composants et connexions réellement présents dans atome/eVe ; inventorier la matrice, les outils, les curseurs, les calendriers, alarmes, capteurs et le Moniteur avant de les connecter. Privilégier **JavaScript** dans le code eVe existant ; ne pas introduire une architecture d'interface concurrente.
