# Résultats, suivi et contrats de données

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §29, lignes 1018–1043.

# 29. Ressources et fichiers

Chaque étape doit pouvoir attacher :

- atomes ;
- documents ;
- images ;
- audio ;
- vidéo ;
- liens ;
- notes ;
- contacts ;
- conversations ;
- rendez-vous ;
- budgets ;
- lieux ;
- équipements ;
- versions ;
- livrables.

Le système d’objectifs ne doit pas créer un silo séparé.

Il doit orchestrer les objets déjà présents dans atome/eVe.

---

---

Source : `Sources/objectives_original.md`, §50.10, lignes 1732–1757.

## 50.10. Examens, bilans et résultats de toute nature — une brique « Résultats » universelle

**Décision complémentaire du 11 octobre 2026 : il ne s'agit pas uniquement de bilans sanguins.** Créer ou raccorder **une brique fonctionnelle transversale « Résultats »**, utilisable par les projets de santé **et, lorsque pertinent, par les autres projets et activités**. Un bilan est un cas particulier d'un résultat, pas une nouvelle base de données propre au sang.

**Exemples non exhaustifs de contenus à mémoriser :** analyses sanguines, urinaires ou autres analyses biologiques ; comptes rendus médicaux ; résultats d'imagerie et documents associés (radiologie, échographie, IRM, etc.) ; explorations cardiaques ou respiratoires ; évaluations physiques et sportives ; poids, tension et autres mesures ponctuelles ; relevés de capteurs ; questionnaires, scores, observations et ressentis ; résultats d'un test, d'un examen, d'une consultation ou de toute autre activité. **Les données qualitatives, les textes et les documents sont aussi des résultats**, même lorsqu'aucune valeur numérique ou tableau CSV n'existe.

**Deux responsabilités distinctes et reliées :**

1. **Agenda** — proposer des dates et rappels pour analyses, examens, bilans périodiques, consultations, bilans avec le médecin et revues de programme ; gérer répétitions, reports et annulations **selon les choix de l'utilisateur**. Un examen planifié **n'est pas** un résultat reçu.
2. **Résultats** — lorsqu'un document ou une mesure est reçu, **enregistrer et retrouver durablement le contenu et son historique**, qu'il soit lié ou non à un événement du calendrier. Ce stockage ne se réduit pas à l'alarme, au rendez-vous ni au projet Dashboard.

**Parcours matriciel de la brique :**

`Activités / Projet → Examens et résultats → Type de résultat / examen → Planifier OU Ajouter un résultat → Source / fichier / valeurs → Vérifier → Enregistrer → Consulter les évolutions`

- Accès à cette **même brique** depuis plusieurs objectifs (sommeil, condition physique, prise de masse, etc.) et par la matrice autonome Activités ; aucune base de résultats indépendante par scénario.
- **Import possible d'un fichier reçu** (ex. PDF, CSV, document, image, selon formats réellement pris en charge), ou **saisie manuelle** des valeurs et observations. Conserver **l'original sans altération** en plus de toute extraction structurée. Les documents complexes, visuels et annexes doivent rester consultables, sans tentative de les réduire artificiellement à une cellule CSV.
- Pour les **données structurables**, mémoriser chaque observation avec au minimum : identifiant stable ; date et heure de mesure ou prélèvement ; date de réception si différente ; type d'examen/activité ; paramètre ou nature du résultat ; **valeur et unité si applicable** ; intervalle de référence et méthode lorsque disponibles ; contexte ; source et auteur/professionnel quand connus ; document d'origine ; type de saisie (manuelle, importée, instrumentée) ; statut de vérification ; rattachement facultatif à un ou plusieurs projets.
- Pour les **résultats non numériques**, conserver le document, le texte, l'image, la pièce jointe ou la qualification avec ses métadonnées, sans inventer de valeur. Une extraction automatique éventuelle reste une **proposition à vérifier**, jamais une donnée médicale « certifiée » par simple lecture automatique.
- Offrir un **format structuré exportable en CSV** pour les séries et tableaux qui s'y prêtent, avec colonnes explicites, unités, dates et références de source ; un autre format structuré peut être nécessaire en stockage natif pour préserver les types, métadonnées, références et pièces jointes. **CSV n'est ni le seul format ni un substitut au document original.** Pas de conversion destructive.
- Conserver **tous les résultats successifs et leurs versions** afin d'afficher l'évolution d'un même paramètre ou d'une même performance dans le temps. Vérifier **unités, méthodes, conditions et comparabilité** avant toute courbe ou comparaison ; présenter une incertitude ou une rupture de série lorsqu'elle existe. Un changement de document ou une correction ne doit pas effacer silencieusement la valeur historique.
- Le **Moniteur commun** agrège les observations **autorisées**, garde la provenance de chaque donnée et sépare fait observé, ressenti, interprétation et hypothèse. Un résultat hors normes peut justifier une invitation à consulter ; **aucun diagnostic ni changement de traitement ou de complément n'est décidé automatiquement**.
- **Données privées par défaut** : autorisations de collecte et d'import, contrôle d'accès par document/valeur, partage explicite vers un professionnel ou un proche, traçabilité des corrections et export, respect des capacités et garanties réelles de stockage/chiffrement d'atome à auditer. Une notification ne révèle pas un résultat médical sensible sur écran verrouillé.

**Lien avec les activités sportives :** une séance de natation peut générer des résultats de longueurs, de temps et de distance ; une séance de musculation des séries, répétitions et charges ; un laboratoire un compte rendu et plusieurs paramètres. Ils sont de **natures différentes mais suivent le même principe de traçabilité, d'import éventuel, de stockage et d'historique**. Réutiliser les objets d'observation existants si leur modèle le permet, sans fabriquer une API ou un système concurrent.

---

Source : `Sources/objectives_original.md`, §50.11, lignes 1758–1767.

## 50.11. Compléments alimentaires, agenda et bilans réguliers — règles de liaison

Cette sous-section complète **50.8** et **50.10** sans créer une troisième application de suivi.

- **Compléments alimentaires** : depuis leur carré dans Activités, l'utilisateur peut sélectionner un produit proposé **ou le saisir manuellement**, renseigner **quantité/dose et unité** telles qu'indiquées par le produit, le prescripteur éventuel ou l'utilisateur, ainsi qu'horaires, jours, fréquence, durée et notes. Distinguer **dose déclarée**, **prise planifiée** et **prise réellement notée** ; pas de posologie imposée par défaut par l'IA.
- **Calendrier commun** : après accord, créer des occurrences pour les horaires de prise, ainsi que des rendez-vous de suivi, **bilans périodiques et consultations médicales**. Le rappel n'atteste ni la prise d'un complément ni la réalisation d'un examen. Reporter une occurrence modifie les rappels liés sans perdre les prises et bilans antérieurs.
- **Réception du bilan** : au retour d'un médecin, laboratoire ou autre prestataire, importer le **compte rendu original** et/ou saisir les observations dans la **brique Résultats**, avec date de réalisation, type d'examen, valeurs mesurées, unités et source lorsque disponibles. Le lien avec l'événement du calendrier est facultatif mais conservé s'il existe.
- **Suivi longitudinal** : le Moniteur peut rapprocher l'historique des prises **déclarées** et celui des résultats (biologiques ou non) pour les présenter côte à côte. **Une concomitance ne démontre pas une causalité** et ne déclenche pas automatiquement une recommandation de dosage ou de traitement. Les professionnels restent responsables des décisions médicales.
- **Scénarios transversaux** : la même brique Résultats peut documenter une prise de masse, une amélioration du sommeil, une évaluation de douleur, un contrôle périodique ou un projet hors santé, dans les limites des autorisations et sans compter deux fois le même examen.

---

Source : `Sources/objectives_original.md`, §51.23, lignes 2291–2301.

## 51.23. Examens, prévention, compte-rendus et résultats : prolongement universel

- **Brique `BR-SUI-04`** : `Prévention / Examen demandé par médecin / Consultation / Contrôle personnalisé → Choisir créneau → Confirmer → Agenda`. En France, le dispositif **« Mon bilan prévention »** propose des plages d'âge spécifiques (18–25, 45–50, 60–65 et 70–75 ans), **non une analyse sanguine annuelle imposée à toute personne** [S17]. Les recommandations de dépistage et périodicités doivent être reliées à la situation et aux recommandations officielles à jour.
- **Brique `BR-SUI-05`** : `Résultats → Importer [PDF / image / CSV / données instrumentées / texte / audio / autre format accepté] OU Saisir → Vérifier → Enregistrer → Lier à un examen / activité / objectif`. Conserver le **fichier source inchangé**, son propriétaire, la date, le professionnel ou appareil, les unités et méthodes, puis les valeurs structurées **lorsqu'elles existent**. Conserver aussi les rapports *qualitatifs* (diagnostic rédigé par un professionnel, commentaires, descriptions d'imagerie), sans tenter de les « réduire à un CSV ».
- **Séparer les niveaux** : compte rendu original / valeurs extraites automatiquement **non vérifiées** / valeurs relues par l'utilisateur / observation instrumentée / avis signé d'un professionnel. Ne pas mettre « normal » ou « anormal » sans plage adaptée et origine clairement reliées au laboratoire/clinicien ; la plage peut dépendre du sexe biologique, de l'âge, de la méthode et de la situation.
- **Export** : CSV UTF-8 structuré pour données tabulaires (`observation_id`, `patient_id_local`, `recorded_at`, `measured_at`, `test_name`, `analyte_or_metric`, `value`, `unit`, `reference_interval`, `method`, `source_id`, `verification_status`, `project_links`, `original_document_id`) ; ne pas supposer qu'un CSV est une base de données de santé suffisante. Utiliser un stockage natif typé pour versions, documents, métadonnées et droits. Ne jamais inclure de données personnelles identifiantes dans une exportation non demandée.
- **Vie privée** : chiffrement et permissions **à auditer dans l'architecture réelle**, accès privé par défaut, suppression/export réglementaires, absence de partage implicite, journal des corrections. Les résultats associés à plusieurs objectifs **ne sont pas copiés**, ce sont des références vers un résultat unique avec droits indépendants.
- **Moniteur** : séries temporelles comparables seulement quand unités, méthodes et conditions permettent l'analyse ; séparation **mesuré / déclaré / calculé / interprété**. « Absence de résultat » ≠ « résultat négatif ». Une anomalie, une variation ou un rapport complexe **n'est pas un diagnostic automatique**. Dépistages et décisions thérapeutiques nécessitent des professionnels.

**Exemple complet** : une consultation est proposée pour un contrôle indiqué, acceptée dans l'agenda ; le médecin prescrit un examen ; l'utilisateur importe ensuite un PDF de laboratoire et, s'il le souhaite, une mesure de tension issue d'un appareil. Le système **conserve les deux sources d'origine**, normalise seulement les données approuvées, propose un graphique des valeurs comparables et permet un export CSV de la série. Il **n'en déduit pas automatiquement** une dose de zinc ou de vitamine D.

---

Source : `Sources/objectives_original.md`, §51.25, lignes 2332–2355.

## 51.25. Contrats de données et événements : assemblage de modules existants, sans duplication

**Ce tableau est un modèle conceptuel à confronter au code et aux outils réels**. Il ne déclare ni endpoint, ni protocole, ni méthode d'API d'atome/eVe disponible.

| Entité | Champs indispensables ou comportements | Relations et source de vérité |
| --- | --- | --- |
| **Projet-objectif** | `id`, `objective_code`, intention, propriétaire, état, critères, versions du programme, confidentialité | Un projet peut relier plusieurs briques ; la matrice du projet le présente. |
| **Brique référentielle** | `brick_id`, version, paramètres admis, unités, risques, références, outil natif compatible | Fiche unique commune au projet et au panneau **Activités**. |
| **Activité configurée** | `activity_id`, `brick_id`, paramètres enregistrés, préférences, provenance et version | Peut être indépendante ou associée à plusieurs objectifs. |
| **Séance composée** | `session_id`, activités ordonnées, segments, état, horaires, pauses, corrections | Réutilise les activités configurées, sans copies de programmes par discipline. |
| **Occurrence de calendrier** | `occurrence_id`, `activity_id`, date, heure, durée, récurrence, fuseau, état, rappel | **Calendrier commun** ; événement planifié ≠ activité accomplie. |
| **Événement d'exécution** | `event_id`, `session_id`, étape, horodatage, action `start/pause/complete/correct/stop`, auteur | Une série ou longueur achevée par appui n'est pas une mesure automatique. Historique append-only ou journal d'audit équivalent à vérifier. |
| **Observation / mesure** | `observation_id`, `source`, type `déclaré/mesuré/calculé`, valeur et unité facultatives, contexte, date, précision si disponible | Résultats partagés par références, **provenance obligatoire**. |
| **Document original** | `document_id`, type, intégrité, version, source, date, autorisations | PDF, image, texte, audio, compte-rendu, rapport sport ; conservation non destructive. |
| **Produit/complément** | `product_id`, concentration, portion, composition, source, dose déclarée, horaires, lots et changements | Occurrences et prises déclarées distinctes, pas de conseil clinique implicite. |
| **Professionnel / rendez-vous** | Relation contact existante, rôle, horaire, statut rendez-vous, partage permis | Réutilise Contacts + Calendrier, sans inventer de prise de rendez-vous externe. |
| **Moniteur** | Agrégation de résultats autorisés et historisés, objectifs correspondants, comparabilité, réserves d'interprétation | Ne crée pas de données biologiques et n'effectue pas de diagnostic. |

**Règles d'intégrité** : une occurrence ne peut pas être simultanément `non démarrée` et `terminée` ; une correction conserve l'ancienne valeur et son auteur ; une même longueur, série ou prise ne doit pas compter deux fois ; dédoublement entre import Health et saisie utilisateur à examiner avec consentement, sans supprimer silencieusement un élément. Une action planifiée partagée entre deux objectifs conserve **un seul identifiant d'événement** et plusieurs rattachements de projet. Une modification rétroactive d'une fiche machine n'altère pas l'exercice historiquement réalisé sur cette machine.

**Adaptation UI** : carrés de matrice **natifs**, pas cards génériques ; extension 2–3 unités, slider ou contrôle natif dans le carré, fermeture puis conservation de la valeur ; hiérarchie navigable avec retour, reprise, focus accessible et commandes de véritable outil. Sur petit écran, le redéploiement doit conserver lisibilité, surfaces tactiles et grille. Aucun pop-up requis pour un réglage courant. Dans un état d'exécution (natation, musculation, journal), afficher **l'outil fonctionnel** avec ses contrôles, pas une simple icône de projet.

**Contraintes d'implémentation** : utiliser **JavaScript** et l'architecture vérifiée d'eVe ; composants Bevy/Canvas, calendrier, Moniteur, Finder, outils texte/audio/vidéo, permissions et connexions MCP à inventorier avant raccordement. Ne pas créer un « moteur santé » concurrent du calendrier ou du stockage atome. Ne pas prétendre que HealthKit, Health Connect, les capteurs sous WebView, les alarmes profondes iOS, une base nutrition ou une API médicale sont opérationnels tant que l'environnement ne l'a pas confirmé. Supporter fonctionnement dégradé sans ces intégrations.
