# Valeurs, preuve et revue clinique

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §51.5, lignes 1892–1913.

## 51.5. Repères scientifiques communs et politique des valeurs

Les valeurs suivantes sont **des références de santé publique ou des exemples d'interface**, jamais un programme délivré sans contexte. Chaque valeur affichée par eVe doit porter un **type** : `repère scientifique`, `exemple de saisie`, `préférence utilisateur`, `recommandation du professionnel`, `mesure enregistrée` ou `hypothèse à confirmer`.

| Sujet | Repère utilisable avec ses limites | Source et règle d'usage |
| --- | --- | --- |
| **Sommeil adulte** | **7–9 heures par nuit** comme ordre de grandeur populationnel ; variations selon âge et situation. | NIH/NHLBI [S03] ; ne pas pousser artificiellement une personne à « faire » neuf heures ni extrapoler un stade profond de montre grand public. |
| **Activité aérobie adulte** | **150–300 min/semaine modérée**, ou **75–150 min soutenue**, et **renforcement ≥2 jours/semaine** à terme ; **toute activité compte** au départ. | OMS [S01] ; **objectif de population, pas minimum imposé à un débutant** ou une personne malade. |
| **Alimentation générale >10 ans** | **≥400 g de fruits et légumes/jour**, **≥25 g de fibres alimentaires/jour** comme repères de population. | OMS [S02] ; attention aux régimes thérapeutiques, troubles digestifs et tolérance. |
| **Perte de poids** | Adaptation nutritionnelle individualisée ; si réduction calorique indiquée, déficit approprié et suivi ; aucun seuil standard d'apport énergétique ou cadence automatique. | NICE NG246 [S04] ; dépister restrictions dangereuses et troubles alimentaires avant le scénario. |
| **Entraînement de résistance** | Activités progressives, adaptées aux préférences et aux capacités ; force et hypertrophie possibles avec plusieurs stratégies. | ACSM **2026** [S05] ; ne pas imposer 5×5, l'échec musculaire, le test de charge maximale, ni la même dose à tous. |
| **Protéines et activité** | Chez les **adultes physiquement actifs en bonne santé**, plage de référence pour gains/maintien musculaires **1,4–2,0 g/kg de masse corporelle/jour**. | ISSN [S06] ; pas de cible universelle, prudence et validation pour maladie rénale ou autres contraintes médicales. L'alimentation demeure prioritaire. |
| **Créatine** | **Créatine monohydrate**, parmi les suppléments ayant des données sur la performance de force/effort bref ; **3–5 g/j** est une quantité *étudiée* chez des adultes, **pas une dose prescrite par atome**. | NIH ODS [S07]. Présenter seulement comme **option à examiner**, avec contre-indications/interactions et validation appropriée. |
| **Vitamines/minéraux** | Corriger une insuffisance identifiée ou un risque nutritionnel documenté ; **B12** si alimentation végétalienne inadaptée sans supplémentation, **fer** seulement avec indication, **vitamine D** selon situation clinique. | NIH ODS [S08] ; éviter les tests biologiques et suppléments systématiques, surdosage et interactions. |
| **Douleur chronique** | Évaluation centrée sur la personne ; exercice *adapté* et approches psychologiques peuvent contribuer dans des contextes choisis. | NICE NG193 [S09] ; douleur nouvelle/intense ou drapeau rouge → soins, pas exercices automatiques. |
| **Insomnie chronique** | **TCC-I multicomposante** recommandée comme prise en charge de première intention ; l'« hygiène du sommeil » isolée n'est pas suffisante. | AASM [S10] ; les restrictions de sommeil thérapeutiques nécessitent un cadre approprié, pas un calcul autonome de l'app. |
| **Santé mentale** | Activités, accompagnement psychologique et, selon le trouble, traitements médicaux ; chemin de soin selon symptômes/gravité. | NICE [S11] / OMS [S12]. Une app ne remplace pas une évaluation clinique. |
| **Vieillissement cutané** | Photoprotection large spectre **SPF ≥30** et mesures contre les UV utiles pour limiter le photovieillissement. | AAD [S13] ; les traitements dermatologiques plus actifs relèvent d'une discussion spécialisée. |
| **Vieillir en bonne santé** | Préserver **capacités fonctionnelles**, autonomie, santé sociale et mentale ; pas d'équivalence avec « retrouver un âge biologique de 25 ans ». | OMS [S14]. Les produits anti-âge expérimentaux ne deviennent pas des routines recommandées. |

**Règles complémentaires :** vérifier unité et contexte de chaque mesure ; ne jamais convertir une estimation d'IA en donnée de laboratoire ; ne jamais afficher un objectif de poids, une dose de supplément, une intensité d'exercice ou une fréquence d'examen médical comme « adaptée » sans les informations requises. Un programme sérieux peut ne contenir **aucun complément alimentaire** et **aucun bilan sanguin ajouté**.

---

Source : `Sources/objectives_original.md`, §51.6, lignes 1914–1921.

## 51.6. Règles de personnalisation des douze scénarios

Pour chacun : **Entrée → données minimales → briques suggérées → matrices de configuration → validation → programme daté → action au premier plan → résultat → adaptation**. Les questions dépendent des briques effectivement envisagées ; l'application n'oblige pas à saisir le poids pour méditer ni son humeur pour courir. Le programme propose en priorité des changements **observables, réalisables et réversibles**. Les activités et mesures importantes doivent pouvoir être importées ou saisies manuellement sans capteur ni abonnement à un fabricant.

Les niveaux de recommandation visibles *sur demande* (pas nécessairement en texte sur chaque carré) : **A — pratique soutenue par recommandations solides pour la situation** ; **B — option raisonnable mais bénéfice ou application variable** ; **C — expérimental, efficacité non établie, non proposé comme routine** ; **P — prescrit par un professionnel identifié**. La provenance scientifique et la date de vérification sont conservées. Un classement A sur une activité générale ne prouve jamais qu'elle est indiquée pour cet utilisateur. Une nouvelle étude ou un avis professionnel peut entraîner la révision de la bibliothèque sans effacer les programmes historiques.

**Sorties communes** : chaque scénario détaille son critère principal (*par exemple amélioration de la fonction diurne pour le sommeil plutôt que « HRV parfaite »*), un ou deux indicateurs facultatifs, des conditions d'alerte et un rendez-vous de revue. L'utilisateur peut arrêter son projet sans perdre les données qu'il choisit de conserver.

---

Source : `Sources/objectives_original.md`, §51.28, lignes 2399–2421.

## 51.28. Sources scientifiques et référentiels de conception (vérification : 11/10/2026)

La bibliographie est **publique et accessible** pour revue clinique ultérieure. Les lignes citées ne valident pas un protocole individualisé ni chaque valeur purement UX de ce cahier. Les recommandations évoluent ; la date de révision doit rester attachée à la brique concernée.

- **[S01] OMS** — *Guidelines on physical activity and sedentary behaviour* (2020) ; recommandations adultes et renforcement. https://www.who.int/europe/news-room/fact-sheets/item/physical-activity
- **[S02] OMS** — *Alimentation saine* (fiche révisée en 2026, alimentation et fibres). https://www.who.int/fr/news-room/fact-sheets/detail/healthy-diet
- **[S03] NIH/NHLBI** — *How Much Sleep Is Enough?* (2022). https://www.nhlbi.nih.gov/health/sleep/how-much-sleep
- **[S04] NICE** — *Overweight and obesity management, NG246*, recommandations sur l'alimentation et les approches durables (2025). https://www.nice.org.uk/guidance/ng246/chapter/Physical-activity-and-diet
- **[S05] American College of Sports Medicine (ACSM)** — *Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults: An Overview of Reviews* (2026). https://pubmed.ncbi.nlm.nih.gov/41843416/
- **[S06] International Society of Sports Nutrition** — *Position stand: protein and exercise* (2017). https://pubmed.ncbi.nlm.nih.gov/28642676/
- **[S07] NIH Office of Dietary Supplements** — *Dietary Supplements for Exercise and Athletic Performance*, fiche professionnelle, créatine et preuves. https://ods.od.nih.gov/factsheets/ExerciseAndAthleticPerformance-HealthProfessional/
- **[S08] NIH Office of Dietary Supplements** — *Dietary Supplements: What You Need to Know* (risques et interactions) ; fiches B12, D et fer. https://ods.od.nih.gov/HealthInformation/healthinformation.aspx ; https://ods.od.nih.gov/factsheets/VitaminB12-HealthProfessional/ ; https://ods.od.nih.gov/factsheets/VitaminD-HealthProfessional/ ; https://ods.od.nih.gov/factsheets/Iron-HealthProfessional/
- **[S09] NICE** — *Chronic pain (primary and secondary) in over 16s, NG193* (2021). https://www.nice.org.uk/guidance/ng193/chapter/recommendations
- **[S10] American Academy of Sleep Medicine** — *Behavioral and psychological treatments for chronic insomnia disorder in adults: clinical practice guideline* (2021), recommandation forte de TCC-I. https://pmc.ncbi.nlm.nih.gov/articles/PMC7853203/
- **[S11] NICE** — *Depression in adults: treatment and management, NG222* (2022). https://www.nice.org.uk/guidance/ng222/chapter/Recommendations
- **[S12] OMS** — *Principaux repères sur la dépression* (consultation et traitements psychologiques). https://www.who.int/fr/news-room/fact-sheets/detail/depression
- **[S13] American Academy of Dermatology** — *11 ways to reduce premature skin aging*, photoprotection. https://www.aad.org/public/everyday-care/skin-care-secrets/anti-aging/reduce-premature-aging-skin
- **[S14] OMS** — *Healthy ageing: functional ability*, objectif de vieillissement en bonne santé. https://www.who.int/health-topics/ageing/transforming-health-and-social-services-towards-a-more-person-centred-and-integrated-care
- **[S15] OMS** — *From loneliness to social connection* (rapport, 2025). https://www.who.int/publications/b/79027
- **[S16] NICE** — *Self-harm: assessment, management and preventing recurrence, NG225* (2022) ; **ne pas utiliser de scores pour prédire le suicide**. https://www.nice.org.uk/guidance/ng225/chapter/recommendations
- **[S17] Assurance maladie (France)** — *Mon bilan prévention*, tranches d'âge couvertes. https://www.ameli.fr/assure/sante/mon-bilan-prevention

**Conclusion opérationnelle de cette section :** douze objectifs **entièrement scénarisés au niveau fonctionnel**, une bibliothèque initiale de briques identifiées et transversales, une matrice Sport extensible aux disciplines/machines/mouvements, un espace Nutrition et Compléments facultatif, et un module commun de Résultats documentés. **Les fiches détaillées de tous les sports mondiaux, les pictogrammes définitifs, les protocoles médicaux individualisés et les intégrations natives restent des travaux de développement/validation**, explicitement listés plutôt que supposés terminés.
