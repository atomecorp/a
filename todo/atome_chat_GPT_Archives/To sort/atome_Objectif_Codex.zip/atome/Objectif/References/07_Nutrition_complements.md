# Nutrition et compléments

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §50.8, lignes 1675–1694.

## 50.8. Compléments alimentaires — brique transversale avec propositions et saisie manuelle

**Décision complémentaire du 11 octobre 2026.** Ajouter « **Compléments alimentaires** » parmi les briques accessibles dans la **matrice du panneau Activités**, au même titre que Sport, Nutrition, Méditation et les autres catégories. Cette brique n'est ni limitée à un objectif de santé ni un outil indépendant recréé pour chaque projet. Une entrée Nutrition peut pointer vers cette **même brique**.

**Deux façons d'entrer dans cette brique :**

1. **Proposition facultative.** eVe peut afficher des compléments à envisager ou à consulter, selon le contexte et les informations disponibles. Une proposition n'est pas une prescription ni un ajout automatique au programme : l'utilisateur choisit de l'examiner, de l'ignorer ou de la valider. Le système ne suppose pas qu'un complément est nécessaire ou bénéfique en l'absence d'éléments suffisants.
2. **Saisie manuelle.** L'utilisateur peut enregistrer **n'importe quel complément qu'il utilise ou souhaite suivre**, même absent des propositions, en saisissant au minimum son **nom**. Si nécessaire, il peut préciser le produit, la forme, les composants, la quantité réellement prise et son unité, les horaires, la fréquence, les notes et la date de début/fin. Les informations non connues restent facultatives ou « non renseignées » ; ne pas inventer une composition ni une quantité.

**Parcours matriciel commun :** `Activités → Compléments alimentaires → Proposition / Saisie manuelle → Complément choisi → Paramètres → Validation`. Chaque élément part d'un carré de la matrice ; si un réglage nécessite davantage de place, le **carré s'étend sur deux ou trois cellules**, révèle les options **réelles** dans sa surface, puis revient à un carré après validation, comme en 50.2. Pour du texte libre (nom d'un produit), employer le composant de saisie natif existant dans cette même grammaire visuelle ; ne pas forcer un slider pour saisir un nom.

**Après validation**, la brique peut :

- être retrouvée dans les **Activités personnelles**, sans nécessiter la création d'un objectif ;
- être liée, avec l'accord de l'utilisateur, à un ou plusieurs projets-objectifs pertinents, **sans duplication de la même fiche ni double comptage** ;
- créer, **uniquement si l'utilisateur le souhaite**, des occurrences dans le calendrier commun, des rappels et un moyen de consigner les **prises effectivement déclarées** (distinctes des prises seulement prévues ou des notifications envoyées) ;
- faire remonter au Moniteur les déclarations et observations autorisées, en conservant source, date, contexte et incertitudes, **sans attribuer automatiquement un effet positif ou négatif** au complément.

**Limites et sécurité :** ne pas proposer de dosage personnalisé, de traitement, d'augmentation de dose ou d'achat automatisé. Distinguer clairement une fiche enregistrée par l'utilisateur d'une suggestion du système, et les informations établies de celles qui sont incertaines. Lorsqu'un risque de contre-indication, d'interaction avec un médicament, de grossesse ou de maladie est pertinent, inviter à une vérification auprès d'un professionnel de santé plutôt que d'automatiser la décision. Le contenu et les historiques restent **privés par défaut**, avec les mêmes règles de consentement que les autres données de santé. Les connexions à une base de données produits, au calendrier et au Moniteur doivent être **vérifiées** avant de déclarer ces capacités implémentées.

---

Source : `Sources/objectives_original.md`, §51.21, lignes 2235–2264.

## 51.21. Nutrition : une matrice d'alimentation adaptée au but, sans « régime magique »

**Navigation** : `Activités / Objectif → Nutrition → [Mes habitudes / Composer un repas / Courses / Protéines / Fibres / Hydratation / Contraintes / Suppléments si utiles] → Sous-brique → Paramètres → Valider`. **Nutrition** et **Compléments alimentaires** sont deux catégories reliées mais **différentes** : on ne suggère pas une pilule lorsqu'un aliment ou un changement de pratique suffit.

### 51.21.1. Structure détaillée d'un repas

`Nutrition → Repas → [Petit-déjeuner / Déjeuner / Dîner / Collation / Avant effort / Après effort / Autre] → [Plat / Protéine / Végétaux / Accompagnement / Boisson / Contraintes] → Choix → Portions facultatives → Temps de préparation → Jours → Agenda`.

- Le carré **repas** peut représenter une activité de cuisine, un **rappel de repas choisi** ou une observation déclarée. Il ne présume ni trois repas obligatoires ni horaires universels.
- Les sous-briques `Céréales/féculents`, `Légumes`, `Fruits`, `Légumineuses`, `Produits protéiques`, `Produits laitiers ou alternatives`, `Matières grasses`, `Boissons` sont des **éléments alimentaires reconfigurables**, pas des injonctions de manger un produit déterminé. Allergies, culture, convictions, budget, textures et tolérance sont pris en compte.
- Réglages à exposer **seulement si l'utilisateur les veut** : portions ou unité, grammes estimés, fréquence, durée de préparation, liste d'achats, origine de recette et éventuelles valeurs nutritionnelles **sourcées**. Un nombre d'énergie/protéines estimé depuis une photo n'est pas traité comme un dosage clinique mesuré.
- `BR-NUT-03/05` peut proposer, si pertinent, l'augmentation graduelle de la variété végétale et des fibres avec les **repères OMS ≥400 g de fruits/légumes et ≥25 g de fibres/jour** pour la population concernée [S02], **sans imposer ce palier** à une personne ayant une contre-indication digestive ou un régime prescrit.
- `BR-NUT-07` demande si un besoin spécifique existe (forte chaleur, exercice prolongé, restriction médicale hydrique, etc.) ; **ne pas imposer « boire X litres » à tout le monde**. Pour certaines maladies, fluides et électrolytes relèvent d'un conseil médical.

### 51.21.2. Adaptation nutritionnelle selon l'objectif

| Objectif pertinent | Focus nutritionnel scientifiquement justifiable | Briques à ne pas imposer |
| --- | --- | --- |
| **OBJ-01 Poids** | Habitudes soutenables, équilibre alimentaire, portions et contexte ; déficit énergétique **individualisé uniquement si indiqué**, soutien diététique si besoin [S04]. | Jeûne intermittent, apport calorique universel, restriction drastique, « brûle-graisse ». |
| **OBJ-03 Masse musculaire** | Énergie suffisante, protéines alimentaires ; référence scientifique 1,4–2,0 g/kg/j chez adulte sain actif **si pertinent et validé** [S06]. | Whey si apport alimentaire suffisant, hyperprotéine en cas de contre-indication, suppléments anabolisants. |
| **OBJ-02 Sommeil** | Si inconfort ou stimulant pertinent : horaires et nature des consommations, caféine, gêne digestive nocturne. | Régime du sommeil, coupure arbitraire de glucides, suppléments soporifiques. |
| **OBJ-09 Condition** | Repas variés et appropriés à l'activité ; récupération énergétique proportionnée si pratique sportive. | Régimes d'endurance extrêmes, compléments « booster » systématiques. |
| **OBJ-10 Vieillir en santé** | Qualité, variété, éventuels besoins liés à l'âge ou déficits identifiés, maintien des capacités. | « Nutrition anti-âge » garantissant un rajeunissement, hormones, produits expérimentaux. |
| **OBJ-04 Douleur / OBJ-05 Trouble** | Seulement les adaptations nutritionnelles **réellement indiquées** par la situation et un professionnel. | « Régime anti-inflammatoire universel », bilan nutritionnel sans motif. |
| **OBJ-11 Bien-être / OBJ-12 Santé mentale** | Alimentation équilibrée soutenable si la personne le souhaite ; prise en compte des difficultés alimentaires et des soins. | Promesse de traiter une dépression par un régime ou complément seul. |

**Exemple de composition** : `Prise de muscle → Nutrition → Protéines → Sources alimentaires / Préparation de repas → Nombre de jours → Valider`. Si l'apport estimé paraît insuffisant, la personne peut demander des alternatives culinaires ou **examiner une protéine en poudre** ; le programme distingue clairement `repère général`, `consommation déclarée`, `recommandation du diététicien`, `supplément choisi`. L'application n'invente ni son poids, ni ses besoins, ni son bilan biologique.

**Exécution** : au rappel « préparer le repas », ouvrir la fiche réelle de la recette/liste ; au retour « je l'ai préparé » ou « remplacé par… », consigner uniquement la déclaration, sans inventer une ingestion. Les personnes avec trouble alimentaire connu ou suspecté doivent recevoir un parcours adapté, supervisé ; éviter la gamification des calories ou du poids.

---

Source : `Sources/objectives_original.md`, §51.22, lignes 2265–2290.

## 51.22. Compléments alimentaires : catalogue facultatif, saisie libre et suivi sûr

**Parcours matriciel :** `Activités → Compléments alimentaires → [Ajouter / Déjà utilisé / Consulter / Planifier / Historique] → Famille → Produit réel → Dose déclarée → Heure/jour/fréquence → Vérifier / Valider → Agenda`.

**Distinguer toujours quatre états** : `(a) produit présent dans le catalogue`, `(b) produit envisagé`, `(c) produit réellement utilisé selon déclaration`, `(d) produit recommandé/prescrit par professionnel documenté`. Un nom de produit dans une matrice **n'est pas une recommandation** et n'entraîne jamais de prise.

| Famille/fonction possible | Comportement du moteur | Condition médicale ou état des preuves à montrer |
| --- | --- | --- |
| **Protéines en poudre (whey, végétales)** | Saisir portion et contenu **selon étiquette** ; proposer uniquement si un besoin nutritionnel est identifié et non couvert commodément par l'alimentation. | Aliment/supplément pratique, **pas indispensable** ; tenir compte d'allergies/intolérances et pathologies. |
| **Créatine monohydrate** | Fiche pédagogique consultable, suivi d'une prise choisie ; plage **3–5 g/j dans des études adultes** uniquement en information sourcée [S07]. | Option possible pour certains efforts de force ; vérifier médicaments, problèmes rénaux, grossesse et autres risques via un professionnel si pertinent. **Pas d'effet de rajeunissement humain démontré.** |
| **Vitamine B12** | Proposer l'examen de l'adéquation alimentaire dans certains régimes végétaliens ou situations cliniques, avec orientation. | Prévenir/corriger un déficit ; quantités choisies selon contexte et conseils professionnels, pas un dosage unique [S08]. |
| **Vitamine D** | Fiche d'information et éventuel suivi d'un traitement/complément existant. | Pas de dépistage biologique universel chez adulte sain, ni de supplémentation forte non justifiée [S08]. |
| **Fer** | Enregistrer ordonnance/prise si besoin ; préparer un rendez-vous pour suspicion de carence. | **Ne pas recommander de fer sans indication** : risque de surcharge et d'interactions [S08]. |
| **Oméga-3** | Examiner en priorité les habitudes alimentaires et objectifs ; enregistrer une prise choisie. | Preuves dépendant de l'indication, du produit et de la dose ; pas de promesse cardiovasculaire ou anti-âge universelle. |
| **Fibres / psyllium** | Saisie manuelle possible avec heure et quantité. | Tolérance digestive, interactions médicamenteuses et eau adaptée à discuter ; ne pas présumer un besoin. |
| **Magnésium, zinc, cuivre, folates, autres micronutriments** | Saisie depuis étiquette, contrôle des **doublons de produits** et rappels. | Déficits/indications propres, plafonds et interactions ; excès possibles, ne jamais recommander un empilement systématique. |
| **Mélatonine / produits du sommeil** | Enregistrer uniquement utilisation/avis déjà établi, et noter risques/interactions. | **Pas de protocole automatique de traitement de l'insomnie** ; orientation TCC-I en cas d'insomnie chronique [S10]. |
| **Collagène, probiotiques, plantes, antioxydants** | Inventaire et observation facultatifs, sans attribution automatique d'efficacité. | Preuves dépendant de la formulation et de l'indication, risques d'interactions/contaminants. |
| **NMN, resvératrol, fisétine, sénolytiques et autres « longévité »** | Catégorie `expérimental / efficacité clinique de rajeunissement non établie`, consignation d'un usage déclaré seulement. | **Ne pas générer de cure ni de dose « anti-âge »**, renvoyer vers un professionnel et des sources rigoureuses. |

**Fiche de produit** : `produit_id`, fabricant, composition **par portion**, forme, unité et concentration, lot/dates facultatifs, source et date d'information, contre-indications signalées, médicaments/suppléments déclarés potentiellement interactifs, **dose inscrite sur l'emballage ou prescrite** (jamais une dose devinée), horaires, fréquence, plage de dates, rappel, prise *confirmée manuellement* et éventuel ressenti. Une saisie libre doit fonctionner pour un produit absent du catalogue ; les champs incertains restent inconnus. Si la personne change de marque/concentration, **créer une nouvelle version de la fiche** et ne pas recopier silencieusement une ancienne quantité.

**Sécurité d'orchestration** : proposer un **contrôle des doublons d'ingrédient actif** entre produits, un signal d'interaction potentielle et une **vérification humaine** — cela ne prouve jamais l'absence d'interactions. **Pas d'achat, d'arrêt de médicament, de dosage personnalisé, de cure de charge, de changement de traitement ni de bilan biologique obligatoire** déclenchés par l'IA. Toutes ces décisions relèvent de la personne et des professionnels appropriés. Le NIH ODS rappelle que « naturel » ne veut pas dire sans danger, en particulier avec les associations et médicaments [S08].

**Agenda et résultats** : une occurrence de prise proposée avec horaire et récurrence ; l'app enregistre `rappel envoyé` puis uniquement si signalé `prise déclarée`, jamais une absorption présumée. Bilan médical si indiqué → rendez-vous distinct ; document reçu → `BR-SUI-05 Résultats`. Pour le Moniteur, une évolution survenue pendant une cure est **associée dans le temps**, sans déduction automatique de causalité.
