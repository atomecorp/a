# Catalogue général à étendre par données

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §7, lignes 375–421.

# 7. Musique et audio

Prévoir au minimum :

1. Créer une chanson.
2. Composer une chanson à plusieurs.
3. Écrire des paroles.
4. Composer une musique instrumentale.
5. Produire un morceau complet.
6. Enregistrer une démo.
7. Enregistrer un single.
8. Mixer un morceau.
9. Masteriser un morceau.
10. Finaliser un morceau déjà commencé.
11. Créer un EP.
12. Créer un album.
13. Remixer un morceau.
14. Préparer une collaboration musicale.
15. Trouver un chanteur.
16. Trouver un musicien.
17. Constituer un groupe.
18. Répéter un répertoire.
19. Préparer une setlist.
20. Préparer un concert.
21. Organiser un concert.
22. Préparer une tournée.
23. Organiser une tournée.
24. Préparer un live électronique.
25. Préparer un playback / backing tracks.
26. Préparer un système de scène audio/MIDI/DMX.
27. Publier un morceau.
28. Distribuer un morceau sur les plateformes.
29. Déclarer et documenter une œuvre.
30. Préparer une sortie promotionnelle.
31. Créer un clip musical.
32. Créer une identité sonore.
33. Créer une banque de sons.
34. Créer un sample pack.
35. Créer un podcast.
36. Produire un épisode de podcast.
37. Créer un habillage sonore.
38. Préparer une session studio.
39. Préparer un rider technique.
40. Monter un home-studio.

---

---

Source : `Sources/objectives_original.md`, §8, lignes 422–456.

# 8. Vidéo, cinéma et audiovisuel

1. Écrire un scénario.
2. Développer une idée de film.
3. Préparer un storyboard.
4. Réaliser un court métrage.
5. Réaliser un film.
6. Réaliser un documentaire.
7. Réaliser une vidéo YouTube.
8. Réaliser une publicité.
9. Réaliser un clip.
10. Réaliser une interview.
11. Préparer un tournage.
12. Constituer une équipe de tournage.
13. Trouver des acteurs.
14. Faire un casting.
15. Trouver des lieux.
16. Organiser un planning de tournage.
17. Préparer le matériel.
18. Monter une vidéo.
19. Faire l’étalonnage.
20. Faire le sound design.
21. Ajouter musique et voix.
22. Ajouter sous-titres.
23. Finaliser les exports.
24. Préparer une diffusion.
25. Soumettre un film à des festivals.
26. Chercher un financement audiovisuel.
27. Organiser une projection.
28. Créer une série de vidéos.
29. Créer une chaîne vidéo.
30. Construire un calendrier éditorial vidéo.

---

---

Source : `Sources/objectives_original.md`, §9, lignes 457–481.

# 9. Graphisme, design et création visuelle

1. Créer un logo.
2. Créer une identité visuelle.
3. Créer une charte graphique.
4. Réaliser une affiche.
5. Réaliser une pochette d’album.
6. Créer un visuel promotionnel.
7. Créer un site visuel / maquette.
8. Créer une interface.
9. Créer une illustration.
10. Réaliser une série d’illustrations.
11. Créer un portfolio.
12. Préparer une exposition.
13. Organiser une exposition.
14. Créer une collection graphique.
15. Créer des assets pour un jeu.
16. Créer des visuels pour les réseaux sociaux.
17. Préparer des fichiers d’impression.
18. Concevoir un packaging.
19. Créer une présentation visuelle.
20. Créer un livre illustré.

---

---

Source : `Sources/objectives_original.md`, §10, lignes 482–506.

# 10. Écriture, publication et contenu

1. Écrire un livre.
2. Écrire une nouvelle.
3. Écrire un article.
4. Écrire un essai.
5. Écrire un scénario.
6. Écrire une pièce.
7. Écrire des paroles.
8. Créer un blog.
9. Publier régulièrement.
10. Créer une newsletter.
11. Créer un dossier de presse.
12. Créer un communiqué.
13. Préparer une campagne éditoriale.
14. Traduire une œuvre.
15. Corriger un manuscrit.
16. Préparer l’édition.
17. Auto-publier un livre.
18. Chercher un éditeur.
19. Préparer une campagne de lancement.
20. Créer une documentation technique.

---

---

Source : `Sources/objectives_original.md`, §11, lignes 507–536.

# 11. Logiciel, produit numérique et technologie

1. Créer une application.
2. Créer un site web.
3. Créer un prototype.
4. Finaliser un MVP.
5. Préparer une bêta.
6. Lancer un produit numérique.
7. Débugger un produit.
8. Optimiser les performances.
9. Sécuriser un produit.
10. Préparer un déploiement.
11. Créer une API.
12. Créer un plugin.
13. Créer un jeu.
14. Créer un outil interne.
15. Migrer une architecture.
16. Auditer un codebase.
17. Documenter un projet.
18. Organiser les tests.
19. Préparer une release.
20. Organiser la maintenance.
21. Construire une communauté open source.
22. Recruter des contributeurs.
23. Chercher des testeurs.
24. Collecter les retours utilisateurs.
25. Préparer une roadmap.

---

---

Source : `Sources/objectives_original.md`, §12, lignes 537–576.

# 12. Entreprise, activité professionnelle et entrepreneuriat

1. Créer une entreprise.
2. Lancer une activité indépendante.
3. Valider une idée de business.
4. Construire un business model.
5. Réaliser une étude de marché.
6. Trouver un nom.
7. Créer une marque.
8. Créer une offre.
9. Fixer un prix.
10. Trouver ses premiers clients.
11. Créer une stratégie commerciale.
12. Créer une stratégie marketing.
13. Préparer un lancement.
14. Construire un site commercial.
15. Mettre en place une facturation.
16. Mettre en place une comptabilité.
17. Organiser l’administratif.
18. Trouver des partenaires.
19. Recruter.
20. Constituer une équipe.
21. Chercher des prestataires.
22. Trouver un associé.
23. Préparer une levée de fonds.
24. Chercher des investisseurs.
25. Préparer un pitch.
26. Préparer un dossier financier.
27. Chercher des subventions.
28. Organiser une campagne de crowdfunding.
29. Améliorer la rentabilité.
30. Réduire les coûts.
31. Automatiser des opérations.
32. Développer à l’international.
33. Préparer une nouvelle offre.
34. Préparer une fusion ou un partenariat.
35. Créer un réseau professionnel.

---

---

Source : `Sources/objectives_original.md`, §13, lignes 577–603.

# 13. Financement et ressources

Cette catégorie peut être utilisée seule ou comme sous-objectif d’un autre scénario.

1. Évaluer le budget d’un projet.
2. Construire un plan de financement.
3. Réduire le coût d’un projet.
4. Trouver des aides.
5. Trouver des subventions.
6. Trouver des sponsors.
7. Trouver des investisseurs.
8. Trouver des mécènes.
9. Lancer un crowdfunding.
10. Préparer un dossier bancaire.
11. Trouver des partenaires matériels.
12. Chercher des dons.
13. Mutualiser des ressources.
14. Louer plutôt qu’acheter.
15. Identifier les dépenses obligatoires.
16. Prioriser les dépenses.
17. Suivre budget prévu / réel.
18. Préparer des échéances de paiement.
19. Prévoir une réserve.
20. Clôturer financièrement un projet.

---

---

Source : `Sources/objectives_original.md`, §14, lignes 604–633.

# 14. Travail, carrière et compétences

1. Trouver un emploi.
2. Changer de métier.
3. Préparer un CV.
4. Créer un portfolio.
5. Préparer un entretien.
6. Chercher des offres.
7. Organiser des candidatures.
8. Développer son réseau.
9. Trouver un mentor.
10. Apprendre une compétence.
11. Obtenir une certification.
12. Préparer un examen.
13. Préparer un concours.
14. Construire une formation.
15. Suivre une formation.
16. Créer un plan de carrière.
17. Préparer une promotion.
18. Négocier une rémunération.
19. Lancer une activité parallèle.
20. Passer indépendant.
21. Reprendre des études.
22. Créer une réputation professionnelle.
23. Publier des travaux.
24. Préparer une conférence.
25. Faire une présentation publique.

---

---

Source : `Sources/objectives_original.md`, §15, lignes 634–664.

# 15. Santé, forme et bien-être

Les scénarios de santé doivent rester des outils d’organisation et de suivi et ne pas remplacer un professionnel de santé.

1. Perdre du poids.
2. Prendre de la masse.
3. Prendre du muscle.
4. Maintenir son poids.
5. Reprendre le sport.
6. Améliorer sa condition physique.
7. Améliorer son endurance.
8. Améliorer sa force.
9. Améliorer sa mobilité.
10. Améliorer sa souplesse.
11. Mieux dormir.
12. Stabiliser ses horaires de sommeil.
13. Améliorer son alimentation.
14. Boire suffisamment.
15. Réduire une habitude alimentaire.
16. Préparer un bilan de santé.
17. Organiser ses rendez-vous médicaux.
18. Suivre des mesures de santé.
19. Suivre un traitement prescrit.
20. Organiser une rééducation prescrite.
21. Diminuer le stress.
22. Introduire une routine de relaxation.
23. Reprendre une activité après une interruption.
24. Maintenir une amélioration obtenue.

---

---

Source : `Sources/objectives_original.md`, §16, lignes 665–689.

# 16. Sport et performance

1. Courir 5 km.
2. Courir 10 km.
3. Courir un semi-marathon.
4. Courir un marathon.
5. Préparer un trail.
6. Faire une grande randonnée.
7. Préparer une randonnée sur plusieurs jours.
8. Faire un trek.
9. Préparer une course cycliste.
10. Préparer une longue sortie vélo.
11. Améliorer une performance sportive.
12. Préparer une compétition.
13. Reprendre une saison sportive.
14. Construire un programme d’entraînement.
15. Organiser le matériel.
16. Organiser la récupération.
17. Planifier une progression.
18. Atteindre un objectif de force.
19. Atteindre un objectif d’endurance.
20. Maintenir un niveau après l’objectif.

---

---

Source : `Sources/objectives_original.md`, §17, lignes 690–714.

# 17. Voyage, aventure et déplacement

1. Organiser un voyage.
2. Organiser un road trip.
3. Préparer un voyage longue durée.
4. Préparer une expatriation.
5. Préparer un trek.
6. Préparer une randonnée.
7. Organiser un voyage en groupe.
8. Trouver des participants.
9. Construire un itinéraire.
10. Réserver les transports.
11. Réserver les hébergements.
12. Préparer un budget.
13. Préparer les documents.
14. Préparer le matériel.
15. Préparer les assurances.
16. Organiser les étapes.
17. Partager l’itinéraire.
18. Suivre les dépenses.
19. Documenter le voyage.
20. Archiver souvenirs et médias.

---

---

Source : `Sources/objectives_original.md`, §18, lignes 715–739.

# 18. Vie personnelle et organisation

1. Organiser sa semaine.
2. Organiser son année.
3. Mettre en place une routine.
4. Réduire la procrastination.
5. Trier ses documents.
6. Organiser ses fichiers.
7. Faire un déménagement.
8. Préparer un changement de logement.
9. Rénover une pièce.
10. Rénover un logement.
11. Organiser un budget personnel.
12. Épargner pour un achat.
13. Préparer un achat important.
14. Simplifier son quotidien.
15. Créer une routine matinale.
16. Créer une routine du soir.
17. Réduire une mauvaise habitude.
18. Installer une nouvelle habitude.
19. Réaliser une liste de projets personnels.
20. Atteindre un objectif libre.

---

---

Source : `Sources/objectives_original.md`, §19, lignes 740–764.

# 19. Relations, groupe et communauté

1. Organiser une rencontre.
2. Réunir un groupe.
3. Constituer une équipe.
4. Trouver des personnes partageant un intérêt.
5. Créer une communauté.
6. Développer une communauté.
7. Organiser des rencontres régulières.
8. Organiser un événement.
9. Organiser une fête.
10. Organiser une réunion.
11. Organiser une conférence.
12. Organiser un atelier.
13. Trouver des intervenants.
14. Trouver des bénévoles.
15. Trouver des participants.
16. Répartir les rôles.
17. Organiser les communications.
18. Maintenir l’engagement du groupe.
19. Suivre les décisions collectives.
20. Préparer un projet collaboratif.

---

---

Source : `Sources/objectives_original.md`, §20, lignes 765–783.

# 20. Rencontre et vie relationnelle

Ces scénarios doivent rester respectueux de la vie privée, du consentement et des choix individuels.

1. Élargir son cercle social.
2. Faire de nouvelles rencontres.
3. Organiser plus de sorties.
4. Trouver des activités sociales.
5. Développer une relation.
6. Préparer une activité à deux.
7. Organiser un voyage à deux.
8. Construire un projet commun.
9. Maintenir du temps de qualité.
10. Organiser des objectifs communs.

Le système ne doit jamais transformer une personne en « cible » à obtenir ni automatiser des comportements intrusifs.

---

---

Source : `Sources/objectives_original.md`, §21, lignes 784–808.

# 21. Maison, matériel et environnement

1. Aménager une pièce.
2. Créer un studio.
3. Créer un atelier.
4. Créer un bureau.
5. Faire des travaux.
6. Acheter du matériel.
7. Comparer des équipements.
8. Installer un système audio.
9. Installer un système lumière.
10. Installer un réseau.
11. Organiser un inventaire.
12. Entretenir un équipement.
13. Préparer une maintenance.
14. Réduire la consommation.
15. Organiser un déménagement.
16. Concevoir un espace.
17. Planifier une rénovation.
18. Suivre artisans et prestataires.
19. Suivre budget travaux.
20. Valider la fin des travaux.

---

---

Source : `Sources/objectives_original.md`, §22, lignes 809–833.

# 22. Recherche, science et invention

1. Explorer une question.
2. Construire une hypothèse.
3. Faire un état de l’art.
4. Organiser une veille.
5. Concevoir une expérience.
6. Collecter des données.
7. Analyser des résultats.
8. Documenter une découverte.
9. Créer un prototype.
10. Tester un prototype.
11. Améliorer une invention.
12. Chercher des collaborateurs.
13. Chercher un laboratoire.
14. Chercher un financement.
15. Préparer une publication.
16. Préparer une présentation.
17. Déposer une preuve d’antériorité.
18. Préparer une stratégie de propriété intellectuelle.
19. Construire une roadmap de recherche.
20. Transformer une recherche en produit.

---

---

Source : `Sources/objectives_original.md`, §23, lignes 834–858.

# 23. Éducation et apprentissage

1. Apprendre une langue.
2. Apprendre un instrument.
3. Apprendre à chanter.
4. Apprendre à coder.
5. Apprendre le dessin.
6. Apprendre la vidéo.
7. Apprendre la photographie.
8. Apprendre une compétence professionnelle.
9. Préparer un examen.
10. Préparer un concours.
11. Réviser un programme.
12. Lire une série de livres.
13. Construire un programme personnel.
14. Trouver des ressources.
15. Trouver un professeur.
16. Trouver un partenaire de pratique.
17. Suivre ses heures de pratique.
18. Valider des niveaux.
19. Produire un projet final.
20. Maintenir la compétence.

---

---

Source : `Sources/objectives_original.md`, §24, lignes 859–878.

# 24. Engagement, association et action collective

1. Créer une association.
2. Organiser une action locale.
3. Recruter des bénévoles.
4. Organiser une collecte.
5. Trouver des financements.
6. Préparer une campagne.
7. Organiser un événement caritatif.
8. Développer une communauté.
9. Gérer les participants.
10. Gérer les ressources.
11. Mesurer l’impact.
12. Communiquer les résultats.
13. Trouver des partenaires.
14. Organiser une action récurrente.
15. Maintenir le projet après son lancement.

---

---

Source : `Sources/objectives_original.md`, §25, lignes 879–901.

# 25. Objectif libre universel

Il doit toujours exister une entrée :

> **Créer mon propre objectif**

Le système demande alors :

1. Quel résultat veux-tu obtenir ?
2. Pourquoi ?
3. Pour quand ?
4. Comment sauras-tu que c’est réussi ?
5. Que possèdes-tu déjà ?
6. Que te manque-t-il ?
7. As-tu besoin d’autres personnes ?
8. As-tu besoin d’un budget ?
9. Existe-t-il des contraintes ?
10. Quelles sont les premières étapes connues ?

L’assistant peut ensuite proposer un scénario initial en réutilisant les briques génériques.

---
