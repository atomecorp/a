# Moteur universel et scénarios déclaratifs

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §1, lignes 19–90.

# 1. Vision

atome/eVe doit proposer un système d’objectifs beaucoup plus large qu’un gestionnaire de projets classique.

L’utilisateur ne crée pas simplement une liste de tâches.

Il exprime un résultat qu’il veut atteindre, par exemple :

- créer un album ;
- préparer un concert ;
- réaliser un film ;
- organiser une grande randonnée ;
- perdre du poids ;
- prendre de la masse ;
- mieux dormir ;
- courir un marathon ;
- monter une société ;
- financer un projet ;
- organiser un événement ;
- réunir une équipe ;
- apprendre une compétence ;
- trouver des collaborateurs ;
- préparer un voyage ;
- lancer un produit ;
- écrire un livre ;
- améliorer une habitude ;
- mener une recherche ;
- accomplir un objectif libre non prévu à l’avance.

atome/eVe doit alors transformer cet objectif en **itinéraire structuré, adaptable et suivi dans le temps**.

Le système doit guider l’utilisateur depuis l’intention initiale jusqu’à :

1. la définition ;
2. la préparation ;
3. la planification ;
4. l’exécution ;
5. le suivi ;
6. les corrections ;
7. la validation ;
8. l’achèvement ;
9. le maintien éventuel après réussite.

Le système doit pouvoir intégrer :

- tâches ;
- sous-objectifs ;
- calendrier ;
- rappels ;
- ressources ;
- documents ;
- médias ;
- budget ;
- financement ;
- personnes ;
- équipes ;
- contacts ;
- recherche de compétences ;
- communication ;
- localisation ;
- dépendances ;
- contraintes ;
- métriques ;
- preuves d’avancement ;
- automatisations ;
- recommandations ;
- assistant IA ;
- conditions d’entrée/sortie ;
- suivi après atteinte de l’objectif.

---

---

Source : `Sources/objectives_original.md`, §2, lignes 91–130.

# 2. Principe fondamental : un objectif n’est pas un projet figé

Un objectif doit être représenté comme un **graphe évolutif**, pas comme une simple checklist linéaire.

Un objectif peut comporter :

- plusieurs chemins possibles ;
- des étapes facultatives ;
- des étapes conditionnelles ;
- des dépendances ;
- des branches ;
- des retours en arrière ;
- des validations ;
- des étapes parallèles ;
- des personnes différentes ;
- plusieurs sources de financement ;
- plusieurs lieux ;
- plusieurs dates possibles ;
- plusieurs niveaux de réussite.

Exemple :

> Objectif : sortir un album.

Le chemin peut varier selon que l’utilisateur :

- compose seul ou avec un groupe ;
- possède déjà les morceaux ;
- doit trouver un chanteur ;
- enregistre chez lui ou en studio ;
- autoproduit ou cherche un label ;
- prévoit une sortie numérique uniquement ;
- souhaite presser un vinyle ;
- dispose déjà du financement ;
- veut préparer ensuite une tournée.

Le scénario doit donc être **pré-câblé mais jamais rigide**.

---

---

Source : `Sources/objectives_original.md`, §3, lignes 131–211.

# 3. Modèle d’un objectif

Chaque objectif doit être un objet structuré contenant au minimum :

## 3.1 Identité

- titre ;
- description ;
- catégorie ;
- type de scénario ;
- statut ;
- priorité ;
- date de création ;
- date de début ;
- date cible éventuelle ;
- horizon temporel ;
- propriétaire ;
- participants éventuels.

## 3.2 Résultat attendu

Le système doit demander ou déduire :

- ce que signifie « réussi » ;
- le niveau minimum acceptable ;
- le niveau idéal ;
- les critères mesurables ;
- les critères qualitatifs ;
- les preuves nécessaires.

## 3.3 Étapes

Chaque étape peut contenir :

- titre ;
- explication ;
- actions ;
- dépendances ;
- durée estimative ;
- dates ;
- ressources ;
- contacts ;
- budget ;
- conditions ;
- critères de validation ;
- livrables ;
- sous-objectifs ;
- documents liés ;
- médias liés ;
- notes ;
- risques ;
- alternatives.

## 3.4 Progression

La progression ne doit pas être calculée uniquement en pourcentage de tâches cochées.

Elle peut prendre en compte :

- étapes obligatoires terminées ;
- importance relative des étapes ;
- jalons atteints ;
- métriques réelles ;
- validation manuelle ;
- validation automatique ;
- temps écoulé ;
- qualité du résultat ;
- risques restant ouverts.

Afficher au minimum :

- progression globale ;
- prochaine étape ;
- blocages ;
- retard éventuel ;
- jalons importants ;
- date cible ;
- tendance : en avance / normal / en retard / bloqué.

---

---

Source : `Sources/objectives_original.md`, §4, lignes 212–325.

# 4. Cycle de vie générique de tous les objectifs

Tous les scénarios doivent pouvoir s’appuyer sur un cycle commun.

## Phase 1 — Intention

Questions de base :

- Que veux-tu accomplir ?
- Pourquoi ?
- Pour quand ?
- Quel niveau de résultat souhaites-tu ?
- Est-ce personnel, collectif ou professionnel ?
- Existe-t-il déjà des éléments réalisés ?

## Phase 2 — Diagnostic initial

Déterminer :

- point de départ ;
- ressources disponibles ;
- compétences ;
- temps disponible ;
- budget ;
- contraintes ;
- personnes déjà impliquées ;
- matériel ;
- documents ;
- risques ;
- prérequis.

## Phase 3 — Construction du parcours

Le système instancie le scénario choisi et supprime les branches inutiles.

Il propose :

- phases ;
- jalons ;
- actions ;
- ordre logique ;
- tâches parallèles ;
- ressources ;
- personnes à trouver ;
- budget ;
- dates.

## Phase 4 — Exécution

L’utilisateur avance dans le scénario.

Le système :

- présente la prochaine action utile ;
- évite d’afficher inutilement toute la complexité ;
- suit les dépendances ;
- détecte les blocages ;
- adapte les étapes suivantes.

## Phase 5 — Contrôle

À intervalles pertinents :

- comparer prévu / réel ;
- vérifier les métriques ;
- vérifier les livrables ;
- identifier retard ou dérive ;
- proposer une correction.

## Phase 6 — Validation

Une étape peut être validée par :

- l’utilisateur ;
- un collaborateur ;
- une donnée mesurée ;
- un fichier produit ;
- une date atteinte ;
- un événement ;
- une condition ;
- une vérification automatique.

## Phase 7 — Achèvement

Le système confirme :

- résultat obtenu ;
- éléments manquants ;
- résultat partiel éventuel ;
- livrables finaux ;
- archivage ;
- partage.

## Phase 8 — Maintien

Certains objectifs ne s’arrêtent pas lorsqu’ils sont atteints.

Exemples :

- poids ;
- forme ;
- sommeil ;
- revenus ;
- apprentissage ;
- entretien d’un équipement ;
- communauté ;
- clientèle ;
- relation ;
- habitudes.

Le scénario peut donc basculer vers un **mode maintien** avec une fréquence plus faible de suivi.

---

---

Source : `Sources/objectives_original.md`, §5, lignes 326–366.

# 5. Architecture des scénarios pré-câblés

Les scénarios ne doivent pas être codés directement dans l’interface.

Créer un format déclaratif permettant de définir un scénario avec :

- `id`
- `name`
- `category`
- `description`
- `tags`
- `goal_type`
- `questions`
- `phases`
- `steps`
- `dependencies`
- `conditions`
- `milestones`
- `resources`
- `roles`
- `metrics`
- `funding_options`
- `maintenance`
- `recommended_tools`
- `automation_hooks`

Le moteur doit interpréter ces définitions et construire l’objectif.

Avantages :

- ajout d’un scénario sans modifier l’UI ;
- possibilité de partager des scénarios ;
- scénarios communautaires ;
- scénarios privés ;
- scénarios créés par l’utilisateur ;
- scénarios générés avec l’assistant ;
- versionnage ;
- évolution sans casser les objectifs déjà créés.

---

---

Source : `Sources/objectives_original.md`, §25, lignes 879–901.

# 25. Objectif libre universel

Il doit toujours exister une entrée :

> **Créer mon propre objectif**

Le système demande alors :

1. Quel résultat veux-tu obtenir ?
2. Pourquoi ?
3. Pour quand ?
4. Comment sauras-tu que c’est réussi ?
5. Que possèdes-tu déjà ?
6. Que te manque-t-il ?
7. As-tu besoin d’autres personnes ?
8. As-tu besoin d’un budget ?
9. Existe-t-il des contraintes ?
10. Quelles sont les premières étapes connues ?

L’assistant peut ensuite proposer un scénario initial en réutilisant les briques génériques.

---

---

Source : `Sources/objectives_original.md`, §26, lignes 902–939.

# 26. Sous-objectifs réutilisables

Certaines fonctions doivent exister comme scénarios transverses appelables depuis n’importe quel objectif.

Exemples :

- trouver une personne ;
- trouver une compétence ;
- recruter ;
- trouver un prestataire ;
- obtenir un avis ;
- trouver un financement ;
- trouver du matériel ;
- acheter ;
- louer ;
- réserver ;
- comparer ;
- apprendre ;
- contacter ;
- demander une autorisation ;
- obtenir un document ;
- créer un budget ;
- créer un planning ;
- faire une recherche ;
- organiser une réunion ;
- faire valider une étape ;
- publier ;
- communiquer ;
- promouvoir ;
- mesurer ;
- tester ;
- corriger ;
- maintenir.

Ces briques doivent pouvoir être injectées automatiquement dans des scénarios différents.

---

---

Source : `Sources/objectives_original.md`, §35, lignes 1176–1200.

# 35. Adaptation dynamique

Le scénario doit évoluer.

Exemple :

Objectif initial :

> Organiser un concert.

L’utilisateur indique plus tard :

> La salle est annulée.

Le système doit :

1. rouvrir l’étape lieu ;
2. marquer les dépendances impactées ;
3. préserver le travail déjà fait ;
4. proposer de chercher une autre salle ;
5. réévaluer budget et planning ;
6. signaler les actions devenues invalides.

---

---

Source : `Sources/objectives_original.md`, §36, lignes 1201–1225.

# 36. Scénarios composables

Un grand objectif doit pouvoir appeler d’autres scénarios.

Exemple :

## Créer un album

Sous-objectifs possibles :

- composer 10 titres ;
- trouver un bassiste ;
- enregistrer ;
- mixer ;
- masteriser ;
- créer la pochette ;
- financer le mastering ;
- publier ;
- promouvoir ;
- préparer un concert de lancement.

Chaque sous-objectif peut être un scénario autonome réutilisé ailleurs.

---

---

Source : `Sources/objectives_original.md`, §37, lignes 1226–1244.

# 37. Progression intelligente

Ne pas utiliser une progression naïve.

Chaque étape doit pouvoir avoir :

- `weight` ;
- `required` ;
- `optional` ;
- `blocking` ;
- `validation_mode` ;
- `progress_metric`.

Exemple :

Pour un album, « choisir une couleur de dossier » ne doit pas compter autant que « terminer le mixage des 10 morceaux ».

---

---

Source : `Sources/objectives_original.md`, §38, lignes 1245–1265.

# 38. Historique et traçabilité

Conserver :

- création ;
- décisions ;
- changements de dates ;
- validations ;
- annulations ;
- nouvelles branches ;
- changements de budget ;
- personnes ajoutées ;
- livrables ;
- changements de statut.

Permettre de comprendre :

> pourquoi le plan actuel est différent du plan initial.

---

---

Source : `Sources/objectives_original.md`, §39, lignes 1266–1286.

# 39. États d’un objectif

Prévoir au minimum :

- idée ;
- à définir ;
- préparé ;
- actif ;
- en attente ;
- bloqué ;
- en pause ;
- en retard ;
- presque terminé ;
- terminé ;
- partiellement réussi ;
- abandonné ;
- archivé ;
- maintien.

---

---

Source : `Sources/objectives_original.md`, §40, lignes 1287–1311.

# 40. Niveau d’automatisation

Pour chaque scénario, définir ce qui est :

- manuel ;
- assisté ;
- automatique ;
- conditionnel.

Exemple :

### Manuel
Valider que l’utilisateur aime le mix final.

### Assisté
Proposer une liste d’ingénieurs du son.

### Automatique
Calculer le pourcentage de morceaux masterisés.

### Conditionnel
Débloquer la distribution lorsque tous les masters obligatoires existent.

---

---

Source : `Sources/objectives_original.md`, §46, lignes 1483–1494.

# 46. Règle d’architecture essentielle

Le catalogue d’objectifs ne doit pas devenir une énorme collection de code spécifique.

Construire :

> un moteur générique + des briques réutilisables + des scénarios déclaratifs.

Les centaines d’objectifs doivent principalement être des combinaisons de ces briques.

---
