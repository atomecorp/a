# 53. Développement progressif, validation visuelle et recette humaine

## 53.1. Répartition des responsabilités

**Codex** lit le code réel, propose les changements, prépare une démonstration isolée, exécute les tests techniques et fournit les preuves. **Le porteur du projet** valide visuellement chaque panneau, étape et proposition, puis effectue la recette d'usage lorsque la tâche complète est terminée. Codex ne peut pas se donner à lui-même une validation humaine.

## 53.2. Cycle bloquant de chaque unité visible

1. Inventorier les composants et les références exactes. Signaler ce qui manque.
2. Décrire la structure concrète : outils présents, sélection, sous-matrices, options natives et paramètres du carré étendu.
3. Préparer une démonstration isolée utilisant les vrais outils, affichable dans l'application de test. Ne pas modifier le parcours intégré avant validation.
4. Afficher **une proposition identifiée et versionnée**, donner son chemin d'accès et la faire manipuler. Captures/vidéos accompagnent la démonstration sans se substituer à un rendu réel lorsqu'il est possible. Les données de démonstration sont identifiées comme telles.
5. **S'arrêter** et attendre la validation visuelle du porteur du projet pour cette unité. Un refus entraîne une nouvelle révision du même élément. Une capture générée ou un test automatique ne vaut pas accord.
6. Après accord, intégrer **uniquement** l'unité approuvée, conserver une possibilité de retour arrière et exécuter les tests techniques réels.
7. Si un changement visible apparaît après accord, le représenter et obtenir une nouvelle validation. Procéder ainsi pour chaque unité de la tâche.
8. Lorsque toutes les unités de la tâche sont intégrées et que les tests de Codex ont réussi, remettre la tâche au porteur du projet pour son **test final d'usage**. Attendre son résultat et traiter les retours.
9. La tâche ne devient terminée qu'après cette recette. Ne pas démarrer la suivante sans une instruction de poursuite explicite. Une seule tâche d'implémentation est active.

## 53.3. Accord précisément délimité

Chaque preuve doit préciser tâche, unité visuelle, révision, version du code, plateforme et état montré. Conserver la réponse réelle de l'utilisateur dans le journal de validation. « Oui » peut approuver uniquement la dernière proposition clairement présentée ; en cas d'ambiguïté, demander quel élément est approuvé. L'approbation d'un écran n'approuve ni les autres états, ni les prochains écrans, ni une publication de données de santé.

Le statut « testé techniquement » ne signifie pas « validé visuellement », « validé cliniquement », « accepté par l'utilisateur » ni « déployé ». Le prototype peut être codé dans un environnement isolé avant approbation, mais il ne doit pas être annoncé comme intégré. Aucun déploiement distant, publication sociale réelle, achat ou envoi à un tiers n'est autorisé par cette procédure seule.

## 53.4. Références et exigences d'interface

Conserver le concept d'atome/eVe : matrice de carrés, sous-matrices, extension temporaire sur deux ou trois cellules, véritables outils et commandes natives. Pas de panneau flottant, formulaire parallèle ou réseau social générique. Réutiliser dimensions, couleurs, pictogrammes et proportions du code et des captures vérifiées. Les références visuelles manquantes sont un point à résoudre, pas une permission d'inventer.

Les premiers tests iOS privilégient l'iPad disponible, avec WebDriverAgent seulement s'il est réellement configuré. Compléter par les autres plateformes réellement supportées. Le toucher, le clavier, les technologies d'assistance, les thèmes et la variation des tailles d'écran doivent être vérifiés selon les capacités existantes. Ne pas déclarer testé un appareil non accessible.

## 53.5. Tâches sans interface et blocages

Une tâche documentaire ou de modèle interne ne doit pas inventer un panneau. Présenter le livrable lisible et, si pertinent, une démonstration dans un outil existant ; faire valider son périmètre et l'absence de régression visuelle. Une impossibilité d'afficher une proposition ou un composant non vérifié empêche de franchir le jalon visuel concerné.

Les tests techniques sont menés par Codex. L'accès manquant à un serveur, à un capteur, au code ou aux appareils doit être noté **bloqué/non testé**, jamais remplacé par une simulation présentée comme une réussite d'intégration.

## 53.6. Précisions de cohérence documentaire

La section 51 remplace les exemples médicaux exploratoires antérieurs. Ses valeurs et références sont **héritées de la source** ; cette opération de découpage n'en constitue pas une nouvelle vérification scientifique. Une revue des sources actuelles et une validation professionnelle des conseils sont des jalons de publication distincts des tests de logiciel.

Corriger dans l'implémentation l'unité d'allure du rameur : **min/500 m**, et non « m/500m » figurant dans certains passages historiques. Garder séparés vitesse, durée, distance et provenance ; ne calculer une allure que si les valeurs sont compatibles. Les exemples 10 kg/5×5 et les durées UX demeurent des jeux d'essai, pas des prescriptions par défaut.

Les mécanismes de matrice de ce chantier concernent l'accès, la sélection, la composition et les réglages. Ils ne réécrivent pas arbitrairement les vues de création audio/vidéo spécialisées, explicitement séparées en section 0.
