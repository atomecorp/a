# Sports, mouvements et machines extensibles

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §51.20, lignes 2124–2234.

## 51.20. Sport : taxonomie extensive, matrices et catalogue évolutif

**Objectif d'implémentation :** « Sport » est une **bibliothèque de vraies activités interactives** partagée entre tous les projets, non neuf outils différents. Décliner les sports courants en **familles → disciplines → sous-disciplines → exercices/positions/machines → paramètres → exécution → mesures**. Le catalogue initial est détaillé ci-dessous, mais **l'extension est illimitée** : de nouveaux sports, mouvements et machines doivent pouvoir être ajoutés **sans modifier le moteur ni le dessin des matrices**. Aucune liste ne peut prétendre couvrir a priori « tous les sports du monde ».

### 51.20.1. La matrice racine « Sport »

`Activités / Objectif → Sport → [Marche, Course, Musculation, Natation, Rameur, Vélo, Fitness, Mobilité, Sports collectifs, Raquettes, Plein air, Danse, Combat, Autre]`. Chaque carré ouvre sa **propre matrice d'options**, non un formulaire générique commun à toutes les disciplines. Catégories, images et paramètres restent rattachés à l'objet réel.

| Famille sportive | Navigation matricielle proposée | Paramètres principaux et événements enregistrés |
| --- | --- | --- |
| **Marche** | Intérieur / Extérieur / Tapis / Marche rapide / Nordic walking | Minutes, distance et vitesse/allure si mesurées, inclinaison si tapis, terrain, pauses ; passage étape suivante si parcours fractionné. |
| **Course** | Extérieur / Piste / Tapis / Trail → Libre / Distance / Temps / Intervalles | Durée, distance, allure min/km, vitesse km/h, segments, récupération, dénivelé réel si disponible, GPS consenti. |
| **Rameur** | Salle / Maison / Eau → Ergometer / Bateau → Libre / Intervalles | Durée, distance (m), cadence coups/min, résistance ou niveau propre à l'appareil, puissance (W) uniquement si émise, intervalles, pauses. |
| **Vélo** | Route / VTT / Urbain / Vélo d'intérieur / Spinning | Durée, distance, vitesse, cadence, zones de résistance, puissance seulement si appareil compatible, segments et récupérations. |
| **Natation** | Piscine / Eau libre → Crawl / Brasse / Dos / Papillon / Éducatifs / Aquagym | Bassin (m), longueurs, distance, durée, nage, série, pauses, temps d'intervalle ; montre étanche si compatible et autorisée, sinon validation manuelle. |
| **Musculation** | Corps entier / Haut / Bas / Bras / Dos / Pectoraux / Jambes / Épaules → Groupe → Mouvement → Matériel | Machine, poids libre, élastique, poids du corps ; charge, assistance/résistance, côté, séries/répétitions, repos et progression. |
| **Cardio indoor** | Elliptique / Stepper / Tapis / Escaliers / Corde à sauter / Ski-erg | Durée, intervalles, cadence, résistance, vitesse/inclinaison selon matériel ; pas de distance fictive si impossible à mesurer. |
| **Fitness et circuits** | Renforcement léger / Circuit / Cardio-danse / Intervalles / HIIT (avancé) | Exercices ordonnés, durée exercice et repos, tours, répétitions, niveau d'effort ; **HIIT jamais suggéré par défaut à un novice**. |
| **Mobilité et souplesse** | Zone du corps → Mouvement / Étirement → Variante / Position | Amplitude non chiffrée si non mesurable, durée tenue, séries/côté, respiration confortable et inconfort déclaré ; pas d'étirement imposé en cas de douleur aiguë. |
| **Yoga / Pilates / Gym douce** | Discipline → Niveau → Posture / Séquence → Variante | Nom de posture, tenue (secondes), transitions, répétitions, latéralité, adaptations, suivi séquence ; positions choisies selon capacité. |
| **Équilibre / autonomie** | Debout / Assis / Avec appui → Mouvement de stabilité | Durée, répétitions, supports, sécurité anti-chute, besoin d'encadrement, confort ; personnes à risque de chute → exercices encadrés si indiqué. |
| **Plein air** | Randonnée / Trail / Escalade / Ski / Raquettes neige / Patinage / Roller / Kayak / Paddle | Durée, dénivelé, distance, difficulté déclarée, conditions météo/accessibilité, équipements de sécurité, GPS facultatif ; besoins spécifiques par discipline. |
| **Sports de raquette** | Tennis / Padel / Badminton / Squash / Tennis de table | Match / Entraînement / Technique, durée, sets/points si pertinents, partenaire, nombre d'échanges facultatif. |
| **Sports collectifs** | Football / Basket / Volley / Handball / Rugby / Hockey, etc. | Entraînement / Match, poste/participation, temps de jeu, phases, score facultatif, efforts mesurés si outils réels. |
| **Danse** | Libre / Classique / Contemporaine / Salsa / Hip-hop / Autre | Durée, chorégraphie / séquence, pas ou mouvements, répétitions et ressenti ; musique native réutilisée si disponible. |
| **Arts martiaux / combat** | Boxe / Judo / Karaté / Taekwondo / Aïkido / Autre | Travail technique, sac, kata/formes, partenaire/sparring, rounds, repos, équipement et précautions ; pas de sparring automatique sans encadrement. |
| **Autres** | Catégorie créée par l'utilisateur / importée d'un catalogue validé | Paramètres choisis par type, fiche d'exécution manuelle minimale, unités et représentation déclarées, icône provisoire avec libellé. |

**Distinguer** : activité sportive de loisir (durée/résultat), exercice technique (répétitions/positions), séance composée (liste d'exercices ordonnés), épisode dans un sport (match/longueur/intervalle) et prescription de rééducation portée par un professionnel. Une séance peut contenir plusieurs briques spécialisées ; chaque sous-activité renvoie un état au même historique.

### 51.20.2. Catalogue Musculation : groupes, mouvements, positions et variantes

Les exercices suivants sont des **entrées de bibliothèque à construire**, pas des programmes recommandés à tous. Les libellés courts seront associés à des **pictogrammes distinctifs** et leurs variantes ne dupliqueront pas la logique. Chaque mouvement accepte, selon sa nature : *machine / haltères / barre / câble / élastique / poids du corps*, *assis / debout / allongé / à genoux*, *bilatéral / unilatéral*, *charge ou résistance et unité*, *nombre de séries*, *répétitions par série*, *repos*, *amplitude/consigne validée*, *charge réellement effectuée*.

| Groupe principal | Exemples de mouvements à indexer (adaptations selon niveau / matériel) | Matrices spécialisées |
| --- | --- | --- |
| **Biceps / avant-bras** | Curl barre, curl haltères, curl marteau, curl pupitre, curl câble, curl concentré, flexion/extension poignet, préhension | Bras → Biceps / Avant-bras → Mouvement → Machine/outil → Charge / Séries / Répétitions / Côté. |
| **Triceps** | Extension à la poulie haute, extension corde, extension au-dessus de la tête, extension haltère, barre front, extension triceps machine, pompes prise rapprochée, dips **avec adaptations** | Bras → Triceps → Extension / Poussée → Machine / câble / poids du corps → Paramètres. |
| **Pectoraux** | Développé couché ou guidé, développé incliné, chest press assise, pompes adaptées, écartés aux câbles ou machines | Haut du corps → Pectoraux → Poussée / Écarté → Variante → Série. |
| **Dos** | Tirage vertical, tirage horizontal, rowing unilatéral, rowing machine, tractions **assistées**, pullover, extension dorsale **appropriée** | Haut du corps → Dos → Tirage vertical / horizontal / autre → Matériel → Paramètres. |
| **Épaules** | Développé épaules guidé ou haltères, élévation latérale, oiseau/écarté arrière, face-pull, rotation externe **légère adaptée** | Épaules → Deltoïdes / Coiffe → Mouvement → Position / Matériel → Paramètres. |
| **Quadriceps** | Presse à cuisses, squat adapté, squat guidé, extension de genou machine, fente, split squat, montée sur marche | Bas du corps → Cuisses avant → Poussée / Extension → Position → Charge / Répétitions. |
| **Ischio-jambiers** | Leg curl assis/couché, charnière de hanche, soulevé de terre roumain **si compétence appropriée** | Jambes → Ischio-jambiers → Flexion / Charnière → Matériel → Paramètres. |
| **Fessiers / hanches** | Hip thrust, pont fessier, abduction machine/élastique, extension de hanche, fente adaptée, extension sur banc **appropriée** | Bas du corps → Fessiers / Hanche → Mouvement / Machine → Paramètres. |
| **Adducteurs / mollets** | Adduction machine/élastique, élévations mollets debout ou assis, machine mollets | Jambes → Adducteurs / Mollets → Mouvement → Charge / Répétitions. |
| **Tronc / gainage** | Planche adaptée, gainage latéral, bird dog, dead bug, Pallof press, flexion du tronc **si adaptée** | Tronc → Stabilisation / Rotation contrôlée → Position → Durée / Répétitions / Côté. |
| **Composés / corps entier** | Squat, soulevé de terre, développé, tirage, farmer carry, circuit polyarticulaire ; variantes techniques sous encadrement | Séance complète → Mouvement → Prérequis technique → Matériel → Paramètres. |

**Modèle de séance réutilisable :** `Séance bras` peut assembler **Curl biceps → Extension triceps → Curl marteau → Tirage adapté** ; ordre, charge, nombre de séries et repos sont configurables **par exercice**, non globalement imposés. `Série 1/3` et `Exercice 2/4` sont des états réels de l'outil de séance. Certains mouvements ont des répétitions ; d'autres, des secondes de maintien ou une distance (ex. portés). Il est interdit de forcer « poids × répétitions » sur une posture de gainage.

**Exemple de série précise demandé** : `Sport → Musculation → Bras → Triceps → Extension poulie → Machine : Triceps #1 → Charge prévue 10 kg → 5 séries → 5 répétitions → Repos choisi → Séance récurrente durant un mois → Valider`. Après démarrage : `Exercice Triceps · 1/5 · 10 kg · 5 rép prévues` → appui `Série réalisée` → `2/5`, etc. Une correction sur la série 3 (`8 kg, 4 répétitions`) enregistre **prévu 10 kg × 5 / réalisé 8 kg × 4**, sans réécrire les autres séries. Ces chiffres **testent le moteur**, pas la pertinence de ce volume pour une personne réelle.

**Progression :** proposer une augmentation de charge ou de volume **seulement après retour du pratiquant** sur la technique, la tolérance et plusieurs séances, avec validation explicite ; pas de pourcentage automatique applicable à tous. Une hausse de douleur inhabituelle, un vertige, une gêne thoracique ou une dégradation de capacité entraîne arrêt/orientation selon la situation. Les méthodes d'intensité avancées et l'échec musculaire ne sont ni nécessaires ni prioritaires pour un utilisateur débutant [S05].

### 51.20.3. Les machines particulières ajoutées par l'utilisateur

Une **machine est une fiche d'équipement**, pas un nouveau type de projet : l'utilisateur peut la créer dans `Sport → Musculation → Matériel → Ajouter machine` à partir des vrais outils de création disponibles, en mode expert si nécessaire. Les informations non connues restent facultatives.

**Schéma conceptuel de fiche** (à adapter aux véritables objets et API d'atome ; pas de contrat d'API affirmé) :

```yaml
id: equipement-utilisateur-001
nom: "Machine triceps de ma salle"
type: machine_guidée
mouvements_associes: [extension_triceps_poulie]
localisation: "Salle A"     # facultatif
photo_ou_picto: "reference_média_autorisée"  # pas une icône décorative isolée
position: assise
resistance:
  type: charge_affichee
  unite: kg
  increments_disponibles: [2.5, 5]  # exemple; à confirmer sur l'appareil
reglage_machine:
  siege: "valeur_declaree"
  position_poignee: "valeur_declaree"
source: utilisateur
partage: prive
```

Ne pas confondre la **charge indiquée par la machine** avec une force biomécanique comparable à celle d'une autre machine (poulies/leviers). Pour les équipements à assistance (tractions assistées), la valeur peut représenter **une assistance** plutôt qu'une résistance croissante. L'utilisateur règle la machine **dans le carré étendu** ; les paramètres de l'exercice restent associés à la même brique native. Possibilité d'éditer/archiver un appareil sans supprimer les séances historiques qui l'utilisaient ; les identifiants de machine et de mouvement restent indépendants. Les machines fournissant des données électroniques ne les transmettent qu'après **connecteur identifié, compatible et autorisé**.

**Pictogrammes à produire et à intégrer** : créer/associer pour chaque discipline et mouvement courant une icône réellement reconnaissable (silhouette et direction du geste ou équipement pertinent), cohérente avec la DA des carrés d'atome, version claire/sombre et contraste accessible, tailles cohérentes avec le gabarit, texte alternatif. **Privilégier les SVG existants** ; produire uniquement les références manquantes, valider les droits, les variantes et la compréhension. Une machine personnelle peut réutiliser le pictogramme du mouvement et une photo autorisée ; **ne pas inventer un pictogramme spécifique à toutes les marques**. Aucun visuel n'est considéré déjà généré à ce stade.

### 51.20.4. Paramètres par activité et erreurs à éviter

| Type de paramètre | Exemples et unité | Quand le montrer / ne pas le montrer |
| --- | --- | --- |
| **Séries / répétitions** | 1, 2, 3… séries ; 1… répétitions, entier | Musculation, circuits, certains exercices de mobilité ; **pas** pour une course libre. |
| **Charge / assistance** | kg, lb, résistance `niveau`, élastique caractérisé | Exercice avec charge ou machine ; préserver les valeurs natives, ne pas assimiler les « niveaux » de machines différentes. |
| **Durée / repos** | s/min/h ; récupération entre séries/intervalles | Presque toutes les disciplines, selon type. |
| **Longueur du bassin** | 25 m, 50 m ou valeur réellement choisie | Natation **en piscine seulement** ; ne pas l'inventer pour eau libre. |
| **Longueurs / tours** | entier ; distance = longueurs × longueur si données fiables | Natation bassin, piste ou circuit défini ; enregistrer modifications de longueur de bassin. |
| **Distance** | m, km, autre unité convertible | Course, marche, vélo, rameur et natation avec capteur ou saisie ; ne pas afficher de mesure comme instrumentée si seulement estimée. |
| **Vitesse / allure** | km/h ; min/km ; éventuellement m/500m sur rameur | Course/marche/rameur/vélo quand temps **et** distance sont compatibles ; distinguer objectif, saisie appareil et calcul dérivé. |
| **Cadence / puissance** | foulées/min, coups/min, tr/min, W | Seulement si appareil/capteur mesure ou si l'utilisateur peut renseigner correctement. |
| **Position / latéralité** | debout, assis, dos, ventre, genou, côté gauche/droit | Mobilité, yoga, rééducation, exercices unilatéraux et machines. |
| **Intensité perçue** | RPE 0–10, option | Sport uniquement ; ne jamais l'utiliser comme mesure objective ou autorisation d'effort extrême. |
| **Environnement / sécurité** | piscine, extérieur, tapis, risque de chute, supervision | Lorsque la pratique le requiert ; conditions météo et lieu ne sont pas des justificatifs médicaux universels. |

**Calculs de suivi autorisés si les données existent** : `distance en piscine = longueurs × bassin (m)`, `vitesse moyenne (km/h) = distance (km) / durée (h)`, `allure (min/km) = durée (min) / distance (km)`, `volume externe indicatif = somme [charge affichée × répétitions réalisées]` **uniquement à charge comparable et exercice identifié**. Prévoir cas zéro, unité inconnue, temps de pause non inclus, reprise de séance, changement d'appareil, erreurs de GPS et déclarations corrigées. Afficher la provenance et éviter de transformer une estimation en mesure physiologique.

### 51.20.5. Exécution interactive commune aux sports

- L'**occurrence acceptée dans l'agenda** lance l'outil d'activité selon les permissions et restrictions de la plateforme ; une notification iOS **ne peut pas ouvrir arbitrairement l'application en premier plan sans intervention** de l'utilisateur.
- L'outil affiche **l'étape réelle** : `Exercice 2/4 – Série 3/5`, `Longueur 7/20`, `Intervalle 2/6`, `Posture 3/8`, `Segment de course 4/5`, ou `Fin de séance`, selon sa discipline.
- **Toucher / clic sur la surface de validation de l'outil** : passe à l'étape suivante et note `terminé par l'utilisateur`, avec heure ; un geste de correction ou bouton natif permet **annuler la dernière validation, modifier répétitions/charge/distance/temps ou reporter**. Supporter lecteurs d'écran/commande vocale accessibles quand disponibles ; ne pas exiger de viser un petit point précis.
- Interactions `Démarrer`, `Pause`, `Reprendre`, `Passer`, `Corriger`, `Terminer` doivent être liées à des actions **réelles et testées**, pas des pictogrammes inertes. L'utilisateur garde le contrôle des déclenchements audio, capteurs et notifications.
- Capteurs : chaque échantillon indique source, précision si disponible, horodatage et permission ; si capteur absent, basculer vers **saisie manuelle**, pas des chiffres fictifs. Considérer les intégrations système (HealthKit, autres si la plateforme les fournit) **uniquement après vérification des capacités et autorisations**.
- Plusieurs sports dans une séance (`échauffement rameur → renforcement → marche`) sont **une seule session composée** avec trois segments horodatés, indépendamment des objectifs reliés.
- Repos et récupération sont de **vraies étapes configurables** : sans repos forcé par l'application, ni comptage comme exercice accompli.
