# Critères et recettes hérités

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §42, lignes 1329–1357.

# 42. MVP du système d’objectifs

Pour la première version fonctionnelle, prioriser :

1. création d’un objectif ;
2. choix d’un scénario ;
3. questions initiales ;
4. génération des étapes ;
5. sous-objectifs ;
6. tâches ;
7. dépendances ;
8. jalons ;
9. progression ;
10. calendrier ;
11. pièces jointes / atomes ;
12. contacts ;
13. budget simple ;
14. blocages ;
15. validation ;
16. achèvement ;
17. maintien ;
18. objectif libre ;
19. scénarios composables ;
20. architecture déclarative extensible.

La recherche externe de financement, l’annuaire public de compétences ou les systèmes avancés de recommandation peuvent être connectés progressivement sans modifier le modèle central.

---

---

Source : `Sources/objectives_original.md`, §43, lignes 1358–1386.

# 43. Premiers scénarios à implémenter réellement

Ne pas essayer d’implémenter immédiatement les centaines de scénarios avec une logique entièrement spécifique.

Créer d’abord environ 15 scénarios exemplaires couvrant des structures différentes :

1. Créer une chanson.
2. Créer un album.
3. Préparer un concert.
4. Réaliser un film.
5. Finaliser un MVP logiciel.
6. Créer une entreprise.
7. Lancer un produit.
8. Organiser un événement.
9. Trouver un financement.
10. Apprendre une compétence.
11. Perdre du poids.
12. Prendre de la masse.
13. Mieux dormir.
14. Préparer un marathon.
15. Organiser une grande randonnée.
16. Objectif libre.

Ces scénarios doivent servir à valider le moteur générique.

Ensuite, enrichir la bibliothèque principalement par données déclaratives, pas par nouvelles architectures.

---

---

Source : `Sources/objectives_original.md`, §44, lignes 1387–1413.

# 44. Critères de validation du moteur

Le moteur est considéré comme valide si l’on peut créer avec la même architecture :

- un album ;
- un marathon ;
- un film ;
- une entreprise ;
- une randonnée ;

sans créer cinq systèmes différents.

Il doit gérer correctement :

- étapes séquentielles ;
- étapes parallèles ;
- conditions ;
- dépendances ;
- budget ;
- personnes ;
- documents ;
- calendrier ;
- progression ;
- maintien.

---

---

Source : `Sources/objectives_original.md`, §45, lignes 1414–1482.

# 45. Tests obligatoires

## Test 1 — Album

Créer un album avec :

- 10 morceaux ;
- 2 collaborateurs ;
- budget ;
- mixage externe ;
- date de sortie.

Vérifier que le scénario construit le parcours complet.

## Test 2 — Marathon

Créer un objectif marathon.

Vérifier :

- progression temporelle ;
- jalons ;
- séances ;
- adaptation ;
- maintien après la course si choisi.

## Test 3 — Film

Créer un film avec :

- scénario ;
- casting ;
- budget ;
- lieux ;
- tournage ;
- montage ;
- diffusion.

## Test 4 — Entreprise

Créer une entreprise avec :

- offre ;
- administratif ;
- financement ;
- site ;
- clients ;
- lancement.

## Test 5 — Randonnée

Créer une randonnée longue avec :

- itinéraire ;
- dates ;
- transport ;
- matériel ;
- participants ;
- budget ;
- étapes.

## Test 6 — Objectif non prévu

Entrer un objectif totalement libre.

Vérifier que le système peut construire un plan sans avoir besoin d’un nouveau développement spécifique.

---

---

Source : `Sources/objectives_original.md`, §47, lignes 1495–1510.

# 47. Livrable attendu

À la fin de l’implémentation, produire :

- architecture du moteur ;
- format de scénario ;
- catalogue des scénarios ;
- scénarios effectivement implémentés ;
- briques transverses disponibles ;
- intégrations calendrier/contacts/communication/recherche/budget ;
- tests ;
- limites ;
- prochaines extensions.

---

---

Source : `Sources/objectives_original.md`, §48, lignes 1511–1534.

# 48. Definition of Done

Le système est considéré comme prêt lorsque :

- l’utilisateur peut exprimer un objectif en langage naturel ou le choisir dans une bibliothèque ;
- atome/eVe transforme l’objectif en parcours ;
- les étapes sont adaptables ;
- les dépendances fonctionnent ;
- les sous-objectifs fonctionnent ;
- la progression est significative ;
- le calendrier est relié ;
- les personnes peuvent être associées ;
- un besoin de ressource peut être représenté ;
- un budget peut être suivi ;
- un besoin de financement peut devenir une action ;
- les fichiers et atomes peuvent être liés ;
- les conditions peuvent déclencher des évolutions ;
- un objectif peut être validé ;
- un objectif peut entrer en maintien ;
- un scénario libre peut être créé ;
- de nouveaux scénarios peuvent être ajoutés sans modifier le moteur central.

---

---

Source : `Sources/objectives_original.md`, §49, lignes 1535–1562.

# 49. Instruction finale à l’agent de développement

Ne construis pas un simple gestionnaire de tâches.

Construis un **moteur universel de parcours vers un résultat**.

Un scénario pré-câblé doit être une aide de départ, pas une prison.

Le moteur doit pouvoir guider des objectifs aussi différents que :

- créer un album ;
- réaliser un film ;
- monter une entreprise ;
- courir un marathon ;
- organiser une randonnée ;
- apprendre une compétence ;
- réunir une équipe.

Utilise les mêmes primitives fondamentales :

> objectif → phases → étapes → actions → conditions → ressources → personnes → budget → preuves → validation → maintien.

Avant de créer une nouvelle fonctionnalité spécifique à un scénario, vérifier si le besoin peut être exprimé avec une brique transverse existante.

La puissance du système doit venir de la **composition**, pas de l’accumulation de code spécialisé.

---

---

Source : `Sources/objectives_original.md`, §50.7, lignes 1650–1674.

## 50.7. Ordre de réalisation et tests de validation

**Ordre de travail :**

1. **Inventaire réel** des composants de matrice, de carrés sélectionnables, de curseurs natifs, de projets, d'activités, du calendrier, des alarmes, des capteurs disponibles et du Moniteur. Noter toute capacité manquante ; ne pas inventer une API.
2. Définir ou raccorder **une seule interaction matricielle réutilisable** : carré stable, extension sur deux à trois cellules, curseur natif, validation, rétraction, navigation en profondeur et retour.
3. Raccorder cette interaction à la **matrice des projets** et au parcours de **création d'un projet** ; ne pas conserver un second flux de rectangles dispersés.
4. Mettre en œuvre et tester le scénario pilote **Mieux dormir**, en préservant le document source et en réutilisant calendrier, activités, alarmes, capteurs autorisés et Moniteur réellement existants.
5. Exposer les mêmes briques depuis la **matrice autonome Activités**, puis vérifier leur réutilisation dans un deuxième objectif sans duplication d'exécution ou de données.
6. Détailler et implémenter progressivement les **huit autres scénarios** avec leur configuration propre, sans recréer l'interface ni le moteur à chaque fois.
7. Réaliser les **tests d'usage et de régression** sur iOS/iPad, web et macOS selon les plateformes prises en charge.

**Critères d'acceptation spécifiques à cette décision :**

- Un carré de réglage **devient temporairement un rectangle aligné** occupant deux ou trois unités de grille ; son slider fonctionne, sa valeur est sauvegardée, puis il **redevient un carré** ; l'ouverture suivante restitue la valeur.
- Les autres carrés se réorganisent sans chevauchement, déformation, saut intempestif ni perte de focus/sélection, y compris sur petit écran et lors des changements d'orientation.
- Les carrés de navigation font apparaître la **bonne matrice fille** et permettent retour, reprise et validation sans créer des doublons.
- La vue de **création de projet**, les projets existants, les neuf objectifs de santé et la bibliothèque **Activités** présentent le **même langage visuel** et des modules réels, non des simulations décoratives.
- Une même activité (par exemple Natation) fonctionne depuis un projet et depuis **Activités** avec les mêmes paramètres et outils ; sa planification et son suivi ne dupliquent ni occurrence ni comptage.
- Les rappels ouvrent le contexte pertinent seulement selon les **capacités autorisées de la plateforme** ; aucun capteur indisponible ou non autorisé n'est présenté comme actif.
- Le Moniteur sépare activité réalisée, bénéfice observé, déclaration utilisateur et mesure instrumentée ; pause, reprise et modifications n'effacent pas l'historique.
- Depuis **Activités → Compléments alimentaires**, l'utilisateur peut consulter des **suggestions facultatives**, **ajouter manuellement** un produit absent des suggestions, retrouver sa configuration, planifier ou enregistrer une prise s'il le décide, sans création d'un deuxième moteur ni recommandation de dosage automatique.

**Décision de design à conserver : une seule grammaire visuelle matricielle dans atome/eVe, des carrés comme unité de base, des expansions temporaires pour régler, et des matrices imbriquées pour approfondir.**

---

Source : `Sources/objectives_original.md`, §50.12, lignes 1768–1791.

## 50.12. Ordre de développement et critères d'acceptation complémentaires

1. **Inventorier** les véritables outils atome/eVe : composants carrés/matrice, exercices existants, pictogrammes, contrôles de valeurs, calendrier/rappels, outils d'exécution, capteurs/permissions, stockage de fichiers et mesures, import/export, Moniteur et accès aux données. Documenter leurs API et manques avant développement ; **JavaScript** pour les composants eVe, sans introduire TypeScript par défaut.
2. **Définir les briques réutilisables** : type de discipline, séance, mouvement, paramètres et unités ; occurrence de calendrier ; résultat typé et source ; référence au fichier d'origine ; liens entre projets. Réutiliser les objets et connexions réels plutôt que dupliquer leurs responsabilités.
3. **Réaliser les disciplines par lots**, avec au moins les démonstrateurs complets Musculation, Natation et Course : matrices approfondies, pictogrammes adaptés, réglages natifs, planification, lancement, avancement tactile, stockage de réalisations et retour Moniteur. Étendre ensuite sport par sport / position par position selon un inventaire priorisé.
4. **Réaliser le suivi des compléments** et les rendez-vous de bilan avec données saisies manuellement, horaires et rappels, sans prescrire automatiquement.
5. **Réaliser la brique Résultats universelle** : saisie manuelle, import d'un document, conservation de l'original, normalisation non destructive des valeurs applicables, historique, export CSV pertinent et réutilisation par plusieurs objectifs ; étendre progressivement les connecteurs réels.
6. **Valider en conditions réelles sur les plateformes prises en charge**, notamment iPad/iOS, web et macOS, dans le respect des limites des systèmes d'exploitation, capteurs et permissions.

**Tests à passer :**

- **Musculation** : configurer `10 kg, 5 × 5` sur un mouvement, l'insérer dans une séance, exécuter cinq séries avec l'appui tactile, modifier la troisième série réellement accomplie, interrompre/reprendre puis retrouver chaque série et l'historique sans duplication.
- **Natation** : définir taille du bassin, longueurs et durée cible ; enregistrer longueurs et temps réels sans montre ; associer un capteur seulement si disponible et autorisé ; retrouver unités et distance totale cohérentes.
- **Course** : afficher et enregistrer durée, distance et vitesse en km/h (ou allure explicitement convertie) ; gérer une mesure GPS absente ou refusée sans inventer de parcours.
- **Compléments** : choisir un produit proposé puis ajouter un autre produit par saisie libre ; régler une quantité déclarée et les horaires ; vérifier que l'agenda et le Moniteur ne confondent pas rappel, prise déclarée et observation médicale.
- **Résultats multi-formats** : importer un compte rendu sanguin avec plusieurs mesures, puis un résultat **non sanguin** (par exemple compte rendu d'imagerie ou d'examen fonctionnel), une donnée sportive et un questionnaire qualitatif ; conserver chaque original et ses métadonnées, exporter la série tabulaire en CSV quand possible et restituer correctement les résultats non tabulaires.
- **Évolution** : enregistrer deux bilans datés d'un même paramètre, gérer des unités non directement comparables, afficher une courbe uniquement après harmonisation validée, conserver provenance, corrections, et lier sans doublon le résultat à deux projets.
- **Vie privée / limites OS** : pas de partage implicite de bilan, pas de données fictives, pas d'ouverture forcée non autorisée depuis une notification, pas de changement automatisé de dosage ou de prise en charge médicale.

**Statut de ces sections : spécification fonctionnelle, non preuve que les modules, pictogrammes, connecteurs et capteurs sont déjà implémentés.**


---

---

Source : `Sources/objectives_original.md`, §51.24, lignes 2302–2331.

## 51.24. Trois parcours de démonstration de bout en bout et multi-objectifs

### Parcours A — Sommeil, effort doux, sans hypothèses arbitraires

1. Dans la matrice des projets, choisir `OBJ-02 Mieux dormir`.
2. Préciser `réveils fréquents`, puis `travail à horaires habituels` si réel ; accepter de consigner le sommeil sur quelques jours, refuser toutes les autres questions facultatives.
3. Sélectionner `Effort 2` dans son **carré extensible** ; régler `Temps disponible : 90 min/semaine`, cinq jours + quatre soirs dans la configuration de l'exemple (51.3).
4. eVe propose `Lumière matinale : 10 min × 5` et `Rituel apaisant : 10 min × 4`, plus `Journal léger` en option. **Aucune natation, régime ou mélatonine par défaut**.
5. Chaque choix ouvre une sous-matrice ; réglage du temps dans le carré étendu, validation et réduction en carré. L'utilisateur peut refuser le rituel et choisir une autre brique.
6. Le **calendrier commun** affiche les propositions ; après confirmation, les occurrences nourrissent `Aujourd'hui`. À la notification, l'utilisateur ouvre l'activité ciblée si son appareil le permet.
7. Le Moniteur conserve heures de lever, perception du repos, observance et provenance ; une insomnie persistante donne accès à une matrice `Aide → Professionnel / TCC-I`, pas à une escalade arbitraire d'effort.

### Parcours B — Prise de muscle et appareil personnel

1. `OBJ-03 → Masse → Effort 3 → Temps 120 min/semaine` ; choisir en connaissance de cause **2 séances de 40 min** et **2 créneaux préparation de repas de 20 min** (total **120 min**, sans compter un trajet non renseigné).
2. `Musculation → Bras → Triceps → Extension → Ma machine`; l'utilisateur crée/choisit une **fiche machine** si nécessaire, puis configure charge, séries, répétitions et repos par carrés extensibles.
3. Une séance réutilise les mêmes mouvements et paramètres que `Activités → Sport → Musculation`; le programme est une composition, pas une nouvelle bibliothèque de machines.
4. Lors de la séance, écran d'exercice au premier plan, appui pour chaque série, correction d'une répétition, pause, reprise ; enregistrement du réalisé et du prévu.
5. Si un autre objectif (`OBJ-09 Condition physique`) est actif, **la séance de bras apparaît une fois dans l'agenda** et peut alimenter deux bilans, sans double comptage.
6. La Nutrition propose les **sources alimentaires** ; un complément protéique ou de créatine reste une **option** évaluée selon le contexte et éventuellement par le professionnel.

### Parcours C — Sport libre, résultats et suivi de prévention

1. Sans projet, ouvrir `Activités → Sport → Natation → Piscine → 25 m → Crawl → 12 longueurs → Valider` ; les valeurs sont **saisies par la personne**, pas un exercice imposé.
2. Au démarrage réel, le compteur avance **1/12…12/12** par appui ; la distance calculée est **300 m** uniquement si les 12 longueurs et la taille de bassin sont confirmées ; la durée est chronométrée ou saisie selon disponibilité.
3. Le résultat sportif rejoint `Résultats`, source `saisie utilisateur`, et peut ensuite être **lié volontairement** à `OBJ-09`.
4. Par ailleurs, un contrôle médical indiqué par un professionnel est programmé dans le **même agenda**. Lorsque le rapport est reçu, son PDF original et les mesures vérifiées sont stockés dans `Résultats`, séries CSV possibles si adaptées.
5. Le Moniteur affiche séparément la progression en piscine et le résultat médical ; **il n'en déduit pas qu'un changement biologique est causé par la natation**.

---

Source : `Sources/objectives_original.md`, §51.26, lignes 2356–2373.

## 51.26. Ordre de réalisation : une bibliothèque unique avant les douze programmes

**Lot 0 — Inventaire réel :** examiner les objets et outils existants, API, permissions, formats et comportement sur Web, macOS, iPad/iOS ; dresser la matrice `réutilisable / à adapter / absent`. Exemples de composants à auditer : matrice carrée, extension de cellule, curseur, outil de séance, calendrier/alarme, Dashboard, Finder, Moniteur, capteurs, import/export et fichiers d'atome.

**Lot 1 — Contrats et accessibilité :** arrêter identifiants, paramètres typés et unités, provenance, correction, consentement et confidentialité ; valider la matrice imbriquée, le carré extensible, le suivi de focus et l'interface touch/VoiceOver. Prévoir tests hors ligne et sans capteur.

**Lot 2 — Première bibliothèque de briques :** rendre utilisables `Effort`, `Temps`, `Marche`, `Rythme sommeil`, `Rituel`, `Nutrition repas`, `Séance de musculation`, `Résultats`, `Rendez-vous`, `Journal`, `Moniteur`. **Même objet réutilisable** en projet et en `Activités`.

**Lot 3 — Trois pilotes complets :** `OBJ-02 Sommeil` **refait médicalement**, `OBJ-03 Masse musculaire` avec machines personnelles, séries et correction, `OBJ-09 Condition physique` avec rameur/course/natation. Tests réels sur **iPad de préférence** puis Web et macOS selon disponibilité, sans affirmer pouvoir ouvrir automatiquement une application iOS en arrière-plan.

**Lot 4 — Nutrition et santé :** compléter repas, catalogue suppléments facultatifs, suivi des prises déclarées, agenda de rendez-vous et stockage des résultats multi-formats (CSV pour séries tabulaires et **original conservé**), puis les modules de prudence clinique et d'aide professionnelle.

**Lot 5 — Compléter les autres objectifs :** `OBJ-01`, `OBJ-04` à `OBJ-08`, `OBJ-10` à `OBJ-12` par **assemblage et configuration**, pas par duplication de scènes, de tableaux de bord ou de systèmes d'alarme.

**Lot 6 — Étendre le sport** : pictogrammes référencés, mouvements machine/poids du corps, variantes, piscine, rameur, tapis, vélo, yoga/mobilité, puis autres disciplines du catalogue 51.20 ; enrichissement **par fiches de données et outils réutilisés**. Un sport non catalogué doit rester lançable en suivi manuel minimal.

**Lot 7 — Revue médicale et maintenance scientifique** : validation par des professionnels compétents des scénarios et conseils, documentation de leur niveau de preuve, contre-indications et mises à jour de recommandations ; possibilité de retirer une proposition dangereuse sans corrompre l'historique des utilisateurs. Chaque valeur « par défaut » médicale devra faire l'objet d'une validation spécifique ; en l'absence de validation, demander la préférence ou afficher « pas de valeur recommandée ».

---

Source : `Sources/objectives_original.md`, §51.27, lignes 2374–2398.

## 51.27. Tests de réception spécifiques et obligatoires

| Cas de test | Procédure de bout en bout | Réussite exigée |
| --- | --- | --- |
| **Matrice universelle** | Entrer par Projets, Créer, Sommeil, revenir, ouvrir Activités puis Sport. | Mêmes carrés, proportions, navigation profonde et retour cohérents, sans panneaux génériques. |
| **Carré de temps** | Cliquer `Temps`, étendre sur 2–3 cellules, régler 90 min/semaine, refermer, rouvrir. | Valeur préservée, grille réorganisée sans recouvrement, focus/lecteur d'écran conservé. |
| **Effort vs capacité** | Mettre Effort 5 et indiquer une capacité très limitée ou un besoin d'avis médical. | **Aucune** séance intense, charge lourde, régime restrictif ou cure générée automatiquement. |
| **Budget et partage** | Activer OBJ-03 + OBJ-09, partager une séance de 40 min dans les deux. | Temps compté **une fois**, occurrence unique, résultats distincts par objectif. |
| **Sommeil refait** | Déclarer difficultés d'endormissement, temps 90 min, refuser nutrition et sport. | Parcours court, aucune natation/mélatonine ajoutée ; orientation TCC-I possible en cas d'insomnie chronique. |
| **Douleur / anomalie** | Signaler un symptôme potentiellement grave, puis essayer de lancer une activité aggravante. | Affichage prudent d'orientation et blocage de **la recommandation inappropriée**, sans diagnostic affiché. |
| **Musculation avec machine créée** | Ajouter machine personnelle, sélectionner triceps, configurer test 5×5 et 10 kg, valider chaque série, corriger série 3. | Machine enregistrée comme équipement ; série suivante au toucher ; valeurs prévues/réelles historisées, modification rétroactive non destructive. |
| **Natation** | Choisir bassin 25 m, 12 longueurs, terminer à la main sans montre. | 12 étapes et 300 m calculés **seulement après validation** ; source « déclarée », pas « mesure capteur ». |
| **Rameur / course** | Enregistrer distance, durée, résistance ou cadence selon discipline ; afficher km/h ou m/500m seulement si possible. | Valeurs dérivées cohérentes, nulls et unités gérés, aucun champ inventé. |
| **Positions et variantes** | Passer d'une extension triceps machine à une planche statique et un étirement. | Paramètres propres : charge/répétitions **ou** durée/position, pas formulaire universel incohérent. |
| **Activités libres** | Lancer natation depuis Activités, puis lier après coup le résultat à OBJ-09. | **Même brique fonctionnelle**, pas de création d'une deuxième performance. |
| **Complément** | Ajouter vitamine B12 manuellement, modifier concentration, renseigner un horaire, ignorer un rappel. | Ni dose proposée comme prescription, ni prise inférée du rappel, historique conservé. |
| **Résultats** | Importer PDF biologique, image d'examen non chiffré, observation sportive et note personnelle autorisée. | Originaux conservés, exports CSV seulement si pertinents, unités et droits distincts. |
| **Rendez-vous** | Créer rendez-vous médical, reporter, puis importer un compte rendu quelques jours après. | Statuts séparés planifié/effectué/document reçu ; lien facultatif, audit disponible. |
| **Bien-être et santé mentale** | Sélectionner loisirs, puis signaler une détresse importante ; refuser une collecte d'humeur. | Pas de diagnostic ni analyse forcée du journal ; ressources d'aide accessibles, confidentialité respectée. |
| **Rajeunissement** | Choisir amélioration de l'apparence, examiner un « booster NAD » et préférer photoprotection. | Photoprotection plausible ; produit expérimental **non présenté comme rajeunissant prouvé**. |
| **Historique / retour arrière** | Ajuster une séance après trois semaines, désactiver une brique, restaurer un ancien programme. | Activités passées et résultats restent datés ; la version active évolue sans réécrire le passé. |
| **iPad et OS** | Vérifier navigation tactile/VoiceOver et rappel calendrier en écran verrouillé, permissions refusées. | Pas d'ouverture iOS forcée illicite ni capteur « actif » fictif ; accès alternatif manuel. |

La **réussite médicale** ne se mesure pas uniquement à l'ouverture d'un projet : les conseils doivent être traçables, proportionnés, sans promesses trompeuses et révisables après intervention humaine. La **réussite produit** exige que les vrais outils d'atome/eVe exécutent réellement la planification, les étapes et l'enregistrement.
