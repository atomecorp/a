# Personnes, ressources, financement et assistant

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §26, lignes 902–939.

# 26. Sous-objectifs réutilisables

Certaines fonctions doivent exister comme scénarios transverses appelables depuis n’importe quel objectif.

Exemples :

- trouver une personne ;
- trouver une compétence ;
- recruter ;
- trouver un prestataire ;
- obtenir un avis ;
- trouver un financement ;
- trouver du matériel ;
- acheter ;
- louer ;
- réserver ;
- comparer ;
- apprendre ;
- contacter ;
- demander une autorisation ;
- obtenir un document ;
- créer un budget ;
- créer un planning ;
- faire une recherche ;
- organiser une réunion ;
- faire valider une étape ;
- publier ;
- communiquer ;
- promouvoir ;
- mesurer ;
- tester ;
- corriger ;
- maintenir.

Ces briques doivent pouvoir être injectées automatiquement dans des scénarios différents.

---

---

Source : `Sources/objectives_original.md`, §27, lignes 940–978.

# 27. Personnes, contacts et mise en relation

Le système d’objectifs doit pouvoir dire :

> Pour continuer, il te manque une personne ayant telle compétence.

Il peut alors :

1. chercher dans les contacts existants ;
2. chercher dans l’équipe du projet ;
3. chercher dans un annuaire interne si disponible ;
4. proposer de publier une demande ;
5. préparer un message ;
6. suivre les réponses ;
7. ajouter la personne au projet après accord.

Types de besoins :

- musicien ;
- ingénieur du son ;
- graphiste ;
- développeur ;
- acteur ;
- technicien ;
- coach ;
- expert ;
- prestataire ;
- partenaire ;
- investisseur ;
- sponsor ;
- bénévole ;
- participant ;
- mentor ;
- collaborateur.

La mise en relation doit respecter les permissions, le consentement et les règles de confidentialité.

---

---

Source : `Sources/objectives_original.md`, §28, lignes 979–1017.

# 28. Financement intégré aux objectifs

Tout scénario pouvant nécessiter de l’argent doit pouvoir activer un module financement.

Fonctions :

- budget estimatif ;
- budget disponible ;
- écart ;
- coûts obligatoires ;
- coûts optionnels ;
- échéances ;
- dépenses réelles ;
- financement manquant ;
- sources possibles ;
- suivi des demandes.

Sources possibles :

- fonds personnels ;
- revenus du projet ;
- précommandes ;
- crowdfunding ;
- aides ;
- subventions ;
- sponsoring ;
- mécénat ;
- investisseurs ;
- partenaires ;
- prêt ;
- mutualisation ;
- apport en nature.

Le système doit pouvoir proposer une action lorsque :

> financement disponible < financement nécessaire.

---

---

Source : `Sources/objectives_original.md`, §29, lignes 1018–1043.

# 29. Ressources et fichiers

Chaque étape doit pouvoir attacher :

- atomes ;
- documents ;
- images ;
- audio ;
- vidéo ;
- liens ;
- notes ;
- contacts ;
- conversations ;
- rendez-vous ;
- budgets ;
- lieux ;
- équipements ;
- versions ;
- livrables.

Le système d’objectifs ne doit pas créer un silo séparé.

Il doit orchestrer les objets déjà présents dans atome/eVe.

---

---

Source : `Sources/objectives_original.md`, §32, lignes 1084–1106.

# 32. Assistant IA

L’assistant doit jouer le rôle de guide, mais le moteur d’objectifs ne doit pas dépendre entièrement de lui.

L’assistant peut :

- comprendre un objectif formulé naturellement ;
- proposer le meilleur scénario ;
- adapter un scénario ;
- détecter une étape manquante ;
- reformuler un objectif trop vague ;
- proposer une prochaine action ;
- expliquer un blocage ;
- aider à chercher une ressource ;
- proposer des alternatives ;
- préparer un message ;
- produire un résumé ;
- comparer progression réelle et prévue.

Les scénarios fondamentaux doivent rester exploitables sans génération IA.

---
