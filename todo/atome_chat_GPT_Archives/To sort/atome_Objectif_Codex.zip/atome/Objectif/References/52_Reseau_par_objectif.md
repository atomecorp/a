# 52. Mise en relation facultative entre personnes partageant un objectif

**Décision ajoutée à la demande du porteur du projet.** Cette section complète toutes les entrées d'objectif, les douze scénarios de santé, les objectifs génériques et les objectifs ajoutés ultérieurement. Elle ne crée pas un treizième objectif de santé : c'est une capacité transversale.

## 52.1. Une option dès le début de chaque objectif

Après le choix ou la création de l'objectif, proposer dans la matrice une brique facultative « Avec d'autres ». Son ouverture présente : **« Voulez-vous être en contact avec des personnes qui partagent le même objectif que vous ? »** Les choix sont **Oui**, **Non**, **Plus tard**, sans réponse affirmative présélectionnée. Le parcours individuel continue sans pénalité avec Non, Plus tard ou aucune réponse. Un besoin d'aide urgente reste prioritaire ; l'invitation sociale ne retarde pas l'accès au soin.

La préférence est **propre à cet objectif et à cette personne**. Elle n'active pas automatiquement les autres objectifs, ni un objectif créé par copie. Elle peut être modifiée ensuite dans la même brique, sans refaire le programme.

## 52.2. Ce que signifie accepter

« Oui » ouvre les possibilités de mise en relation. Ce n'est ni une publication de dossier ni une invitation envoyée à tous les contacts. Les choix suivants restent distincts : rechercher des participants ; autoriser la visibilité de son propre thème déclaré ; demander une mise en relation ; accepter une demande reçue ; partager un élément déterminé ; participer à une activité ou un groupe.

Avant toute visibilité, la personne choisit le thème et les informations effectivement présentés : nom ou pseudonyme disponible, avatar carré natif et objectif **explicitement déclaré comme partageable**. La prévisualisation doit montrer exactement ce qu'un tiers verra. Le titre privé d'un projet peut être différent du thème partageable. Aucun thème n'est inféré depuis un diagnostic, un résultat, un texte privé ou les capteurs. Les règles de rapprochement se fondent sur ce thème déclaré, éventuellement une langue ou des disponibilités consenties. Géolocalisation précise et carnet de contacts complet ne sont pas requis.

## 52.3. Un réseau intégré aux outils d'atome/eVe

Réutiliser les contacts, avatars carrés, outils de communication, invitations, partages et éventuels groupes réellement présents. L'accès aux participants reste une **matrice**, pas un nouveau fil social conventionnel, des cartes profil génériques, des compteurs de popularité ou un système de messagerie concurrent. Cliquer sur une personne ouvre le véritable outil de contact ; ses options natives restent avec lui.

Parcours : `Objectif → Avec d'autres → Choix du thème partageable / Visibilité → Personnes partageant l'objectif → Personne → Demander un contact → Acceptation réciproque → Communication / Partage choisi`.

Le rapprochement doit exclure l'utilisateur courant, les personnes bloquées et les profils non autorisés à être proposés. Absence de résultat, service indisponible ou permission manquante ne doit jamais produire de faux participants. Un objectif libre utilise un thème choisi par l'utilisateur, pas une déduction automatique du contenu privé.

## 52.4. Partager et pratiquer ensemble

Permettre une conversation ou une activité commune au moyen des capacités réelles du projet, après accords nécessaires. Réutiliser l'occurrence de calendrier et les invitations existantes. Une activité collective peut relier plusieurs personnes ; **chacune conserve ses propres données, paramètres, consentements et résultats**. Ni le poids, ni les charges, ni les objectifs alimentaires d'un membre ne sont copiés vers les autres.

Un partage désigne un élément précis et ses destinataires : activité, créneau, conseil libre, document ou résultat sélectionné. Les originaux médicaux, journal intime, traitements, doses, localisation et données des capteurs restent privés par défaut. Un score ou un classement comparant santé, corps ou rapidité de progression ne fait pas partie de ce périmètre. Les échanges entre pairs ne deviennent pas des prescriptions du système.

## 52.5. Retrait, protection et conservation

Prévoir retrait de visibilité, refus d'une demande, retrait d'un groupe, blocage et signalement. Le retrait arrête les nouvelles propositions de profil et les nouveaux accès concernés, y compris côté serveur, index et caches maîtrisés. Il ne supprime pas l'objectif individuel ni ses résultats privés. Ne pas promettre d'effacer une copie déjà exportée chez un destinataire : distinguer retrait d'accès, suppression locale et contenu déjà partagé.

Les droits doivent être testés avec deux comptes et un tiers non autorisé. Ne pas se contenter de masquer un carré côté interface. Les règles de modération, traitement des signalements, protection des mineurs et validation des mentions de consentement doivent être définies avant ouverture réelle du réseau ; pas de communauté de santé publique sans mécanisme de protection opérationnel. Pas de profilage sensible automatique, pas de partage implicite avec le Moniteur ou l'IA.

## 52.6. Cinq briques de spécification réutilisables

| Identifiant conceptuel | Fonction | Réutilisation |
| --- | --- | --- |
| BR-SOC-01 | Option initiale, préférence par objectif et consentements séparés | Tous les objectifs, au début puis modifiable dans leur matrice. |
| BR-SOC-02 | Découverte autorisée de personnes par thème déclaré | Même annuaire et mêmes règles de visibilité, sans exposition du projet privé. |
| BR-SOC-03 | Demande de contact et communication réciproque | Véritables outils Contacts et Communication à inventorier. |
| BR-SOC-04 | Partage sélectif, groupe et activité commune | Réutilisation des objets de partage, calendrier et activités. |
| BR-SOC-05 | Retrait, blocage, signalement et modération | Protection commune de tous les parcours. |

Ces identifiants ne sont **pas** des noms d'API certifiés. Leur mapping technique est une tâche d'audit. Les nouvelles briques complètent les 72 briques de la section 51.4, sans remplacer BR-VIE-04, qui reste la brique générale de liens sociaux.

## 52.7. Recette obligatoire

Vérifier les douze objectifs et un objectif libre : option au début ; Non/Plus tard sans inscription sociale ; Oui avec prévisualisation des données réellement exposées ; deux personnes optantes rapprochées par thème ; aucune fuite du journal, des examens ou des capteurs ; contact réciproque ; partage d'une seule activité sans accès au programme entier ; retrait de visibilité ; blocage effectif ; absence de doublon d'occurrence ; aucun effet sur les autres objectifs. Valider visuellement **chaque** nouvelle matrice, détail de personne, état d'invitation et écran de partage avant intégration.
