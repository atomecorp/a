# Agenda, alarmes et exécution

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §30, lignes 1044–1064.

# 30. Calendrier

Une étape peut produire :

- une date cible ;
- une échéance ;
- un rendez-vous ;
- une répétition ;
- une session de travail ;
- une période de suivi ;
- un rappel ;
- un jalon.

Les changements de planning doivent être propagés lorsqu’ils affectent des dépendances.

Exemple :

> Le mixage est retardé de 4 jours → le mastering et la date de livraison doivent être signalés comme potentiellement impactés.

---

---

Source : `Sources/objectives_original.md`, §31, lignes 1065–1083.

# 31. Conditions et automatisations

Le moteur doit pouvoir exploiter des conditions.

Exemples :

- si budget >= montant requis → débloquer réservation ;
- si tous les morceaux sont validés → proposer mastering ;
- si une personne accepte l’invitation → l’ajouter à l’étape ;
- si la date approche → augmenter la priorité ;
- si un jalon est en retard → proposer replanification ;
- si la métrique cible est atteinte → passer en maintien ;
- si une ressource manque → déclencher une recherche ;
- si un fichier est validé → débloquer l’étape suivante.

Les conditions doivent être séparées des interfaces spécifiques afin de rester réutilisables dans tous les modules.

---

---

Source : `Sources/objectives_original.md`, §41, lignes 1312–1328.

# 41. Notifications intelligentes

Éviter les rappels inutiles.

Notifier principalement lorsque :

- une action devient disponible ;
- une échéance approche ;
- une dépendance bloque ;
- une personne répond ;
- une condition importante change ;
- un objectif dérive ;
- un jalon est atteint ;
- une validation est nécessaire.

---

---

Source : `Sources/objectives_original.md`, §50.4, lignes 1604–1632.

## 50.4. Scénarios des objectifs de santé : partir du besoin, composer, puis agir

**Référence de départ : les neuf objectifs de santé convenus dans nos échanges.** Les 24 propositions de la section 15 restent un **catalogue de possibilités** et ne doivent pas être confondues avec cette sélection initiale. La liste de travail est :

1. **Perdre du poids**.
2. **Mieux dormir et retrouver de l'énergie**.
3. **Prendre de la masse musculaire**.
4. **Gérer une douleur**.
5. **Repérer un trouble et orienter vers un professionnel**, sans diagnostic autonome.
6. **Préserver du temps pour soi**.
7. **Retrouver le calme intérieur** (dont méditation).
8. **Tenir un journal personnel** (expression, ressenti, création).
9. **Améliorer sa condition physique**.

Pour **chacun** de ces neuf projets-objectifs, le scénario devra préciser les mêmes phases et objets réutilisables, mais des briques, activités et observations adaptées au but :

1. **Entrée dans l'objectif.** Le choix de l'objectif se fait depuis une matrice ; l'utilisateur peut aussi exprimer un besoin libre. Reprendre un projet existant ne le recrée pas.
2. **Point de départ.** Collecter uniquement les données déjà disponibles et autorisées ; si elles sont insuffisantes pour proposer un programme pertinent, demander progressivement les quelques informations utiles. Ne pas imposer un questionnaire complet.
3. **Implication.** Proposer les carrés ajustables **Effort souhaité / rythme** et **Temps disponible**, puis leurs curseurs par extension dans la grille. Respecter ce que la personne accepte réellement.
4. **Composition.** Proposer une **matrice de briques transversales** pertinentes (par exemple détente, méditation, nutrition, mouvement et habitudes pour Mieux dormir), sans déclarer ces activités universellement nécessaires ni cliniquement efficaces.
5. **Approfondissement.** Un carré sélectionné peut ouvrir une matrice plus précise, jusqu'à une activité concrète et ses paramètres. Exemple : **Mieux dormir → Activité physique → Sport → Natation → Durée / fréquence → Validation**. Les contenus exacts restent dépendants de la situation ; Natation est une démonstration de navigation, pas une recommandation sommeil universelle.
6. **Validation.** L'utilisateur accepte, modifie ou refuse les briques et la charge. Une brique acceptée devient une activité réelle du programme, avec sa configuration conservée et une identité stable.
7. **Projet Dashboard.** Une fois le programme validé, le projet se présente dans un **mode Dashboard**, regroupant les activités à réaliser, notamment pour **Aujourd'hui**. Ce n'est ni un deuxième projet sans lien ni une application de santé séparée : il s'agit d'une présentation du projet-objectif et de ses activités.
8. **Calendrier.** Les occurrences acceptées sont proposées au **calendrier commun d'atome** avec horaires, durées, rappels, récurrences et possibilité de modification ; aucune planification définitive sans choix/autorisation de l'utilisateur. Une action n'existe qu'une fois même si plusieurs objectifs la partagent.
9. **Au moment de l'activité.** Le rappel doit permettre d'ouvrir le **projet et l'activité concernée au premier plan**. Lorsque le système d'exploitation le permet et après les autorisations requises, déclencher les capteurs pertinents **au démarrage effectif de l'activité** et suivre les données disponibles ; ne pas inventer de mesure. Sur iOS notamment, une notification ne doit pas être documentée comme capable d'ouvrir arbitrairement une app sans action de l'utilisateur si l'OS ne le permet pas.
10. **Résultat et adaptation.** Enregistrer réalisation, données mesurées autorisées, ressenti et contexte avec leur provenance. Le **Moniteur commun** rapproche ces observations, propose un bilan nuancé et permet d'ajuster, alléger, suspendre ou reprendre le programme sans effacer l'historique.

**État documentaire :** `Scenario_Sommeil.docx` est la référence détaillée du premier scénario (concept, visuels et garde-fous). **Les huit autres scénarios doivent encore être décrits individuellement** en réutilisant le même socle, avec leur logique propre. Les éléments ci-dessus sont une règle transversale, pas une prétention à neuf scénarios complets.

---

Source : `Sources/objectives_original.md`, §50.9, lignes 1695–1731.

## 50.9. Activités sportives — matrices spécialisées, paramètres et exécution interactive

**Décision complémentaire du 11 octobre 2026.** Le fonctionnement détaillé de « Musculation » n'est **pas une exception ni une démonstration sans suite** : chaque discipline proposée dans **Activités → Sport** doit être déclinée en **matrices de sous-activités réellement configurables**, avec des pictogrammes adaptés et des paramètres spécifiques à sa pratique. Le même modèle s'applique aux activités sportives intégrées à un objectif et à celles démarrées librement. Il faut **décrire et réaliser progressivement chaque discipline**, sans prétendre que le catalogue exhaustif ou les pictogrammes existent déjà.

**Navigation commune, toujours matricielle :**

`Activités / Projet → Sport → Discipline → Séance ou mouvement → Équipement / exercice / variante → Paramètres → Valider / Planifier / Démarrer`

- Chaque niveau part de **carrés alignés dans la matrice d'atome** ; un carré de sélection ouvre la matrice fille. Un carré de paramètre s'étend temporairement en rectangle de **deux ou trois unités de grille**, affiche le véritable contrôle natif (curseur, sélecteur, saisie), enregistre la valeur puis redevient carré.
- Chaque activité ou mouvement possède un **pictogramme reconnaissable et cohérent** avec le vocabulaire graphique existant ; le pictogramme correspond à l'exercice réel et non à une icône générique décorative. Les ressources visuelles à concevoir sont des livrables, pas des composants supposés déjà disponibles.
- Les choix de mouvements, de machines et de positions reposent sur des **éléments réutilisables** et des références stables : une séance peut assembler plusieurs exercices et les ordonner, sans créer une copie de l'outil pour chaque usage.
- Un **socle commun d'activité** conserve identité, objectifs associés, variantes, durée, fréquence/récurrence, horaire, conditions, contraintes, suivi, provenance, historique et paramètres effectivement pertinents. Les **paramètres spécifiques** ne s'affichent que pour les disciplines auxquelles ils s'appliquent. Une mesure facultative inconnue reste « non renseignée ».

**Déclinaison par pratique — première grille de spécifications à approfondir discipline par discipline :**

| Discipline / contexte | Matrices et briques spécialisées | Réglages pertinents, selon la pratique | Suivi d'exécution |
| --- | --- | --- | --- |
| **Musculation / machines / poids libres** | Séance (par ex. bras) → groupes musculaires → machine ou mouvement (par ex. triceps) → série. Variantes possibles : appareil, haltères, barre, poids du corps. | Charge et unité (kg), **nombre de séries**, **répétitions par série**, durée de repos, durée totale, périodicité, progression/objectif sur une période. Éventuellement unilatéral/bilatéral, résistance, assistance, tempo si disponibles et utiles. | Afficher le mouvement courant et la série courante. **Un appui tactile valide la série réalisée et affiche la suivante**, sans ressaisie inutile ; possibilité de corriger le nombre réel de répétitions/la charge, de passer, de mettre en pause ou d'annuler. Enregistrer la réalisation effective de chaque série et de la séance. |
| **Natation / piscine** | Natation → nage / type de séance → bassin / exercice → longueur ou intervalle. | Longueur du bassin (m), **nombre de longueurs**, distance totale, durée, cadence/allure, séries et récupérations, fréquence ; unités explicites. | Avancer à la longueur ou à l'intervalle suivant, consigner longueurs et temps réels, distinguer saisie tactile de données de montre/capteur réellement disponible. |
| **Course / marche / tapis** | Course ou marche → environnement (extérieur, piste, tapis) → séance / intervalle. | **Distance (km ou m)**, **durée**, vitesse (**km/h**), allure (min/km), fractionnés/répétitions, récupération, fréquence ; GPS facultatif en extérieur, vitesse du tapis déclarée si applicable. | Départ, pause, reprise, arrivée ; distance, durée et allure selon source réelle ; correction manuelle et enregistrement d'un parcours uniquement si autorisé. |
| **Cyclisme / vélo d'intérieur** | Vélo → extérieur / appareil → séance / segment. | Distance, durée, vitesse, dénivelé, résistance ou puissance uniquement si l'équipement et ses données existent, intervalles et cadence facultatifs. | Suivi des segments, interruptions, provenance des données et bilan. |
| **Mobilité / étirements / yoga / exercices au sol** | Discipline → zone ou objectif → **position / mouvement**, accompagné de son pictogramme → séquence. | Tenue de position, nombre de passages, côté du corps, répétitions, repos, intensité ressentie et durée, lorsque pertinent. | Passer à la position suivante, enregistrer durée réellement tenue, adaptations et ressenti. |
| **Autres sports / activités non cataloguées** | Même matrice, discipline configurable par briques disponibles ; extension du catalogue après validation des critères propres. | Paramètres choisis **selon la discipline**, pas formulaire universel imposant charge/séries/distance à tous. | Démarrage et journal d'activité utilisables même sans capteur ni modèle spécialisé ; ne pas afficher une fonctionnalité non implémentée. |

**Exemple musculation demandé, non prescriptif :** `Sport → Musculation → Bras → Triceps → Appareil / mouvement → Charge : 10 kg → 5 séries × 5 répétitions → Programme d'un mois → Valider`. Ces valeurs **illustrent le paramétrage** et ne sont pas des recommandations d'entraînement. Les charges, répétitions, séries, volumes et progressions restent modifiables et enregistrent leurs changements dans le temps.

**Lancement depuis le calendrier et interaction en séance :**

1. Une activité acceptée est reliée à une **occurrence du calendrier commun** (date/heure, durée, récurrence, notification selon les autorisations). Le projet Dashboard affiche la même activité, sans doublon.
2. Un rappel peut **ouvrir directement l'activité ou son contexte** lorsqu'on l'active ; ne pas promettre qu'une notification iOS impose automatiquement l'ouverture de l'application au premier plan sans intervention de l'utilisateur.
3. L'**outil réel de séance** se place au premier plan dans l'environnement d'atome avec l'exercice courant, son pictogramme et les réglages déjà validés ; conserver le design natif, sans nouveau logiciel de fitness parallèle.
4. Pendant la séance, une action **simple et accessible au toucher** fait avancer d'une série, d'une longueur, d'un intervalle, d'une position ou d'une étape à la suivante. Permettre pause, retour/correction et arrêt sans perdre l'historique. L'action tactile ne doit pas valider une réalisation fictive en cas de contact accidentel ; confirmation/annulation ou correction selon les interactions natives.
5. Si le capteur ou l'appareil associé existe et si les autorisations sont accordées, utiliser ses **données réelles**. Sinon proposer un suivi manuel. Distinguer **planifié, démarré, déclaré accompli et mesuré**.
6. En fin de séance, conserver les valeurs **prévues et effectivement réalisées** (ex. charge et séries, longueurs, durée, distance), la provenance, la date et le ressenti. Le Moniteur exploite l'évolution sans confondre **activité réalisée** et **bénéfice démontré**.

**Exigence éditoriale pour la suite :** chaque discipline ajoutée doit disposer d'une fiche descriptive de ses **matrices successives, mouvements/positions, pictogrammes, paramètres spécifiques, unités, contrôle en cours d'activité, mesures récupérables, suivi manuel alternatif et tests**. Les pictogrammes et l'inventaire exhaustif des mouvements seront construits et vérifiés par lots, pas inventés comme déjà disponibles.

---

Source : `Sources/objectives_original.md`, §51.20.5, lignes 2225–2234.

### 51.20.5. Exécution interactive commune aux sports

- L'**occurrence acceptée dans l'agenda** lance l'outil d'activité selon les permissions et restrictions de la plateforme ; une notification iOS **ne peut pas ouvrir arbitrairement l'application en premier plan sans intervention** de l'utilisateur.
- L'outil affiche **l'étape réelle** : `Exercice 2/4 – Série 3/5`, `Longueur 7/20`, `Intervalle 2/6`, `Posture 3/8`, `Segment de course 4/5`, ou `Fin de séance`, selon sa discipline.
- **Toucher / clic sur la surface de validation de l'outil** : passe à l'étape suivante et note `terminé par l'utilisateur`, avec heure ; un geste de correction ou bouton natif permet **annuler la dernière validation, modifier répétitions/charge/distance/temps ou reporter**. Supporter lecteurs d'écran/commande vocale accessibles quand disponibles ; ne pas exiger de viser un petit point précis.
- Interactions `Démarrer`, `Pause`, `Reprendre`, `Passer`, `Corriger`, `Terminer` doivent être liées à des actions **réelles et testées**, pas des pictogrammes inertes. L'utilisateur garde le contrôle des déclenchements audio, capteurs et notifications.
- Capteurs : chaque échantillon indique source, précision si disponible, horodatage et permission ; si capteur absent, basculer vers **saisie manuelle**, pas des chiffres fictifs. Considérer les intégrations système (HealthKit, autres si la plateforme les fournit) **uniquement après vérification des capacités et autorisations**.
- Plusieurs sports dans une séance (`échauffement rameur → renforcement → marche`) sont **une seule session composée** avec trois segments horodatés, indépendamment des objectifs reliés.
- Repos et récupération sont de **vraies étapes configurables** : sans repos forcé par l'application, ni comptage comme exercice accompli.
