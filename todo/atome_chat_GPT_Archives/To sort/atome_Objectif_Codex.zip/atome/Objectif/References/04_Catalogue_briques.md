# Répertoire et correspondance des briques

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §51.4, lignes 1872–1891.

## 51.4. Répertoire initial des briques transversales — source de vérité

**Toute brique a un ID stable**, une catégorie, une finalité, un ensemble de paramètres pertinents, des activités possibles, les prérequis de sécurité, une durée estimée, des résultats et une politique de confidentialité. Un ID représente **une fonction réutilisable**, pas une capture d'écran ni une promesse qu'un outil existe déjà. Les `BR-` ci-dessous sont des **identifiants de spécification à mapper après audit**, pas des noms d'API atome actuellement certifiées.

| Domaine matriciel | Briques à inventorier / développer | Données ou décisions associées |
| --- | --- | --- |
| **Démarrage** | `BR-COM-01` intention ; `BR-COM-02` situation de départ ; `BR-COM-03` effort souhaité ; `BR-COM-04` temps disponible ; `BR-COM-05` contraintes/préférences ; `BR-COM-06` consentements ; `BR-COM-07` validation et adaptation | But, tolérance, créneaux, besoins, source des données et autorisations. |
| **Sommeil** | `BR-SOM-01` journal sommeil ; `BR-SOM-02` régularité lever/coucher ; `BR-SOM-03` lumière/rythme ; `BR-SOM-04` environnement/rituel ; `BR-SOM-05` stimulants et horaires ; `BR-SOM-06` orientation TCC-I / évaluation clinique | Heures de sommeil déclarées, horaires, réveils, somnolence, facteurs, consultations ; données des montres facultatives, non certifiées. |
| **Nutrition** | `BR-NUT-01` habitudes / bilan alimentaire ; `BR-NUT-02` choix de repas ; `BR-NUT-03` qualité des aliments et variété ; `BR-NUT-04` protéines ; `BR-NUT-05` légumes/fruits/fibres ; `BR-NUT-06` énergie/alimentation suffisante ; `BR-NUT-07` hydratation ; `BR-NUT-08` courses/préparation ; `BR-NUT-09` allergies, intolérances et adaptation | Aliments choisis, portions facultatives, fréquence, contraintes, éventuels objectifs nutritionnels **justifiés et consentis**. |
| **Activité physique** | `BR-ACT-01` marche ; `BR-ACT-02` endurance/course ; `BR-ACT-03` musculation ; `BR-ACT-04` natation ; `BR-ACT-05` rameur ; `BR-ACT-06` vélo ; `BR-ACT-07` mobilité/étirements ; `BR-ACT-08` yoga/pilates ; `BR-ACT-09` équilibre ; `BR-ACT-10` autres sports extensibles ; `BR-ACT-11` récupération/repos ; `BR-ACT-12` mouvement du quotidien | Sport → discipline → exercice → paramètres ; matériel réel ; durée, distance, charge, séries, positions, capteurs autorisés, ressenti et progression. |
| **Calme et émotions** | `BR-MEN-01` respiration confortable ; `BR-MEN-02` relaxation ; `BR-MEN-03` méditation/attention ; `BR-MEN-04` pauses et stress ; `BR-MEN-05` repérage de l'humeur ; `BR-MEN-06` activation comportementale ; `BR-MEN-07` soutien et aide professionnelle ; `BR-MEN-08` plan de sécurité personnalisé *avec professionnel lorsque nécessaire* | Ressenti volontaire, contextes, activités aidantes, rendez-vous ; **aucun diagnostic calculé automatiquement**. |
| **Vie personnelle** | `BR-VIE-01` temps pour soi ; `BR-VIE-02` loisirs/création ; `BR-VIE-03` journal privé ; `BR-VIE-04` liens sociaux ; `BR-VIE-05` limites/disponibilité ; `BR-VIE-06` organisation des routines | Créneaux choisis, activités, écrits privés, invitations explicites, objectifs qualitatifs. |
| **Santé et suivi** | `BR-SUI-01` symptômes ; `BR-SUI-02` douleur ; `BR-SUI-03` consultations/rendez-vous ; `BR-SUI-04` examens / prévention ; `BR-SUI-05` résultats multi-formats ; `BR-SUI-06` mesures / capteurs ; `BR-SUI-07` traitements déclarés ; `BR-SUI-08` compléments déclarés/proposés ; `BR-SUI-09` suivi longitudinal ; `BR-SUI-10` orientation et signaux d'alerte | Distinction prévue/effectuée/mesurée, documents originaux, unités, professionnel/source, corrections, historique, vie privée. |
| **Prévention et vieillissement** | `BR-AGE-01` prévention et suivi adapté ; `BR-AGE-02` santé fonctionnelle/autonomie ; `BR-AGE-03` peau et photoprotection ; `BR-AGE-04` capacités cognitives / activités enrichissantes ; `BR-AGE-05` santé bucco-dentaire ; `BR-AGE-06` prévention chutes/équilibre | Résultats pertinents et professionnels impliqués ; ne jamais produire « âge biologique » ou rajeunissement en années sans méthode cliniquement validée. |
| **Orchestration (déjà unifiée conceptuellement)** | `BR-SYS-01` matrice de sélection ; `BR-SYS-02` projet Dashboard ; `BR-SYS-03` calendrier/occurrences ; `BR-SYS-04` alarmes ; `BR-SYS-05` outil de séance ; `BR-SYS-06` Moniteur ; `BR-SYS-07` stockage/export ; `BR-SYS-08` consentements/partage | **Raccorder les vrais outils d'atome/eVe** plutôt que recréer un calendrier, un Moniteur, une boîte de dialogue ou une base de données par objectif. |

**Catalogue « Activités » autonome :** les mêmes domaines **Nutrition**, **Sport**, **Sommeil/Repos**, **Calme/Méditation**, **Bien-être**, **Journal**, **Suivi/Résultats**, **Compléments alimentaires** sont navigables sans projet-objectif. Un utilisateur peut par exemple lancer `Activités → Sport → Rameur`, consigner `Activités → Nutrition → Repas`, enregistrer `Activités → Suivi → Mesure`, ou créer une prise déclarée dans `Compléments`, puis **associer l'activité a posteriori** à un objectif, avec consentement et sans double comptage.

**Structure minimalement requise d'une fiche de brique :** `brick_id`, version, catégorie, nom court, pictogramme (référence vérifiée), outil natif réel associé, sous-matrices, variantes, paramètres typés + unités/bornes, valeur proposée et **statut preuve**, risques/prérequis, durée estimée, états, événements de suivi, sources de mesures, données facultatives, droits/consentements, objectifs reliés. Les réglages ne doivent pas être proposés lorsque leur discipline ne les utilise pas.

---

Source : `Sources/objectives_original.md`, §51.19, lignes 2103–2123.

## 51.19. Correspondance : objectif → briques communes et briques facultatives

Cette vue permet de construire les programmes par référence aux **mêmes composants**, non en recopiant des scénarios complets ; `C` signifie « proposition prioritaire selon contexte » et `O` signifie « option à activer selon le besoin », **jamais obligation**.

| Objectif | Briques candidates en priorité (C) | Options selon besoins (O) | Suivi central |
| --- | --- | --- | --- |
| OBJ-01 Poids | NUT-01/02/03/05, ACT-01 | ACT-03, SOM-02, NUT-08, SUI-03 | Habitudes, adhésion, éventuelles mesures consenties. |
| OBJ-02 Sommeil | SOM-01/02/04 ou SOM-05 selon cause | SOM-03, MEN-02, SOM-06, ACT-01 | Sommeil déclaré, fonctionnement diurne, tolérance. |
| OBJ-03 Masse | ACT-03, NUT-04/06, ACT-11 | SUI-08, SOM-02, SUI-03 | Séances, séries/charges réellement effectuées, récupération. |
| OBJ-04 Douleur | SUI-02/03, observation | ACT-07, MEN-02, SOM-01 | Retentissement et fonction. |
| OBJ-05 Repérer trouble | SUI-01/03/05/10 | SUI-06/07/09 | Évolution datée, avis/résultats documentés. |
| OBJ-06 Temps personnel | VIE-01/05 | VIE-02/04, MEN-04 | Temps réellement préservé, satisfaction. |
| OBJ-07 Calme | MEN-01/02/03 **au choix** | VIE-02, ACT-01 | Tolérance et calme perçu volontaire. |
| OBJ-08 Journal | VIE-03, SYS-07/08 | MEN-05, VIE-02 | Notes privées, fréquence facultative. |
| OBJ-09 Condition | ACT-01/02, ACT-03 selon capacité | ACT-04/05/06/07/09 | Durée/distance/force réellement mesurées. |
| OBJ-10 Vieillir en santé | AGE-01/02/03, ACT-03 ou ACT-09 selon cible | NUT-03/04, SOM-02, AGE-04/05/06 | Fonction, prévention, habitudes choisies. |
| OBJ-11 Bien-être | VIE-01/02/04 **selon souhait** | ACT-01, MEN-04, SOM-02 | Satisfaction et plaisir vécus. |
| OBJ-12 Santé mentale | MEN-07 si besoin, MEN-06 selon contexte | VIE-04, SOM-01, ACT-01, MEN-02/05 | Accès au soutien, ressenti et retentissement ; sécurité prioritaire. |

Les préfixes `BR-` sont omis dans ce tableau pour le rendre lisible (`ACT-03` signifie `BR-ACT-03`). Le Moniteur applique les contraintes de confidentialité **par résultat**. Si plusieurs objectifs sélectionnent la même séance ou consultation, il propose **une occurrence unique avec plusieurs liens d'objectifs**.
