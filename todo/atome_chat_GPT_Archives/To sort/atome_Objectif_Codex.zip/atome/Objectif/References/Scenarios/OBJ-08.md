# Référence de scénario OBJ-08

Source : `Sources/objectives_original.md`, §51.14, lignes 2030–2041. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.14. OBJ-08 — Tenir un journal personnel

**Matrice** : `Journal → [Écrire / Dicter / Photo / Dessiner / Humeur / Bilan libre] → Fréquence souhaitée → Confidentialité → Commencer`.

**Départ** : demander si le journal vise mémoire, expression artistique, gratitude, réflexion ou événements de santé, et **quel contenu la personne accepte de partager avec le Moniteur**. **Par défaut : journal intégralement privé**, pas de lecture automatique par l'IA ni d'exploitation à des fins de performance. Une note intime ne devient pas une observation de santé par défaut.

**Briques** : `BR-VIE-03` note/son/image/dessin natif, `BR-MEN-05` humeur si choisie, `BR-VIE-02` création, `BR-SYS-07` archive/export, `BR-SYS-08` consentement sélectif. Réutiliser les véritables outils Texte, Audio, Photo, Dessin et leurs formats d'atome quand vérifiés, plutôt qu'une imitation de prise de notes.

**Programme** : effort 1 → page libre **1–2 fois par semaine** ; effort 2 → **2–5 min** par session choisie ; effort supérieur → pages thématiques et bilans rétrospectifs, sans « streak » culpabilisant. `Journal → Nouvelle note → Texte / Audio / Dessin → Enregistrer` ; possibilité de trier sans exiger une nomenclature.

**Exécution / résultat** : ouverture au premier plan de l'outil natif à l'heure choisie ou à la demande ; sauvegarde datée avec modification, suppression et export contrôlés. **Bilan** facultatif : fréquence, utilité ressentie, thématiques **uniquement si l'utilisateur demande une analyse et désigne les notes concernées**. Éviter de transformer automatiquement une mention négative en diagnostic.
