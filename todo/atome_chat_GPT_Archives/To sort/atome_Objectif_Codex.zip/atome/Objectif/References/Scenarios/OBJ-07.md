# Référence de scénario OBJ-07

Source : `Sources/objectives_original.md`, §51.13, lignes 2018–2029. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.13. OBJ-07 — Retrouver le calme intérieur

**Matrice** : `Calme intérieur → Ce qui me convient → Effort → Temps → [Respiration / Relaxation / Méditation / Marche apaisante / Musique] → Variante → Durée → Valider`.

**Départ** : demander **ce que la personne cherche** (réduire une tension passagère, prendre du recul, trouver un moment calme) et **si certaines pratiques sont désagréables**. La méditation focalisée sur le corps peut être mal vécue par certaines personnes (anxiété, trauma) ; toujours prévoir `arrêter`, `passer`, `choisir autre chose`. Le projet n'a pas à étiqueter une personne comme « anxieuse ».

**Briques** : `BR-MEN-01` respiration *naturelle et confortable* (sans apnée forcée, hyperventilation ou objectif de saturation), `BR-MEN-02` détente musculaire facultative, `BR-MEN-03` méditation guidée non obligatoire, `BR-VIE-02` musique ou création, `BR-ACT-01` promenade tranquille, `BR-MEN-04` micro-pause. Exemple de curseur propre à la brique : durée **2–20 minutes**, librement ajustable et sans allégation de dose-thérapie.

**Parcours** : effort 1 → **2–3 minutes** d'activité plaisante lorsqu'un moment se présente ; effort 2 → **5 minutes** plusieurs jours choisis ; effort 3+ → séances un peu plus longues si souhaitées, ou variété de briques, **sans imposer une progression de durée**. `Méditation → Guidée / Silencieuse / Attention à l'environnement → Durée → Démarrer`, l'outil utilise l'audio existant d'atome si réellement disponible.

**Exécution** : minuteur ou audio avec démarrage, pause, fin ; `terminé`, `interrompu`, `trop difficile`, `à refaire` ; aucun score de qualité de méditation prétendument mesuré. **Résultat** : calme perçu avant/après de **0 à 10 si volontaire**, utilité personnelle et choix de poursuivre. Si la souffrance est intense/persistante, proposer aussi `OBJ-12` et un professionnel, sans assimiler relaxation à un traitement.
