# Référence de scénario OBJ-01

Source : `Sources/objectives_original.md`, §51.7, lignes 1922–1939. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.7. OBJ-01 — Perdre du poids

**But clinique :** améliorer durablement le comportement alimentaire, la santé et, si approprié, la composition corporelle **sans créer de restriction dangereuse ni de culpabilisation**.

**Matrice de départ** : `Objectif → Perdre du poids → Mes besoins → Effort → Temps → Alimentation / Mouvement / Sommeil / Accompagnement → Activités → Calendrier`.

**Questions minimales :** l'objectif est-il demandé librement ? Existe-t-il un avis médical pertinent, une variation de poids inexpliquée, un antécédent de trouble du comportement alimentaire, une grossesse, une maladie ou des traitements affectant l'alimentation ? Explorer plutôt habitudes de repas, environnement, faim/satiété, mobilité et disponibilité que saisir un poids cible automatique. Mesures de poids/tour de taille **facultatives**, sensibles et consenties. En cas de poids déjà insuffisant ou restriction excessive, **ne pas générer un parcours de perte de poids** ; proposer une évaluation professionnelle et des activités de santé non amaigrissantes.

**Briques proposées** (maximum 2–4 actives au début) : `BR-NUT-01` identifier une habitude modifiable ; `BR-NUT-02/03/05` composition/qualité des repas et végétaux ; `BR-NUT-08` courses/cuisine ; `BR-ACT-01/12` marche ou activité appréciée ; `BR-ACT-03` renforcement pour préserver la fonction ; `BR-SOM-01/02` sommeil si difficulté ; `BR-SUI-03` diététicien ou médecin si besoin. La brique hydratation n'est pas un substitut systématique au repas.

**Déclinaisons** : `Nutrition → Repas → Petit-déjeuner / Déjeuner / Dîner / Collation → Composer / Substituer / Préparer → Fréquence` ; `Activités → Marche → Durée / Terrain / Jour`. Si un suivi énergétique est réellement utile, ses données et calculs restent **optionnels**, limités et revus ; **pas de seuil calorique extrême, régime « détox », jeûne prolongé ou pesée compulsive imposés**. Aucune pilule « brûle-graisse » n'est suggérée.

**Parcours exemple selon le curseur** : niveau 1 = préparer **un repas habituel légèrement plus équilibré** une fois dans la semaine ; niveau 2 = organiser 2–3 repas et ajouter une petite marche confortable si acceptée ; niveau 3 = planifier cuisine et mouvements compatibles avec le budget ; niveaux 4–5 = augmenter la **régularité et le nombre de briques** sans automatiser une restriction calorique plus forte. Les événements restent modifiables dans l'agenda.

**Pendant l'action** : au créneau « Préparer le dîner », la brique Nutrition affiche le repas choisi et une validation simple ; au créneau Marche, l'outil physique suit durée/distance réelle si disponibles. `Fait` ne signifie pas « déficit calorique confirmé ».

**Résultats et revue** : satisfaction, habitudes acceptées, facilité à tenir, fonction et données corporelles consenties ; évaluation toutes les 2–4 semaines puis maintien. Alerter pour malaise, épuisement, alimentation insuffisante, obsession des chiffres ou perte de poids rapide non intentionnelle : arrêter la progression et orienter. **Repère de preuve : NICE NG246 [S04].**
