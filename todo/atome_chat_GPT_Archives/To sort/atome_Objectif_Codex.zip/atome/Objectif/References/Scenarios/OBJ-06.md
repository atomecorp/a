# Référence de scénario OBJ-06

Source : `Sources/objectives_original.md`, §51.12, lignes 2006–2017. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.12. OBJ-06 — Préserver du temps pour soi

**Matrice** : `Temps pour soi → Sources d'encombrement → Effort → Budget de temps → [Repos / Activité plaisante / Limites / Organisation] → Créneau → Valider`.

**Départ** : demander à quels moments la personne souhaite être disponible ou indisponible ; ne pas supposer des problèmes psychologiques. Option pour repérer des engagements non déplaçables, aidance familiale, travail, contraintes de transport.

**Briques** : `BR-VIE-01` espace personnel ; `BR-VIE-02` loisir/création ; `BR-VIE-05` limites à poser ; `BR-VIE-06` simplifier une routine ; `BR-MEN-04` pause facultative ; `BR-VIE-04` relation choisie. Exemples UI : **5, 10, 15, 30 ou 60 min**, valeurs librement ajustables.

**Parcours** : effort 1 → un créneau de **5–10 min, une fois dans la semaine** ; effort 2 → quelques courtes pauses ; effort 3+ → créneaux structurés avec choix d'activités, sans surestimer du temps disponible. `Activité → Musique / Lecture / Promenade / Ne rien faire / Autre` ouvre la matrice native correspondante. `Ne rien faire` est une **activité valide**, pas une omission fautive.

**Agenda/exécution** : proposition de réservation douce et révocable, rappel facultatif ; si le temps est réaffecté, l'app demande si la personne préfère reporter, jamais considérer cela comme un échec. **Résultat** : satisfaction, temps réellement protégé, ressenti de contrôle, contraintes découvertes ; la synthèse reste privée, sans mesure clinique imposée.
