# Référence de scénario OBJ-09

Source : `Sources/objectives_original.md`, §51.15, lignes 2042–2055. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.15. OBJ-09 — Améliorer sa condition physique

**Matrice** : `Condition physique → Priorité [Endurance / Force / Souplesse / Équilibre / Fonction au quotidien] → Capacité actuelle → Effort → Temps → Sport → Discipline → Séance → Paramètres → Planifier`.

**Départ** : pratique habituelle, limitations, symptômes d'effort, environnement, équipement, aisance à nager/courir/etc., objectifs opérationnels (`marcher sans être essoufflé`, `remonter des escaliers`, `parcourir une distance choisie`). Ne pas imposer un test maximal au début. Des symptômes d'effort suspects conduisent à une évaluation avant exercice intense.

**Briques proposées** : `BR-ACT-01` marche, `BR-ACT-02/05/06` activité aérobie appréciée, `BR-ACT-03` renforcement, `BR-ACT-07/08` mobilité, `BR-ACT-09` équilibre si pertinent, `BR-ACT-11` repos, `BR-SUI-06` mesures consenties. Choisir **une ou deux familles** au départ, puis diversifier en tenant compte de la récupération.

**Parcours illustratif** : effort 1 / condition faible → mouvement confortable **5–10 min** les jours choisis ; effort 2 → durée légèrement plus longue ou activité fractionnée ; effort 3 → répartition dans la semaine avec renforcement adapté ; effort 4–5 → davantage de variété/fréquence **si capacités et temps le permettent**. Les **150–300 min/sem modérées + renforcement ≥2 fois/sem** constituent une orientation de santé publique à atteindre si possible dans la durée, **pas un minimum déclenchant un échec** [S01].

**Exécution** : `Course → Extérieur / Tapis → Temps / Distance / Vitesse ou allure` ; `Natation → Piscine → Longueur de bassin / Nage / Longueurs` ; `Rameur → Ergometer → Durée / Distance / Résistance / Cadence si connue`. Démarrer, pause, terminer, corriger ; source GPS/montre/machine/manual clairement affichée.

**Bilan** : progression d'une capacité utile (durée de marche ressentie comme confortable, régularité, temps réel, distance réellement mesurée, qualité du mouvement), fatigue et plaisir. Pas de VO₂max ou vitesse inventés à partir d'un temps saisi sans mesures valables.
