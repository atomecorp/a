# Index des douze scénarios de santé et bien-être

Le sommeil est le premier pilote. Les onze autres réutilisent ses primitives et les briques métier approuvées. L’option sociale est obligatoire dans la définition de l’entrée mais son activation par la personne est facultative.

| Objectif | Scénario métier | Prompt d’intégration |
| --- | --- | --- |
| OBJ-01 · Perdre du poids | [Référence détaillée](OBJ-01.md) | [P076](../../Prompts/09_Scenarios_sante/P076_OBJ_01_Perdre_du_poids.md) |
| OBJ-02 · Mieux dormir et retrouver de l’énergie | [Référence détaillée](OBJ-02.md) | [P034](../../Prompts/04_Pilote_sommeil/P034_OBJ_02_Mieux_dormir_et_retrouver_de_lenergie.md) |
| OBJ-03 · Prendre de la masse musculaire | [Référence détaillée](OBJ-03.md) | [P074](../../Prompts/09_Scenarios_sante/P074_OBJ_03_Prendre_de_la_masse_musculaire.md) |
| OBJ-04 · Gérer une douleur | [Référence détaillée](OBJ-04.md) | [P077](../../Prompts/09_Scenarios_sante/P077_OBJ_04_Gerer_une_douleur.md) |
| OBJ-05 · Repérer un trouble et être orienté | [Référence détaillée](OBJ-05.md) | [P078](../../Prompts/09_Scenarios_sante/P078_OBJ_05_Reperer_un_trouble_et_etre_oriente.md) |
| OBJ-06 · Préserver du temps pour soi | [Référence détaillée](OBJ-06.md) | [P079](../../Prompts/09_Scenarios_sante/P079_OBJ_06_Preserver_du_temps_pour_soi.md) |
| OBJ-07 · Retrouver le calme intérieur | [Référence détaillée](OBJ-07.md) | [P080](../../Prompts/09_Scenarios_sante/P080_OBJ_07_Retrouver_le_calme_interieur.md) |
| OBJ-08 · Tenir un journal personnel | [Référence détaillée](OBJ-08.md) | [P081](../../Prompts/09_Scenarios_sante/P081_OBJ_08_Tenir_un_journal_personnel.md) |
| OBJ-09 · Améliorer sa condition physique | [Référence détaillée](OBJ-09.md) | [P075](../../Prompts/09_Scenarios_sante/P075_OBJ_09_Ameliorer_sa_condition_physique.md) |
| OBJ-10 · Rajeunissement et vieillissement en bonne santé | [Référence détaillée](OBJ-10.md) | [P082](../../Prompts/09_Scenarios_sante/P082_OBJ_10_Rajeunissement_et_vieillissement_en_bonne_sante.md) |
| OBJ-11 · Améliorer son bien-être | [Référence détaillée](OBJ-11.md) | [P083](../../Prompts/09_Scenarios_sante/P083_OBJ_11_Ameliorer_son_bien_etre.md) |
| OBJ-12 · Prendre soin de sa santé mentale | [Référence détaillée](OBJ-12.md) | [P084](../../Prompts/09_Scenarios_sante/P084_OBJ_12_Prendre_soin_de_sa_sante_mentale.md) |
