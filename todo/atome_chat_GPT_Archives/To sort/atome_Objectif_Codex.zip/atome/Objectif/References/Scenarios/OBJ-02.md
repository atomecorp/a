# Référence de scénario OBJ-02

Source : `Sources/objectives_original.md`, §51.8, lignes 1940–1967. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.8. OBJ-02 — Mieux dormir et retrouver de l'énergie (scénario **refait**)

**But clinique réel :** se sentir plus reposé et fonctionner mieux le jour, en traitant la cause probable lorsqu'une évaluation est nécessaire. **Le sport matinal, la natation, la méditation, la nutrition modifiée et les compléments ne sont pas un paquet universel « sommeil »** ; ils ne figurent que si une donnée ou une préférence le justifie.

**Matrice du scénario** : `Sommeil → Ce qui me gêne → [Endormissement / Réveils / Horaires / Fatigue diurne / Autre] → Effort → Temps → [Rythme / Rituel / Stimulants / Journal / Avis professionnel] → Régler → Accepter → Agenda → Moniteur`.

**Phase 1 : informations utiles (en une ou deux questions à la fois)** : âge ou tranche d'âge ; difficulté principale ; depuis combien de temps ; rythme de travail (horaires réguliers/postés) ; sieste ; quantité et horaire approximatif de caféine si pertinent ; douleur/stress/médicaments ou autres facteurs **si la personne accepte de les indiquer**. Demander explicitement s'il existe **ronflement important avec pauses respiratoires, suffocations nocturnes ou somnolence dangereuse au volant** ; une suspicion conduit à une orientation, **sans diagnostic d'apnée par l'IA**. Troubles persistants, aggravation notable, somnolence sévère ou usages de sédatifs justifient un contact professionnel.

**Phase 2 : observer sans fabriquer un problème** : proposer un **journal très léger sur 7–14 jours**, facultatif, contenant heure de coucher, heure de lever, réveils approximatifs, repos ressenti au matin et gêne dans la journée ; noter les horaires réels plutôt que forcer 7–9 h d'emblée. Montre/Withings/autre : enregistrer leur provenance mais **ne pas interpréter les estimations de sommeil profond/REM comme équivalentes à une polysomnographie**. L'absence de capteur n'empêche rien.

**Phase 3 : proposer les briques réellement pertinentes** :

| Situation relevée | Brique proposée dans la matrice | Activité configurée / limite |
| --- | --- | --- |
| Horaires changeants, réveils difficiles | `BR-SOM-02` régularité | Choisir une **heure de lever praticable** et des jours cibles ; ajuster progressivement si souhaité, tenir compte des équipes de nuit. |
| Très peu de lumière du jour, rythme irrégulier | `BR-SOM-03` exposition à la lumière | Programmer une **sortie ou période à la lumière extérieure** (exemple UX 5–15 min selon situation), sans conseiller l'observation directe du soleil ni affirmer que le bénéfice est garanti. |
| Stimulants tardifs pertinents | `BR-SOM-05` caféine et horaires | Déplacer progressivement la **dernière prise** à une heure choisie ; aucune suppression arbitraire de café ni calcul simpliste de durée d'action. |
| Hyperéveil avant le coucher | `BR-SOM-04` / `BR-MEN-02` | Rituel au calme/relaxation confortable (exemple 5–10 min), si la personne le trouve agréable ; ne pas exiger de méditation. |
| Difficulté installée/retentissement important | `BR-SOM-06` / `BR-SUI-03` | **Orientation vers une TCC-I** ou professionnel compétent ; agenda du rendez-vous, documents préparés, suivi, **sans protocole autonome de restriction de sommeil**. |
| Exercice souhaité ou sédentarité | `BR-ACT-01` ou sport choisi | Activité physique pour la santé générale, **pas comme condition obligatoire pour dormir**, horaire choisi avec la personne. |
| Aucun besoin nutritionnel identifié | **Pas de brique nutrition ni complément par défaut** | Une question ciblée peut être posée si repas tardifs, inconfort digestif ou autre donnée expliquent la pertinence. |

**Phase 4 : validation individuelle** : ne proposer initialement que deux ou trois briques. Exemple réalisable : `Rythme → Heures habituelles → Modifier à mon rythme → Valider` et `Rituel → Activité douce → Durée 10 min → 4 soirs → Valider`. Le curseur « temps » impose le plafond commun. Aucun ajout de mélatonine, antihistaminique, magnésium, complément « sommeil » ou séance à 9 h **sans indication appropriée**. La brique Compléments permet seulement d'**enregistrer une prise existante** et d'organiser un avis médical si besoin.

**Phase 5 : agenda et action** : horaire de lever/rituel selon préférence ; au rappel, ouvrir la brique et guider l'activité acceptée. Le système peut envoyer une notification sans imposer l'ouverture d'iOS en tâche de fond. Le journal demande au maximum un retour simple le lendemain ; `reporté` et `non renseigné` restent distincts.

**Phase 6 : vérifier et corriger** : après 7 nuits comparer surtout **repos ressenti, gêne diurne, régularité et adhésion** ; après 2–4 semaines questionner l'évolution, ajuster une seule variable à la fois si possible, éviter les conclusions causales hâtives. Une aggravation de somnolence, des éveils respiratoires ou une insomnie persistante appellent une évaluation. L'objectif de **7–9 h** est un repère adulte [S03] ; pour l'insomnie chronique la **TCC-I** possède une recommandation forte [S10]. **Ce scénario est la référence clinique actualisée** ; les chiffres et compositions de `Scenario_Sommeil.docx` sont des maquettes historiques, non le protocole par défaut.
