# Référence de scénario OBJ-03

Source : `Sources/objectives_original.md`, §51.9, lignes 1968–1981. Les instructions de méthode du fichier maître restent prioritaires. Les valeurs médicales sont héritées et doivent passer la revue de preuve avant publication.

**Ajout obligatoire pour ce scénario :** l'option facultative « Avec d'autres », au début puis modifiable, suit [la section 52](../52_Reseau_par_objectif.md). Choix Oui / Non / Plus tard ; aucune donnée personnelle partagée implicitement.

**Validation :** toute matrice ou proposition nouvelle suit [la section 53](../53_Validation_progressive.md) ; chaque état visible et le scénario final doivent être acceptés par le porteur du projet.

---

## 51.9. OBJ-03 — Prendre de la masse musculaire

**Matrice** : `Masse musculaire → Expérience / Restrictions → Effort → Temps → [Force / Nutrition / Récupération / Suivi] → Force → Zone musculaire → Mouvement / Machine → Séries / Charge / Répétitions → Séance → Calendrier`.

**Départ** : pratique réelle et ancienneté, blessures, accès au matériel, préférences, horaires et contraintes alimentaires. Si perte de poids involontaire, fatigue inexpliquée, dénutrition, maladie rénale connue ou autre situation médicale, proposer un avis professionnel ; ne pas imposer une consommation protéique élevée.

**Briques essentielles à proposer, sans obligation** : `BR-ACT-03` résistance **progressive** ; `BR-NUT-04/06` apport alimentaire suffisant et protéines si adapté ; `BR-ACT-11/BR-SOM-02` récupération et sommeil ; `BR-SUI-06/09` journal de force et ressenti. **La brique Suppléments n'est pas essentielle** : whey/protéine uniquement pour compléter l'alimentation si utile ; créatine monohydrate comme **option** pour adultes appropriés après vérification des risques, sans effet « anti-âge » promis.

**Plan illustratif débutant sain, personnalisable** : deux séances non consécutives de **20–45 min/semaine chacune** selon le budget, couvrant à terme les grands groupes (poussée, tirage, membres inférieurs, tronc). Pour un mouvement, interface initiale **1–3 séries** et **6–15 répétitions** comme *exemples UX modifiables* ; charge choisie après apprentissage de la technique, jamais imposée en kg ni par 1RM. Le protocole 5×5 cité en section 50 est un **test fonctionnel**, pas une prescription par défaut. Utiliser effort perçu/RPE et récupération uniquement si la personne sait les interpréter. La progression dépend de la qualité des répétitions et de la tolérance, jamais du seul niveau du curseur d'engagement. À capacité différente : programme professionnel adapté ou activité de renforcement moins exigeante.

**Scénario séance** : `Sport → Musculation → Séance complète / Bras / Jambes → Triceps → Machine sélectionnée / Bande / Haltère → Charge (kg ou niveau de résistance) → Séries → Répétitions → Repos → Valider`. À l'heure du calendrier, le véritable outil de séance ouvre le **mouvement actuel** ; chaque série validée par appui passe à la suivante. L'utilisateur corrige une charge ou un nombre de répétitions réel, suspend la séance ou saute le mouvement. Après la dernière série, enregistrer la séance et les observations, pas des performances déduites.

**Suivi** : charges **effectives**, répétitions, nombre de séries achevées, volume facultatif, ressenti/technique, capacités quotidiennes et récupération ; évolution toutes les 4–8 semaines, jamais victoire uniquement sur la balance. Chez les personnes en bonne santé physiquement actives, 1,4–2,0 g/kg/j de protéines est une plage scientifique de référence à **discuter dans le contexte**, pas une dose délivrée automatiquement [S06]. Référentiel force ACSM 2026 [S05].
