# Entrée et réglages communs

> Extraits de la source conservée ; consulter également les sections 52 et 53 pour les ajouts et règles prioritaires. Les descriptions sont des exigences à vérifier, pas une attestation d’outils déjà disponibles.

---

Source : `Sources/objectives_original.md`, §51.1, lignes 1796–1816.

## 51.1. Les douze objectifs officiels et leurs frontières

| Code stable | Objectif choisi dans la matrice | Finalité et frontière |
| --- | --- | --- |
| OBJ-01 | **Perdre du poids** | Démarche nutritionnelle et comportementale adaptée lorsqu'une réduction du poids est indiquée et librement souhaitée ; pas de restriction automatique. |
| OBJ-02 | **Mieux dormir et retrouver de l'énergie** | Qualité du sommeil, rythme et fonctionnement diurne ; orientation vers le soin si suspicion d'insomnie chronique ou d'un trouble du sommeil. |
| OBJ-03 | **Prendre de la masse musculaire** | Progression musculaire et fonctionnelle, entraînement, alimentation et récupération. |
| OBJ-04 | **Gérer une douleur** | Mieux vivre avec une douleur et accéder à une prise en charge adaptée ; aucune affirmation sur la cause. |
| OBJ-05 | **Repérer un trouble et être orienté** | Organiser des symptômes, examens et consultations ; pas de diagnostic autonome ni d'examen systématique sans justification. |
| OBJ-06 | **Préserver du temps pour soi** | Rétablir de l'espace personnel, du repos choisi et des limites de disponibilité. |
| OBJ-07 | **Retrouver le calme intérieur** | Détente, respiration confortable, méditation facultative, régulation du stress ordinaire. |
| OBJ-08 | **Tenir un journal personnel** | Expression et réflexion intime ; non assimilé à un dossier médical obligatoire. |
| OBJ-09 | **Améliorer sa condition physique** | Endurance, force, mobilité et autonomie, selon niveau réel et contraintes. |
| OBJ-10 | **Rajeunissement / vieillir en bonne santé** | Préserver les capacités et, si demandé, l'apparence cutanée ; ne jamais promettre un rajeunissement biologique mesuré ou une inversion de l'âge. |
| OBJ-11 | **Améliorer son bien-être** | Satisfaction de vie, énergie vécue, loisirs, liens, équilibre quotidien ; distinct d'un diagnostic psychiatrique. |
| OBJ-12 | **Prendre soin de sa santé mentale** | Reconnaissance des difficultés, soutien, habitudes aidantes et accès à des professionnels ; pas de diagnostic ni de traitement automatisé. |

Ces objectifs **ne sont pas douze applications** : chacun est un **assemblage de briques transversales** du même moteur d'atome. Par exemple, `BR-ACT-MARCHE` peut contribuer au sommeil, au bien-être, à la condition physique et au vieillissement en bonne santé, avec **une seule occurrence réellement effectuée** et des résultats interprétés séparément pour chaque objectif. Les fonctions Santé mentale et Calme intérieur peuvent proposer certaines activités communes mais elles ne sont pas interchangeables.

**Périmètre initial des repères chiffrés : adultes**, principalement adultes en bonne santé. Les adolescents, femmes enceintes, personnes fragiles, personnes atteintes de maladies chroniques, personnes ayant des troubles du comportement alimentaire ou personnes suivant un traitement peuvent avoir besoin de règles spécifiques et d'une validation clinique. Ni un curseur d'effort élevé ni un désir de résultats rapides ne lève ces conditions.

---

Source : `Sources/objectives_original.md`, §51.2, lignes 1817–1835.

## 51.2. Le parcours unique de l'utilisateur (douze objectifs, même interface)

**Matrice d'entrée :** `Projets → Créer / Reprendre → Objectif → [carrés des 12 objectifs]`. Un objectif déjà commencé s'ouvre sans duplication. Chaque phase ci-dessous reste une matrice de **carrés** ; les carrés ayant une valeur ajustable s'étendent **sur deux ou trois unités de grille** pour montrer leur commande native puis se referment.

1. **Choix de l'intention :** choisir un objectif ou formuler son propre but. Éviter un score ou un plan médical automatique à l'écran d'entrée.
2. **État de départ minimal :** réutiliser uniquement les données déjà présentes **avec permission** ; sinon demander quelques éléments *pertinents pour cette décision* (situation, habitudes, contraintes, accessibilité, activité ou symptômes). La personne peut choisir « je ne sais pas » ou « plus tard ».
3. **Vérification de faisabilité / précautions :** chercher les contre-indications pertinentes, le besoin d'orientation médicale et les contraintes matérielles. Une difficulté sérieuse peut suspendre *une activité spécifique*, pas verrouiller tout le projet.
4. **Deux réglages communs et visibles :** `Effort que je souhaite consacrer` puis `Temps réellement disponible`. Les deux sont des carrés extensibles à curseur ; les règles sont détaillées en 51.3.
5. **Proposition de briques :** présenter une **petite sélection expliquée** (deux à quatre au départ, pas l'ensemble du catalogue) ; pour chacune, afficher l'intérêt plausible, la charge requise, les éventuels prérequis et le niveau de confiance scientifique.
6. **Approfondissement matriciel :** `Domaine → Brique → Activité → Variante / Matériel → Paramètres → Prévisualisation`. Un réglage est édité **dans le carré étendu**, pas dans une fenêtre flottante.
7. **Consentement brique par brique :** `Accepter`, `Modifier`, `Refuser`, `Reporter` ; aucune nutrition, complément, examen, séance, collecte ni partage n'est imposé. L'utilisateur choisit le nombre de briques actives.
8. **Validation du programme :** afficher la somme **réelle des minutes par semaine**, l'horaire possible et les conflits ; proposer une réduction lorsqu'il y a surcharge. Les actions transverses comptent une seule fois.
9. **Projet Dashboard :** synthèse `Aujourd'hui / À venir / Bilan`, issue du **projet atome existant**. La vue calendrier propose les occurrences à autoriser : récurrence, alarmes, rappels, visites, repos ; pas de second agenda.
10. **Exécution :** au déclenchement de l'occurrence, ouvrir l'outil **réel** de l'activité depuis le contexte du calendrier quand la plateforme le permet. Capteur autorisé s'il existe, sinon saisie manuelle. L'outil marque les étapes (série, longueur, repas, note, exercice, etc.).
11. **Résultats :** stocker valeurs prévues et réalisées, date, unité, instrument/source, observations subjectives et documents originaux ; l'absence de mesure vaut « non renseigné ». Le Moniteur rapproche les tendances **sans faire passer une association pour une causalité**.
12. **Bilan et adaptation :** mini-retour après l'activité si la personne le souhaite ; révision après 7 jours, puis 4 semaines, puis à intervalle libre. Conserver toutes les versions, permettre pause, reprise, retrait de brique et objectif terminé/maintenu.

**Règle centrale :** c'est l'utilisateur qui pilote l'effort, l'organisation et les décisions ; le système compose et aide à observer, il ne prescrit pas en silence.

---

Source : `Sources/objectives_original.md`, §51.3, lignes 1836–1871.

## 51.3. Curseurs : effort voulu, temps disponible et progression tolérable

### A. Carré « Effort souhaité » — un seul curseur commun, cinq paliers

Le mot **effort** exprime ici la **charge d'engagement que l'utilisateur accepte** : fréquence, complexité, nécessité de changer des habitudes et temps réellement mobilisé. **Ce n'est pas une autorisation de séance physiquement intense**, ni un score de maladie, ni une estimation automatique de condition cardiorespiratoire.

| Palier affiché | Sens pour l'utilisateur | Construction initiale proposée (configuration, pas prescription) |
| --- | --- | --- |
| **1 · Minimum** | Je veux le plus facile à tenir | **1 brique prioritaire**, micro-action de **2–5 min** aux jours choisis, sans culpabilisation en cas d'absence. |
| **2 · Doux** | Je commence tranquillement | **1–2 briques**, activités de **5–15 min**, progression lente et réversible. |
| **3 · Régulier** | Je peux m'engager de façon stable | **2–3 briques**, une organisation dans la semaine, revue hebdomadaire. |
| **4 · Soutenu** | J'accepte plusieurs changements | **3–4 briques**, créneaux structurés, récupération et charge hebdomadaire surveillées. |
| **5 · Ambitieux** | Je souhaite un projet exigeant | **Jusqu'à 4–5 briques**, mais seulement si elles sont compatibles avec le temps, les capacités et les précautions ; **aucune intensité maximale induite**. |

Les durées de ce tableau sont des **tailles de briques UX** pour amorcer le parcours ; elles ne constituent pas un volume d'entraînement médicalement recommandé. Si la personne a 10 minutes disponibles, le palier 5 n'invente pas une heure de sport. Si une seule brique suffit, aucun objectif n'oblige à en ajouter quatre.

### B. Carré « Temps disponible » — réglage réutilisable et transparent

- Deux vues du **même budget** (pas deux exigences supplémentaires) : `minutes / jour habituel` **ou** `minutes / semaine`. Valeur initiale **à demander**, jamais devinée. `0` signifie « je prépare sans programmer ». Exemple d'amplitude **UI configurable** : 0 à 120 min/j, 0 à 840 min/sem, par pas de 5 min ; au-delà, permettre une saisie explicite, sans limites médicales déguisées en règles d'interface.
- Un carré s'ouvre, s'élargit en **rectangle aligné 2–3 carrés**, montre le curseur natif et une conversion lisible (ex. `20 min/j, 5 jours = 100 min/sem`), puis se referme en mémorisant **100 min/semaine et la distribution choisie**.
- Le nombre de jours réellement libres (`lundi…dimanche`), les fenêtres horaires, contraintes de déplacements, repos et fuseau horaire se choisissent **uniquement si nécessaires à la planification**, dans des carrés de matrice plus profonds ; pas de questionnaire affiché d'emblée.
- Tous les modules communs débitent **un même budget** : le suivi de la séance bras partagé entre OBJ-03 et OBJ-09 n'est compté qu'une fois. Les minutes de trajet, de préparation, de repos **occupant réellement le planning** peuvent être affichées séparément, avec choix utilisateur.
- Afficher `prévu : X min / disponible : Y min` et les conflits **avant validation**, sans glissement silencieux des horaires. `X > Y` entraîne une proposition de simplifier ou reporter, jamais un dépassement imposé.

### C. Capacité actuelle, obstacles, récupération — paramètres séparés et non obligatoires

- **« Qu'est-ce que je peux faire aujourd'hui ? »** : réponse minimale *sans difficulté / limité / besoin d'un avis / je ne sais pas*. Pour le sport, demander le **niveau réellement pratiqué**, les restrictions physiques et le matériel disponible **au moment d'activer Sport**. Une forte motivation **n'augmente jamais les capacités physiologiques présumées**.
- **« Aller doucement / progresser / maintenir »** : préférence **optionnelle** qui module l'**évolution du programme**, pas un troisième curseur imposé. « Récupérer des résultats plus vite » n'autorise pas à supprimer les jours de récupération, à raccourcir une thérapie ou à augmenter une dose.
- **« Ma priorité »**, **« Mes obstacles »** (fatigue, coût, transport, handicap, douleur, horaires, alimentation), **« Je préfère… »** (matin/soir, intérieur/extérieur, autonome/accompagné) : carrés facultatifs révélés en profondeur. Possibilité de personnaliser un module sans dévoiler un dossier de santé entier.
- **Intensité sportive réelle** : uniquement dans les activités sportives, via effort perçu **RPE 0–10** / test de conversation lorsque pertinent, **distinct du curseur d'engagement**. Débutant : pas de test de charge maximale, de « challenge » extrême ni de hausse automatisée.
- **Règle d'adaptation** : journaliser `réalisé / non commencé / reporté`, difficulté ressentie, fatigue, douleur, tolérance ; proposer **maintenir, réduire, déplacer** ou **augmenter graduellement après validation**. Ne pas calculer une « charge médicale sûre » à partir des seuls curseurs.

### D. Exemple de partage du temps

`Mieux dormir · Effort 2 · 90 min/semaine` : l'utilisateur accepte **10 min de lumière matinale extérieure, 5 jours (50 min)** + **10 min de rituel apaisant, 4 soirs (40 min)**. Total proposé **90 min**, sous réserve de son contexte, sans ajout arbitraire de natation, de régime ni de complément. Un temps de journal sommeil facultatif peut remplacer une autre activité ou être explicitement ajouté au budget. En cas de travail posté, de contre-indication d'exposition extérieure, ou de gêne, la proposition change.

---

Source : `Sources/objectives_original.md`, §51.6, lignes 1914–1921.

## 51.6. Règles de personnalisation des douze scénarios

Pour chacun : **Entrée → données minimales → briques suggérées → matrices de configuration → validation → programme daté → action au premier plan → résultat → adaptation**. Les questions dépendent des briques effectivement envisagées ; l'application n'oblige pas à saisir le poids pour méditer ni son humeur pour courir. Le programme propose en priorité des changements **observables, réalisables et réversibles**. Les activités et mesures importantes doivent pouvoir être importées ou saisies manuellement sans capteur ni abonnement à un fabricant.

Les niveaux de recommandation visibles *sur demande* (pas nécessairement en texte sur chaque carré) : **A — pratique soutenue par recommandations solides pour la situation** ; **B — option raisonnable mais bénéfice ou application variable** ; **C — expérimental, efficacité non établie, non proposé comme routine** ; **P — prescrit par un professionnel identifié**. La provenance scientifique et la date de vérification sont conservées. Un classement A sur une activité générale ne prouve jamais qu'elle est indiquée pour cet utilisateur. Une nouvelle étude ou un avis professionnel peut entraîner la révision de la bibliothèque sans effacer les programmes historiques.

**Sorties communes** : chaque scénario détaille son critère principal (*par exemple amélioration de la fonction diurne pour le sommeil plutôt que « HRV parfaite »*), un ou deux indicateurs facultatifs, des conditions d'alerte et un rendez-vous de revue. L'utilisateur peut arrêter son projet sans perdre les données qu'il choisit de conserver.
