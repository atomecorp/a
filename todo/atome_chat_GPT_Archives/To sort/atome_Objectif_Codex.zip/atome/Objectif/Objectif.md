# atome/eVe — Objectif · Prompt maître

**Point d'entrée du dossier.** Ce fichier pilote l'exécution du cahier des charges par petites tâches. Ce dossier contient des instructions et des références, pas une implémentation déjà validée.

## 1. Mission

Construis progressivement le système d'objectifs d'atome/eVe en réutilisant ses vrais outils. Le résultat repose sur **un moteur commun, des briques fonctionnelles réutilisables, des scénarios déclaratifs et une seule grammaire de matrices de carrés**. Ne développe pas douze applications de santé, un logiciel de fitness séparé ou un réseau social conventionnel.

Commence par **P001 : audit du dépôt, des composants, des connexions et des références visuelles**. À la première exécution, ne lance aucune autre tâche et ne modifie pas encore le comportement du produit. Si le dépôt ou une référence essentielle manque, nomme le manque et pose une seule question ciblée.

## 2. Documents à lire, dans cet ordre

1. Ce fichier maître.
2. [Méthode de validation bloquante](References/53_Validation_progressive.md).
3. [Ordre des tâches](Pilotage/Ordre_des_taches.md), [état des tâches](Pilotage/Etat_des_taches.md) et journaux de validations.
4. Le seul prompt actif et les références qu'il cite ; ne recharge pas systématiquement tout le cahier.
5. Si une précision manque : [cahier des charges complet](References/Cahier_des_charges_complet.md), puis [source originale](Sources/objectives_original.md) pour l'historique.

Les sections **52 et 53** décrivent les derniers ajouts. La section **51** prévaut sur les anciens exemples exploratoires pour les objectifs de santé, notamment le sommeil. Les mentions historiques de vérification médicale ne dispensent jamais de la revue de preuve de P002. Les instructions du dépôt et les consignes courantes de l'utilisateur s'appliquent ; une divergence doit être signalée, pas résolue silencieusement.

## 3. Périmètre fonctionnel

Le système comprend douze objectifs de santé/bien-être, le panneau **Activités** indépendant, 77 briques de spécification, un catalogue de sports/mouvements et des machines extensibles. La source universelle est conservée : ressources, personnes, budgets, financement, conditions, preuves, maintien et scénarios hors santé sont traités dans un lot ultérieur identifié.

**Le même objet ne doit pas être copié pour changer de contexte.** Une séance peut servir plusieurs objectifs mais conserve une seule occurrence et une seule réalisation. Les personnes d'une séance collective gardent leurs résultats individuels et leurs droits. Un résultat peut être numérique, textuel ou documentaire ; l'original est conservé, le CSV ne concerne que les données tabulaires pertinentes.

### Matrices et véritables outils

Projets, création, objectifs, Activités, sous-catégories et réglages utilisent la matrice native. Un carré de navigation ouvre une matrice fille. Un carré de valeur s'étend temporairement sur deux ou trois cellules, révèle **son contrôle natif**, enregistre puis se referme. Les outils réels gardent leurs options avec eux. Respecte les captures, SVG, teintes, proportions et gestes vérifiés. Pas de cartes, fenêtres, panneaux flottants ou formulaires autonomes ajoutés par habitude.

Ces règles concernent la navigation, la composition et les réglages ; ne réécris pas les vues spécialisées audio/vidéo sans instruction. Pour le code eVe, conserve JavaScript et l'architecture du dépôt. Aucun TypeScript, framework concurrent, endpoint, composant ou connexion supposés.

### Effort, temps et capacité

Les deux réglages communs restent **Effort souhaité** et **Temps disponible**. L'engagement n'est pas une intensité sportive ni une capacité médicale. La vue jour/semaine décrit le même budget, avec les jours réellement choisis. Les contraintes et la préférence doucement/progresser/maintenir sont facultatives. L'utilisateur valide ou refuse chaque brique ; le refus ne justifie aucune compensation cachée.

### Mise en relation au début de chaque objectif

Intègre l'option **Avec d'autres** au début de tous les objectifs, y compris libres : « Voulez-vous être en contact avec des personnes qui partagent le même objectif que vous ? » Choix **Oui / Non / Plus tard**, sans acceptation par défaut et sans blocage du parcours individuel.

Réutilise Contacts, Communication, invitations, partages et groupes réellement disponibles. Le choix est par objectif ; recherche, visibilité, contact et partage sont des accords distincts. Jamais d'inférence d'un thème public à partir de santé, journal, capteur ou résultat. Ne crée pas de fil social générique. Le réseau doit intégrer retrait, blocage, signalement et règles de protection avant ouverture réelle. Voir [§52](References/52_Reseau_par_objectif.md).

## 4. Procédure obligatoire pour chaque tâche

### A — Audit ciblé et découpage

Vérifie les prérequis réellement acceptés et le code courant. Énonce les seuls outils, connexions, données et écrans concernés. Si le prompt contient plusieurs propositions visibles, donne à chacune un identifiant **Pxxx-V01, Pxxx-V02…**, puis traite-les individuellement. Si une unité reste trop vaste, utilise [le modèle de prompt unitaire](Modeles/Prompt_unitaire.md), propose le sous-découpage et attends l'accord avant de modifier l'ordre de travail.

### B — Démonstration avant intégration

Prépare une démonstration isolée, dans un projet/environnement de test ou un mécanisme d'isolation déjà présent. Le code minimal nécessaire pour afficher les vrais composants peut être écrit dans cet espace ; il ne doit pas remplacer le parcours intégré avant validation. Déclare toute fixture et toute connexion simulée. Un mock n'est pas une preuve d'intégration réelle.

Affiche **la proposition courante** dans l'application de test, au cadrage réel, et indique comment la manipuler. Donne l'identifiant, la révision, la plateforme, la version du code et le chemin de reproduction. La capture/vidéo doit provenir de cette démonstration. Si tu n'as pas accès à l'affichage, fournis le chemin exact pour que l'utilisateur l'ouvre et **arrête-toi au jalon visuel** ; aucune capture inventée.

### C — Validation visuelle humaine, puis arrêt

Écris : **« Proposition Pxxx-Vyy, révision rN, prête à vérifier. J'attends ta validation visuelle avant son intégration. »** Puis arrête l'exécution. Tu ne valides pas à la place du porteur du projet.

Un accord ne porte que sur l'unité présentée et sa révision. Un refus appelle une nouvelle révision du même élément. « Oui » n'approuve que la dernière proposition clairement identifiée ; en cas d'ambiguïté, demande de préciser. Un accord de design ne vaut pas consentement au partage de données, validation clinique, autorisation d'envoi ni déploiement.

### D — Intégration limitée et tests de Codex

Après accord, intègre uniquement l'unité approuvée. Exécute les tests techniques réels adaptés : unitaires, intégration, parcours et régression. Réutilise l'outillage du dépôt. Documente commandes, résultats, logs utiles, environnement et limites. Ne prétends pas avoir exécuté un test indisponible.

Si une correction technique modifie l'apparence ou le comportement perçu, la validation de cette unité redevient nécessaire. Ne profite pas d'une tâche pour corriger des éléments sans rapport. Garde un retour arrière local adapté au dépôt ; pas de déploiement ni d'opération destructive sur les données réelles.

Traite ainsi chaque unité de la tâche. La validation du carré fermé ne valide pas automatiquement le carré étendu, les autres panneaux ni le scénario final.

### E — Test final du porteur du projet

Quand toutes les unités sont approuvées/intégrées et les tests techniques réussis, fournis une version testable et le petit parcours de recette de la tâche. Place-la en **ATTENTE_RECETTE_UTILISATEUR**, puis arrête-toi. Le porteur du projet teste l'ensemble de la tâche. Corrige ses retours en reprenant les jalons concernés.

### F — Clôture et autorisation de poursuite

Une tâche n'est **TERMINEE** qu'avec les preuves techniques et le résultat réel de la recette utilisateur. L'acceptation finale n'autorise pas implicitement toutes les tâches suivantes. Attends une consigne explicite de poursuite, par exemple « Passe à Pxxx ». Une seule tâche d'implémentation est active à la fois.

## 5. Reprise et registre

À chaque nouvelle session, lis l'état, les validations et la version actuelle du code. Ne confonds pas fichier existant et tâche faite. Aucun statut ne peut être inventé ou prérempli comme accepté. Conserve la formulation réelle de l'accord utilisateur et la preuve de la version présentée. Si la version a changé visuellement, rouvre le jalon concerné.

Les états autorisés et les critères de transition sont dans [le protocole](Pilotage/Protocole_etats.md). Les preuves sont rangées dans [Pilotage/Preuves](Pilotage/Preuves/README.md). Les répertoires de preuve ne sont créés qu'au moment des essais ; ce dossier ne contient encore aucune preuve de fonctionnement de l'application.

Le planning par défaut suit les numéros P001…P111. Un changement d'ordre est possible **uniquement sur demande explicite**, après vérification des dépendances. Un blocage se documente ; il n'autorise pas à sauter vers une autre tâche en silence. La partie générique après la réception santé est un lot séparé à ouvrir explicitement.

## 6. Contrôles transversaux non négociables

Codex teste lui-même le fonctionnement. Le porteur du projet valide les visuels et réalise la recette finale. Une revue clinique qualifiée reste indépendante des deux. Avant publication d'un conseil, vérifier preuve, population, source et limites ; ne jamais convertir les valeurs UX en prescription.

Les paramètres sont spécifiques à chaque activité. Une machine est une fiche extensible, pas un projet ni une API. Pictogrammes et variantes manquants restent des livrables à approuver. Les capteurs et leurs permissions sont réels ou déclarés absents. Rappel envoyé, activité démarrée, activité déclarée réalisée, mesure et avis professionnel sont des états différents.

Le journal et les données de santé restent privés par défaut. La mise en relation ne publie jamais le dossier. Les essais sociaux se font avec des comptes et données de test autorisés. Les appels MCP respectent les mêmes droits que les outils eVe. Pas d'envoi, achat, publication, prise de rendez-vous externe ni mise en production implicites.

## 7. Première action autorisée

Ouvre le prompt **P001** référencé dans l'ordre des tâches. Fais seulement l'audit et la présentation de l'existant. Arrête-toi pour validation. **Ne lance pas les 111 prompts en chaîne.**
