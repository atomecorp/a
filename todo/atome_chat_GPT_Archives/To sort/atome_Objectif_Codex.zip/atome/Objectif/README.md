# Dossier Objectif — atome/eVe

**111 prompts Codex, 77 fiches de briques et 12 scénarios de santé/bien-être, avec une mise en relation facultative commune à tous les objectifs.** Le dossier contient également les extensions universelles prévues par le document d'origine.

## Démarrer

Décompresse l'archive : son arborescence est `atome/Objectif/`. Place ce dossier dans l'espace documentaire accessible à Codex. Ce chemin décrit le dossier livré, pas un chemin de code applicatif supposé. Aucune installation dans une bibliothèque distante n'a été effectuée par la création du ZIP.

Ouvre **[Objectif.md](Objectif.md)** : c'est le prompt maître à transmettre à Codex. Il commence uniquement par **[P001 — Audit du dépôt](Prompts/01_Fondations/P001_Audit_du_depot_des_references_et_des_outils_reels.md)**, puis s'arrête. Il lit ensuite le seul prompt autorisé et ses références. **Ne demande pas l'exécution automatique de tous les prompts.**

Message de démarrage possible :

> Lis le fichier maître Objectif.md dans ce dossier. Commence uniquement par P001. Présente les outils et références réels, puis attends ma validation. N'intègre rien et ne lance pas la tâche suivante sans respecter les jalons du dossier.

## La validation prévue

**Une proposition visible → ta validation → intégration limitée → tests de Codex → autres unités de la même tâche selon les mêmes règles → ton test final de la tâche → autorisation explicite de passer à la suivante.**

Chaque panneau, matrice fille, nouvelle variante, pictogramme et étape du scénario possède son accord propre. Un accord global sur le style ne valide pas les écrans futurs. Les tâches sans UI montrent leur livrable et le périmètre d'impact, sans inventer un panneau.

## Organisation

| Lot | Contenu | Prompts | Nombre |
| --- | --- | --- | ---: |
| 01 | Socle commun, matrices, calendrier, résultats et Moniteur | P001–P025 | 25 |
| 02 | Option initiale, découverte, contacts, partage et protection | P026–P030 | 5 |
| 03 | Briques de sommeil refaites | P031–P033 | 3 |
| 04 | Premier scénario complet : Mieux dormir | P034 | 1 |
| 05 | Nutrition, santé, calme, journal, vie personnelle et prévention | P035–P048 | 14 |
| 06 | Sport extensible, machines, séances et récupération | P049–P052 | 4 |
| 07 | Onze groupes de mouvements, fiches et pictogrammes | P053–P063 | 11 |
| 08 | Marche, course, natation, rameur, vélo et autres pratiques initiales | P064–P073 | 10 |
| 09 | Les onze autres objectifs par assemblage | P074–P084 | 11 |
| 10 | Plein air, raquettes, collectifs, danse et arts martiaux | P085–P089 | 5 |
| 11 | Réception santé/sport/social avant ouverture des lots suivants | P090–P093 | 4 |
| 12 | Ressources, personnes, budget et conditions universelles | P094–P097 | 4 |
| 13 | Treize scénarios exemplaires hors cursus initial | P098–P110 | 13 |
| 14 | Réception du moteur universel et passation | P111 | 1 |

Le premier parcours santé complet arrive dès le lot 04, avant de décliner tout le sport. La réception du lot santé/sport/social précède l'ouverture **explicite** des extensions universelles. Les centaines d'idées du catalogue historique sont conservées comme possibilités à détailler ; seuls les scénarios disposant d'une tâche et de preuves peuvent être annoncés réalisés.

## Fichiers importants

- [Objectif.md](Objectif.md) : règles d'orchestration et arrêts obligatoires.
- [Cahier des charges complet](References/Cahier_des_charges_complet.md) : contenu antérieur conservé, typographie normalisée, ajout du réseau par objectif (§52) et des validations (§53).
- [Catalogue des briques](Catalogue/Index_briques.md) : 72 identifiants hérités + 5 briques sociales, chacun relié à son prompt responsable.
- [Ordre et dépendances](Pilotage/Ordre_des_taches.md) : navigation vers les 111 prompts ; [état initial](Pilotage/Etat_des_taches.md), tout à faire.
- [Couverture de la source](Recette/Couverture_source.md) : ce qui est traité et ce qui reste un catalogue d'extension.

## Portée de la livraison

Le ZIP contient une **architecture de travail et des prompts prêts à utiliser**, pas du code atome/eVe déjà intégré. Tous les statuts d'implémentation sont initialisés à A_FAIRE ; les journaux de validation ne contiennent aucun accord fictif. Les tests d'archive vérifient la cohérence documentaire, pas le fonctionnement de l'application.

La source originale de 2 421 lignes / 187 340 octets est conservée octet pour octet. Ses sources scientifiques et valeurs sont héritées : P002 organise leur vérification avant publication de conseils. Les tests logiciels de Codex, la validation visuelle, la recette utilisateur et la revue clinique restent séparés.
