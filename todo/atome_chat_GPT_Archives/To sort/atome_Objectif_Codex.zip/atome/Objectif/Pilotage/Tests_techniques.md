# Tests techniques de Codex

**Aucun test de l'application exécuté par la production de ce dossier.** Les contrôles du ZIP sont documentés séparément.

| Tâche / unité | Version | Environnement réel | Type de test | Commande ou procédure exacte | Résultat | Preuve | Limite / non testé | Date |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

Types à distinguer : test unitaire avec fixture, intégration réelle, parcours eVe, parcours MCP, essai sur simulateur, essai matériel. Un capteur absent, une connexion non accessible ou une erreur de l'outillage ne sont pas une réussite. Ne pas inventer nom de commande, numéro de build ou métrique.
