# Preuves réelles à produire pendant l'exécution

Ce dossier est vide de captures et résultats d'application à la livraison. Aucun fichier témoin ne doit être interprété comme un test effectué.

Lors d'une tâche, créer un sous-dossier `Pxxx/` puis, selon besoins, les captures/vidéos des unités `Vyy-rN`, rapports de tests et notes de reproduction. Référencer les chemins réels dans les journaux. Conserver version du code, plateforme, orientation/thème et contexte. Les données de test doivent être identifiables et non exposer des données personnelles inutiles.

Ne jamais remplacer une capture de l'application par une image générée sans la déclarer comme simple illustration ; une illustration n'est pas une preuve d'intégration.
