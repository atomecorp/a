# Recettes finales effectuées par le porteur du projet

**Aucune recette enregistrée au moment de la livraison.** Codex fournit la version et le parcours, l'utilisateur teste et décide. Ne pas préremplir une réussite.

| Tâche | Version testée | Parcours remis | Tests techniques associés | Retours réels de l'utilisateur | Acceptation / corrections attendues | Décision de poursuite | Date |
| --- | --- | --- | --- | --- | --- | --- | --- |

Une recette finale n'efface pas des unités visuelles non approuvées. Si des changements visibles sont nécessaires, reprendre leur validation. La tâche suivante demande une instruction explicite, même si cette recette est acceptée.
