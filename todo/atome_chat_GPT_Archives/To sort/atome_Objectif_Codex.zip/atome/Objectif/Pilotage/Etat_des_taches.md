# État des tâches

**État au moment de la livraison : aucun développement exécuté dans le dépôt ; aucun écran validé ; aucune recette utilisateur obtenue.** Tous les prompts sont A_FAIRE. La colonne Décision doit renvoyer au journal réel, jamais à une déduction de Codex.

Les fichiers de preuve de l'application n'existent pas encore. Une tâche bloquée ne doit pas être marquée terminée pour pouvoir poursuivre.

| Prompt | Tâche | État | Unité / révision active | Version du code | Preuves et décision humaine |
| --- | --- | --- | --- | --- | --- |
| [P001](../Prompts/01_Fondations/P001_Audit_du_depot_des_references_et_des_outils_reels.md) | Audit du dépôt, des références et des outils réels | A_FAIRE | — | — | — |
| [P002](../Prompts/01_Fondations/P002_Revue_des_valeurs_medicales_et_des_sources_heritees.md) | Revue des valeurs médicales et des sources héritées | A_FAIRE | — | — | — |
| [P003](../Prompts/01_Fondations/P003_Modele_de_projet_objectif_graphe_et_scenario_declaratif.md) | Modèle de projet-objectif, graphe et scénario déclaratif | A_FAIRE | — | — | — |
| [P004](../Prompts/01_Fondations/P004_Registre_des_77_briques_et_disponibilite_reelle.md) | Registre des 77 briques et disponibilité réelle | A_FAIRE | — | — | — |
| [P005](../Prompts/01_Fondations/P005_Consentements_et_isolation_des_donnees.md) | Consentements et isolation des données | A_FAIRE | — | — | — |
| [P006](../Prompts/01_Fondations/P006_Matrice_universelle_et_navigation_en_profondeur.md) | Matrice universelle et navigation en profondeur | A_FAIRE | — | — | — |
| [P007](../Prompts/01_Fondations/P007_Carre_extensible_et_commande_native_integree.md) | Carré extensible et commande native intégrée | A_FAIRE | — | — | — |
| [P008](../Prompts/01_Fondations/P008_Referentiel_de_pictogrammes_et_validation_des_visuels.md) | Référentiel de pictogrammes et validation des visuels | A_FAIRE | — | — | — |
| [P009](../Prompts/01_Fondations/P009_Projets_en_matrice_et_creation_dun_objectif.md) | Projets en matrice et création d’un objectif | A_FAIRE | — | — | — |
| [P010](../Prompts/01_Fondations/P010_Recueil_initial_progressif_et_situation_de_depart.md) | Recueil initial progressif et situation de départ | A_FAIRE | — | — | — |
| [P011](../Prompts/01_Fondations/P011_Curseur_dengagement_Effort_souhaite.md) | Curseur d’engagement Effort souhaité | A_FAIRE | — | — | — |
| [P012](../Prompts/01_Fondations/P012_Budget_Temps_par_jour_ou_par_semaine.md) | Budget Temps par jour ou par semaine | A_FAIRE | — | — | — |
| [P013](../Prompts/01_Fondations/P013_Contraintes_preferences_et_capacite_du_moment.md) | Contraintes, préférences et capacité du moment | A_FAIRE | — | — | — |
| [P014](../Prompts/01_Fondations/P014_Composer_et_valider_un_programme_brique_par_brique.md) | Composer et valider un programme brique par brique | A_FAIRE | — | — | — |
| [P015](../Prompts/01_Fondations/P015_Panneau_Activites_autonome.md) | Panneau Activités autonome | A_FAIRE | — | — | — |
| [P016](../Prompts/01_Fondations/P016_Projet_Dashboard_et_activites_du_jour.md) | Projet Dashboard et activités du jour | A_FAIRE | — | — | — |
| [P017](../Prompts/01_Fondations/P017_Calendrier_commun_recurrences_et_conflits.md) | Calendrier commun, récurrences et conflits | A_FAIRE | — | — | — |
| [P018](../Prompts/01_Fondations/P018_Alarmes_et_ouverture_du_bon_contexte.md) | Alarmes et ouverture du bon contexte | A_FAIRE | — | — | — |
| [P019](../Prompts/01_Fondations/P019_Moteur_commun_de_seance_et_progression_tactile.md) | Moteur commun de séance et progression tactile | A_FAIRE | — | — | — |
| [P020](../Prompts/01_Fondations/P020_Capteurs_disponibles_et_suivi_manuel_equivalent.md) | Capteurs disponibles et suivi manuel équivalent | A_FAIRE | — | — | — |
| [P021](../Prompts/01_Fondations/P021_Documents_originaux_et_reception_de_resultats.md) | Documents originaux et réception de résultats | A_FAIRE | — | — | — |
| [P022](../Prompts/01_Fondations/P022_Observations_typees_historique_et_export_CSV.md) | Observations typées, historique et export CSV | A_FAIRE | — | — | — |
| [P023](../Prompts/01_Fondations/P023_Moniteur_commun_bilan_et_adaptation_consentie.md) | Moniteur commun, bilan et adaptation consentie | A_FAIRE | — | — | — |
| [P024](../Prompts/01_Fondations/P024_Cycle_de_vie_versions_et_reprise_durable.md) | Cycle de vie, versions et reprise durable | A_FAIRE | — | — | — |
| [P025](../Prompts/01_Fondations/P025_Assistant_et_MCP_raccordes_au_meme_moteur.md) | Assistant et MCP raccordés au même moteur | A_FAIRE | — | — | — |
| [P026](../Prompts/02_Mise_en_relation/P026_Option_Avec_dautres_au_debut_de_chaque_objectif.md) | Option Avec d’autres au début de chaque objectif | A_FAIRE | — | — | — |
| [P027](../Prompts/02_Mise_en_relation/P027_Visibilite_et_decouverte_par_objectif_declare.md) | Visibilité et découverte par objectif déclaré | A_FAIRE | — | — | — |
| [P028](../Prompts/02_Mise_en_relation/P028_Contact_reciproque_et_communication_native.md) | Contact réciproque et communication native | A_FAIRE | — | — | — |
| [P029](../Prompts/02_Mise_en_relation/P029_Partage_cible_groupes_et_activites_communes.md) | Partage ciblé, groupes et activités communes | A_FAIRE | — | — | — |
| [P030](../Prompts/02_Mise_en_relation/P030_Retrait_blocage_signalement_et_ouverture_sure_du_reseau.md) | Retrait, blocage, signalement et ouverture sûre du réseau | A_FAIRE | — | — | — |
| [P031](../Prompts/03_Briques_sommeil/P031_Journal_de_sommeil_et_observation_volontaire.md) | Journal de sommeil et observation volontaire | A_FAIRE | — | — | — |
| [P032](../Prompts/03_Briques_sommeil/P032_Rythme_environnement_rituel_et_stimulants.md) | Rythme, environnement, rituel et stimulants | A_FAIRE | — | — | — |
| [P033](../Prompts/03_Briques_sommeil/P033_Orientation_sommeil_et_acces_au_professionnel.md) | Orientation sommeil et accès au professionnel | A_FAIRE | — | — | — |
| [P034](../Prompts/04_Pilote_sommeil/P034_OBJ_02_Mieux_dormir_et_retrouver_de_lenergie.md) | OBJ-02 — Mieux dormir et retrouver de l’énergie | A_FAIRE | — | — | — |
| [P035](../Prompts/05_Briques_transversales/P035_Bilan_alimentaire_et_contraintes_pertinentes.md) | Bilan alimentaire et contraintes pertinentes | A_FAIRE | — | — | — |
| [P036](../Prompts/05_Briques_transversales/P036_Repas_menus_variete_et_portions_facultatives.md) | Repas, menus, variété et portions facultatives | A_FAIRE | — | — | — |
| [P037](../Prompts/05_Briques_transversales/P037_Proteines_fibres_et_apports_energetiques.md) | Protéines, fibres et apports énergétiques | A_FAIRE | — | — | — |
| [P038](../Prompts/05_Briques_transversales/P038_Hydratation_courses_et_preparation.md) | Hydratation, courses et préparation | A_FAIRE | — | — | — |
| [P039](../Prompts/05_Briques_transversales/P039_Complements_et_traitements_declares.md) | Compléments et traitements déclarés | A_FAIRE | — | — | — |
| [P040](../Prompts/05_Briques_transversales/P040_Consultations_examens_et_prevention_planifiee.md) | Consultations, examens et prévention planifiée | A_FAIRE | — | — | — |
| [P041](../Prompts/05_Briques_transversales/P041_Symptomes_douleur_et_orientation.md) | Symptômes, douleur et orientation | A_FAIRE | — | — | — |
| [P042](../Prompts/05_Briques_transversales/P042_Respiration_confortable_et_relaxation.md) | Respiration confortable et relaxation | A_FAIRE | — | — | — |
| [P043](../Prompts/05_Briques_transversales/P043_Meditation_et_attention_variantes_facultatives.md) | Méditation et attention, variantes facultatives | A_FAIRE | — | — | — |
| [P044](../Prompts/05_Briques_transversales/P044_Journal_prive_multimedia_et_analyse_selective.md) | Journal privé multimédia et analyse sélective | A_FAIRE | — | — | — |
| [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) | Temps personnel, loisirs, liens et limites | A_FAIRE | — | — | — |
| [P046](../Prompts/05_Briques_transversales/P046_Humeur_volontaire_et_activites_aidantes.md) | Humeur volontaire et activités aidantes | A_FAIRE | — | — | — |
| [P047](../Prompts/05_Briques_transversales/P047_Soutien_aide_professionnelle_et_plan_de_securite.md) | Soutien, aide professionnelle et plan de sécurité | A_FAIRE | — | — | — |
| [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) | Prévention, fonction, cognition, peau et santé dentaire | A_FAIRE | — | — | — |
| [P049](../Prompts/06_Sport_socle/P049_Taxonomie_sportive_unites_et_activite_manuelle_extensible.md) | Taxonomie sportive, unités et activité manuelle extensible | A_FAIRE | — | — | — |
| [P050](../Prompts/06_Sport_socle/P050_Equipements_et_machines_personnelles_extensibles.md) | Équipements et machines personnelles extensibles | A_FAIRE | — | — | — |
| [P051](../Prompts/06_Sport_socle/P051_Construction_dune_seance_de_musculation_composee.md) | Construction d’une séance de musculation composée | A_FAIRE | — | — | — |
| [P052](../Prompts/06_Sport_socle/P052_Recuperation_et_repos_dans_le_budget_commun.md) | Récupération et repos dans le budget commun | A_FAIRE | — | — | — |
| [P053](../Prompts/07_Mouvements_musculation/P053_Musculation_Biceps_et_avant_bras.md) | Musculation — Biceps et avant-bras | A_FAIRE | — | — | — |
| [P054](../Prompts/07_Mouvements_musculation/P054_Musculation_Triceps.md) | Musculation — Triceps | A_FAIRE | — | — | — |
| [P055](../Prompts/07_Mouvements_musculation/P055_Musculation_Pectoraux.md) | Musculation — Pectoraux | A_FAIRE | — | — | — |
| [P056](../Prompts/07_Mouvements_musculation/P056_Musculation_Dos.md) | Musculation — Dos | A_FAIRE | — | — | — |
| [P057](../Prompts/07_Mouvements_musculation/P057_Musculation_Epaules.md) | Musculation — Épaules | A_FAIRE | — | — | — |
| [P058](../Prompts/07_Mouvements_musculation/P058_Musculation_Quadriceps.md) | Musculation — Quadriceps | A_FAIRE | — | — | — |
| [P059](../Prompts/07_Mouvements_musculation/P059_Musculation_Ischio_jambiers.md) | Musculation — Ischio-jambiers | A_FAIRE | — | — | — |
| [P060](../Prompts/07_Mouvements_musculation/P060_Musculation_Fessiers_et_hanches.md) | Musculation — Fessiers et hanches | A_FAIRE | — | — | — |
| [P061](../Prompts/07_Mouvements_musculation/P061_Musculation_Adducteurs_et_mollets.md) | Musculation — Adducteurs et mollets | A_FAIRE | — | — | — |
| [P062](../Prompts/07_Mouvements_musculation/P062_Musculation_Tronc_et_gainage.md) | Musculation — Tronc et gainage | A_FAIRE | — | — | — |
| [P063](../Prompts/07_Mouvements_musculation/P063_Musculation_Mouvements_composes_et_corps_entier.md) | Musculation — Mouvements composés et corps entier | A_FAIRE | — | — | — |
| [P064](../Prompts/08_Disciplines_sportives/P064_Marche_et_mouvement_du_quotidien.md) | Marche et mouvement du quotidien | A_FAIRE | — | — | — |
| [P065](../Prompts/08_Disciplines_sportives/P065_Course_tapis_piste_et_intervalles.md) | Course, tapis, piste et intervalles | A_FAIRE | — | — | — |
| [P066](../Prompts/08_Disciplines_sportives/P066_Natation_en_bassin_et_eau_libre.md) | Natation en bassin et eau libre | A_FAIRE | — | — | — |
| [P067](../Prompts/08_Disciplines_sportives/P067_Rameur_interieur_et_aviron.md) | Rameur intérieur et aviron | A_FAIRE | — | — | — |
| [P068](../Prompts/08_Disciplines_sportives/P068_Velo_exterieur_et_interieur.md) | Vélo extérieur et intérieur | A_FAIRE | — | — | — |
| [P069](../Prompts/08_Disciplines_sportives/P069_Cardio_interieur_et_appareils.md) | Cardio intérieur et appareils | A_FAIRE | — | — | — |
| [P070](../Prompts/08_Disciplines_sportives/P070_Fitness_et_circuits_composes.md) | Fitness et circuits composés | A_FAIRE | — | — | — |
| [P071](../Prompts/08_Disciplines_sportives/P071_Mobilite_et_etirements_par_zone_et_position.md) | Mobilité et étirements par zone et position | A_FAIRE | — | — | — |
| [P072](../Prompts/08_Disciplines_sportives/P072_Yoga_Pilates_et_gymnastique_douce.md) | Yoga, Pilates et gymnastique douce | A_FAIRE | — | — | — |
| [P073](../Prompts/08_Disciplines_sportives/P073_Equilibre_et_autonomie.md) | Équilibre et autonomie | A_FAIRE | — | — | — |
| [P074](../Prompts/09_Scenarios_sante/P074_OBJ_03_Prendre_de_la_masse_musculaire.md) | OBJ-03 — Prendre de la masse musculaire | A_FAIRE | — | — | — |
| [P075](../Prompts/09_Scenarios_sante/P075_OBJ_09_Ameliorer_sa_condition_physique.md) | OBJ-09 — Améliorer sa condition physique | A_FAIRE | — | — | — |
| [P076](../Prompts/09_Scenarios_sante/P076_OBJ_01_Perdre_du_poids.md) | OBJ-01 — Perdre du poids | A_FAIRE | — | — | — |
| [P077](../Prompts/09_Scenarios_sante/P077_OBJ_04_Gerer_une_douleur.md) | OBJ-04 — Gérer une douleur | A_FAIRE | — | — | — |
| [P078](../Prompts/09_Scenarios_sante/P078_OBJ_05_Reperer_un_trouble_et_etre_oriente.md) | OBJ-05 — Repérer un trouble et être orienté | A_FAIRE | — | — | — |
| [P079](../Prompts/09_Scenarios_sante/P079_OBJ_06_Preserver_du_temps_pour_soi.md) | OBJ-06 — Préserver du temps pour soi | A_FAIRE | — | — | — |
| [P080](../Prompts/09_Scenarios_sante/P080_OBJ_07_Retrouver_le_calme_interieur.md) | OBJ-07 — Retrouver le calme intérieur | A_FAIRE | — | — | — |
| [P081](../Prompts/09_Scenarios_sante/P081_OBJ_08_Tenir_un_journal_personnel.md) | OBJ-08 — Tenir un journal personnel | A_FAIRE | — | — | — |
| [P082](../Prompts/09_Scenarios_sante/P082_OBJ_10_Rajeunissement_et_vieillissement_en_bonne_sante.md) | OBJ-10 — Rajeunissement et vieillissement en bonne santé | A_FAIRE | — | — | — |
| [P083](../Prompts/09_Scenarios_sante/P083_OBJ_11_Ameliorer_son_bien_etre.md) | OBJ-11 — Améliorer son bien-être | A_FAIRE | — | — | — |
| [P084](../Prompts/09_Scenarios_sante/P084_OBJ_12_Prendre_soin_de_sa_sante_mentale.md) | OBJ-12 — Prendre soin de sa santé mentale | A_FAIRE | — | — | — |
| [P085](../Prompts/10_Extensions_sportives/P085_Plein_air_et_activites_par_environnement.md) | Plein air et activités par environnement | A_FAIRE | — | — | — |
| [P086](../Prompts/10_Extensions_sportives/P086_Sports_de_raquette.md) | Sports de raquette | A_FAIRE | — | — | — |
| [P087](../Prompts/10_Extensions_sportives/P087_Sports_collectifs.md) | Sports collectifs | A_FAIRE | — | — | — |
| [P088](../Prompts/10_Extensions_sportives/P088_Danse_et_sequences_de_mouvements.md) | Danse et séquences de mouvements | A_FAIRE | — | — | — |
| [P089](../Prompts/10_Extensions_sportives/P089_Arts_martiaux_et_entrainement_technique.md) | Arts martiaux et entraînement technique | A_FAIRE | — | — | — |
| [P090](../Prompts/11_Recette_sante/P090_Recette_croisee_des_douze_objectifs_et_du_reseau.md) | Recette croisée des douze objectifs et du réseau | A_FAIRE | — | — | — |
| [P091](../Prompts/11_Recette_sante/P091_Recette_visuelle_iPad_petits_ecrans_et_accessibilite.md) | Recette visuelle iPad, petits écrans et accessibilité | A_FAIRE | — | — | — |
| [P092](../Prompts/11_Recette_sante/P092_Resilience_permissions_et_performances.md) | Résilience, permissions et performances | A_FAIRE | — | — | — |
| [P093](../Prompts/11_Recette_sante/P093_Reception_finale_du_lot_sante_et_remise_utilisateur.md) | Réception finale du lot santé et remise utilisateur | A_FAIRE | — | — | — |
| [P094](../Prompts/12_Extensions_transversales/P094_Ressources_et_livrables_lies_aux_etapes.md) | Ressources et livrables liés aux étapes | A_FAIRE | — | — | — |
| [P095](../Prompts/12_Extensions_transversales/P095_Personnes_roles_et_besoins_de_competences.md) | Personnes, rôles et besoins de compétences | A_FAIRE | — | — | — |
| [P096](../Prompts/12_Extensions_transversales/P096_Budget_financement_et_besoins_de_ressources.md) | Budget, financement et besoins de ressources | A_FAIRE | — | — | — |
| [P097](../Prompts/12_Extensions_transversales/P097_Conditions_blocages_et_replanification_du_graphe.md) | Conditions, blocages et replanification du graphe | A_FAIRE | — | — | — |
| [P098](../Prompts/13_Scenarios_generiques/P098_EXT_01_Creer_une_chanson.md) | EXT-01 — Créer une chanson | A_FAIRE | — | — | — |
| [P099](../Prompts/13_Scenarios_generiques/P099_EXT_02_Creer_un_album.md) | EXT-02 — Créer un album | A_FAIRE | — | — | — |
| [P100](../Prompts/13_Scenarios_generiques/P100_EXT_03_Preparer_un_concert.md) | EXT-03 — Préparer un concert | A_FAIRE | — | — | — |
| [P101](../Prompts/13_Scenarios_generiques/P101_EXT_04_Realiser_un_film.md) | EXT-04 — Réaliser un film | A_FAIRE | — | — | — |
| [P102](../Prompts/13_Scenarios_generiques/P102_EXT_05_Finaliser_un_MVP_logiciel.md) | EXT-05 — Finaliser un MVP logiciel | A_FAIRE | — | — | — |
| [P103](../Prompts/13_Scenarios_generiques/P103_EXT_06_Creer_une_entreprise.md) | EXT-06 — Créer une entreprise | A_FAIRE | — | — | — |
| [P104](../Prompts/13_Scenarios_generiques/P104_EXT_07_Lancer_un_produit.md) | EXT-07 — Lancer un produit | A_FAIRE | — | — | — |
| [P105](../Prompts/13_Scenarios_generiques/P105_EXT_08_Organiser_un_evenement.md) | EXT-08 — Organiser un événement | A_FAIRE | — | — | — |
| [P106](../Prompts/13_Scenarios_generiques/P106_EXT_09_Trouver_un_financement.md) | EXT-09 — Trouver un financement | A_FAIRE | — | — | — |
| [P107](../Prompts/13_Scenarios_generiques/P107_EXT_10_Apprendre_une_competence.md) | EXT-10 — Apprendre une compétence | A_FAIRE | — | — | — |
| [P108](../Prompts/13_Scenarios_generiques/P108_EXT_11_Preparer_un_marathon.md) | EXT-11 — Préparer un marathon | A_FAIRE | — | — | — |
| [P109](../Prompts/13_Scenarios_generiques/P109_EXT_12_Organiser_une_grande_randonnee.md) | EXT-12 — Organiser une grande randonnée | A_FAIRE | — | — | — |
| [P110](../Prompts/13_Scenarios_generiques/P110_EXT_13_Objectif_libre_et_extension_du_catalogue.md) | EXT-13 — Objectif libre et extension du catalogue | A_FAIRE | — | — | — |
| [P111](../Prompts/14_Recette_universelle/P111_Reception_universelle_et_passation_du_dossier.md) | Réception universelle et passation du dossier | A_FAIRE | — | — | — |
