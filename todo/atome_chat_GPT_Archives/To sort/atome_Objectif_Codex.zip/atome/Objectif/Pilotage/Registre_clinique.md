# Registre de preuve et publication clinique

**État initial : références et valeurs héritées, non revérifiées pendant le découpage documentaire.** Le prompt P002 doit remplir ce registre. La bibliographie initiale se trouve dans [les références de preuve](../References/09_Preuve_et_securite.md).

| Brique / scénario | Valeur ou conseil concerné | Statut : UX / préférence / mesure / repère / professionnel | Source primaire vérifiée | Population et limites | Date de revue | Revue professionnelle nécessaire / obtenue | Publiable comme conseil ? |
| --- | --- | --- | --- | --- | --- | --- | --- |

Tant qu'une suggestion clinique n'est pas revue, ne pas l'afficher comme adaptée à un utilisateur. Les fonctions de saisie, planning choisi et archivage peuvent être démontrées sans délivrer de recommandation. Une source retirée ou modifiée n'efface pas le contexte historique d'un programme.

Les validations technique, visuelle et de recette utilisateur ne sont pas une validation clinique. Les conseils relatifs aux populations particulières et les règles d'aide urgente requièrent une revue adaptée avant publication.
