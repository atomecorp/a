# Décisions, divergences et blocages

Aucun blocage technique n'a été constaté dans un dépôt lors de la création de cette archive : le code applicatif n'a pas été audité ici. Cette table sert aux travaux ultérieurs.

| Tâche | Manque / divergence constaté | Preuve | Question ou options limitées | Décision réelle | Effet sur périmètre / dépendances | Date |
| --- | --- | --- | --- | --- | --- | --- |

Une référence visuelle manquante n'est pas remplacée par un design générique. Une connexion inconnue n'est pas un endpoint à inventer. Un changement d'ordre, un sous-découpage ou un nouveau composant doit être accepté avant mise à jour du plan.
