# Journal des validations visuelles

**Aucune validation enregistrée au moment de la livraison.** Ajouter une ligne seulement après présentation réelle et réponse de l'utilisateur. Une absence de réponse laisse le jalon en attente.

| Tâche | Unité | Révision | Plateforme / état montré | Version du code | Preuve affichée | Réponse exacte de l'utilisateur | Décision et portée | Date |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

La réponse « Oui » ne vaut accord que si la dernière proposition était clairement identifiée. Un nouvel état, un nouveau pictogramme ou une variante modifiée n'hérite pas d'un accord global. Les références de preuve doivent viser des captures/vidéos réellement produites, pas des chemins vides.
