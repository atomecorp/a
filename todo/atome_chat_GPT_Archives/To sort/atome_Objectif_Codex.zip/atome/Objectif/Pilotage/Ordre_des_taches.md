# Ordre des tâches et dépendances

L’ordre par défaut est numérique, pas celui des noms métier. Une seule tâche active. Après sa recette humaine, la suivante reste verrouillée tant que l’utilisateur n’a pas demandé de poursuivre. Les dépendances ci-dessous sont techniques ; elles ne remplacent pas ce verrou de pilotage.

[Prompt maître](../Objectif.md) · [États](Etat_des_taches.md) · [Protocole](Protocole_etats.md)

## Lot 01 — Socle commun, matrices, calendrier, résultats et Moniteur

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P001](../Prompts/01_Fondations/P001_Audit_du_depot_des_references_et_des_outils_reels.md) | Audit du dépôt, des références et des outils réels | — |
| [P002](../Prompts/01_Fondations/P002_Revue_des_valeurs_medicales_et_des_sources_heritees.md) | Revue des valeurs médicales et des sources héritées | P001 |
| [P003](../Prompts/01_Fondations/P003_Modele_de_projet_objectif_graphe_et_scenario_declaratif.md) | Modèle de projet-objectif, graphe et scénario déclaratif | P001 |
| [P004](../Prompts/01_Fondations/P004_Registre_des_77_briques_et_disponibilite_reelle.md) | Registre des 77 briques et disponibilité réelle | P003 |
| [P005](../Prompts/01_Fondations/P005_Consentements_et_isolation_des_donnees.md) | Consentements et isolation des données | P003 |
| [P006](../Prompts/01_Fondations/P006_Matrice_universelle_et_navigation_en_profondeur.md) | Matrice universelle et navigation en profondeur | P004, P005 |
| [P007](../Prompts/01_Fondations/P007_Carre_extensible_et_commande_native_integree.md) | Carré extensible et commande native intégrée | P006 |
| [P008](../Prompts/01_Fondations/P008_Referentiel_de_pictogrammes_et_validation_des_visuels.md) | Référentiel de pictogrammes et validation des visuels | P006 |
| [P009](../Prompts/01_Fondations/P009_Projets_en_matrice_et_creation_dun_objectif.md) | Projets en matrice et création d’un objectif | P003, P006, P008 |
| [P010](../Prompts/01_Fondations/P010_Recueil_initial_progressif_et_situation_de_depart.md) | Recueil initial progressif et situation de départ | P005, P009 |
| [P011](../Prompts/01_Fondations/P011_Curseur_dengagement_Effort_souhaite.md) | Curseur d’engagement Effort souhaité | P007, P010 |
| [P012](../Prompts/01_Fondations/P012_Budget_Temps_par_jour_ou_par_semaine.md) | Budget Temps par jour ou par semaine | P007, P011 |
| [P013](../Prompts/01_Fondations/P013_Contraintes_preferences_et_capacite_du_moment.md) | Contraintes, préférences et capacité du moment | P010, P012 |
| [P014](../Prompts/01_Fondations/P014_Composer_et_valider_un_programme_brique_par_brique.md) | Composer et valider un programme brique par brique | P004, P013 |
| [P015](../Prompts/01_Fondations/P015_Panneau_Activites_autonome.md) | Panneau Activités autonome | P006, P014 |
| [P016](../Prompts/01_Fondations/P016_Projet_Dashboard_et_activites_du_jour.md) | Projet Dashboard et activités du jour | P014, P015 |
| [P017](../Prompts/01_Fondations/P017_Calendrier_commun_recurrences_et_conflits.md) | Calendrier commun, récurrences et conflits | P016 |
| [P018](../Prompts/01_Fondations/P018_Alarmes_et_ouverture_du_bon_contexte.md) | Alarmes et ouverture du bon contexte | P017 |
| [P019](../Prompts/01_Fondations/P019_Moteur_commun_de_seance_et_progression_tactile.md) | Moteur commun de séance et progression tactile | P018 |
| [P020](../Prompts/01_Fondations/P020_Capteurs_disponibles_et_suivi_manuel_equivalent.md) | Capteurs disponibles et suivi manuel équivalent | P005, P019 |
| [P021](../Prompts/01_Fondations/P021_Documents_originaux_et_reception_de_resultats.md) | Documents originaux et réception de résultats | P005, P017 |
| [P022](../Prompts/01_Fondations/P022_Observations_typees_historique_et_export_CSV.md) | Observations typées, historique et export CSV | P021 |
| [P023](../Prompts/01_Fondations/P023_Moniteur_commun_bilan_et_adaptation_consentie.md) | Moniteur commun, bilan et adaptation consentie | P020, P022 |
| [P024](../Prompts/01_Fondations/P024_Cycle_de_vie_versions_et_reprise_durable.md) | Cycle de vie, versions et reprise durable | P023 |
| [P025](../Prompts/01_Fondations/P025_Assistant_et_MCP_raccordes_au_meme_moteur.md) | Assistant et MCP raccordés au même moteur | P024 |

## Lot 02 — Option initiale, découverte, contacts, partage et protection

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P026](../Prompts/02_Mise_en_relation/P026_Option_Avec_dautres_au_debut_de_chaque_objectif.md) | Option Avec d’autres au début de chaque objectif | P005, P009, P025 |
| [P027](../Prompts/02_Mise_en_relation/P027_Visibilite_et_decouverte_par_objectif_declare.md) | Visibilité et découverte par objectif déclaré | P026 |
| [P028](../Prompts/02_Mise_en_relation/P028_Contact_reciproque_et_communication_native.md) | Contact réciproque et communication native | P027 |
| [P029](../Prompts/02_Mise_en_relation/P029_Partage_cible_groupes_et_activites_communes.md) | Partage ciblé, groupes et activités communes | P028, P017, P022 |
| [P030](../Prompts/02_Mise_en_relation/P030_Retrait_blocage_signalement_et_ouverture_sure_du_reseau.md) | Retrait, blocage, signalement et ouverture sûre du réseau | P029 |

## Lot 03 — Briques de sommeil refaites

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P031](../Prompts/03_Briques_sommeil/P031_Journal_de_sommeil_et_observation_volontaire.md) | Journal de sommeil et observation volontaire | P022, P030 |
| [P032](../Prompts/03_Briques_sommeil/P032_Rythme_environnement_rituel_et_stimulants.md) | Rythme, environnement, rituel et stimulants | P031, P014 |
| [P033](../Prompts/03_Briques_sommeil/P033_Orientation_sommeil_et_acces_au_professionnel.md) | Orientation sommeil et accès au professionnel | P032, P017 |

## Lot 04 — Premier scénario complet : Mieux dormir

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P034](../Prompts/04_Pilote_sommeil/P034_OBJ_02_Mieux_dormir_et_retrouver_de_lenergie.md) | OBJ-02 — Mieux dormir et retrouver de l’énergie | P033, P030, P023 |

## Lot 05 — Nutrition, santé, calme, journal, vie personnelle et prévention

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P035](../Prompts/05_Briques_transversales/P035_Bilan_alimentaire_et_contraintes_pertinentes.md) | Bilan alimentaire et contraintes pertinentes | P034 |
| [P036](../Prompts/05_Briques_transversales/P036_Repas_menus_variete_et_portions_facultatives.md) | Repas, menus, variété et portions facultatives | P035 |
| [P037](../Prompts/05_Briques_transversales/P037_Proteines_fibres_et_apports_energetiques.md) | Protéines, fibres et apports énergétiques | P036, P002 |
| [P038](../Prompts/05_Briques_transversales/P038_Hydratation_courses_et_preparation.md) | Hydratation, courses et préparation | P037, P017 |
| [P039](../Prompts/05_Briques_transversales/P039_Complements_et_traitements_declares.md) | Compléments et traitements déclarés | P038, P022 |
| [P040](../Prompts/05_Briques_transversales/P040_Consultations_examens_et_prevention_planifiee.md) | Consultations, examens et prévention planifiée | P039, P021 |
| [P041](../Prompts/05_Briques_transversales/P041_Symptomes_douleur_et_orientation.md) | Symptômes, douleur et orientation | P040, P002 |
| [P042](../Prompts/05_Briques_transversales/P042_Respiration_confortable_et_relaxation.md) | Respiration confortable et relaxation | P041, P019 |
| [P043](../Prompts/05_Briques_transversales/P043_Meditation_et_attention_variantes_facultatives.md) | Méditation et attention, variantes facultatives | P042 |
| [P044](../Prompts/05_Briques_transversales/P044_Journal_prive_multimedia_et_analyse_selective.md) | Journal privé multimédia et analyse sélective | P043, P022, P005 |
| [P045](../Prompts/05_Briques_transversales/P045_Temps_personnel_loisirs_liens_et_limites.md) | Temps personnel, loisirs, liens et limites | P044, P030 |
| [P046](../Prompts/05_Briques_transversales/P046_Humeur_volontaire_et_activites_aidantes.md) | Humeur volontaire et activités aidantes | P045, P002 |
| [P047](../Prompts/05_Briques_transversales/P047_Soutien_aide_professionnelle_et_plan_de_securite.md) | Soutien, aide professionnelle et plan de sécurité | P046, P030 |
| [P048](../Prompts/05_Briques_transversales/P048_Prevention_fonction_cognition_peau_et_sante_dentaire.md) | Prévention, fonction, cognition, peau et santé dentaire | P047, P002 |

## Lot 06 — Sport extensible, machines, séances et récupération

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P049](../Prompts/06_Sport_socle/P049_Taxonomie_sportive_unites_et_activite_manuelle_extensible.md) | Taxonomie sportive, unités et activité manuelle extensible | P048, P004 |
| [P050](../Prompts/06_Sport_socle/P050_Equipements_et_machines_personnelles_extensibles.md) | Équipements et machines personnelles extensibles | P049 |
| [P051](../Prompts/06_Sport_socle/P051_Construction_dune_seance_de_musculation_composee.md) | Construction d’une séance de musculation composée | P050, P019 |
| [P052](../Prompts/06_Sport_socle/P052_Recuperation_et_repos_dans_le_budget_commun.md) | Récupération et repos dans le budget commun | P051 |

## Lot 07 — Onze groupes de mouvements, fiches et pictogrammes

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P053](../Prompts/07_Mouvements_musculation/P053_Musculation_Biceps_et_avant_bras.md) | Musculation — Biceps et avant-bras | P051, P052, P008 |
| [P054](../Prompts/07_Mouvements_musculation/P054_Musculation_Triceps.md) | Musculation — Triceps | P051, P052, P008 |
| [P055](../Prompts/07_Mouvements_musculation/P055_Musculation_Pectoraux.md) | Musculation — Pectoraux | P051, P052, P008 |
| [P056](../Prompts/07_Mouvements_musculation/P056_Musculation_Dos.md) | Musculation — Dos | P051, P052, P008 |
| [P057](../Prompts/07_Mouvements_musculation/P057_Musculation_Epaules.md) | Musculation — Épaules | P051, P052, P008 |
| [P058](../Prompts/07_Mouvements_musculation/P058_Musculation_Quadriceps.md) | Musculation — Quadriceps | P051, P052, P008 |
| [P059](../Prompts/07_Mouvements_musculation/P059_Musculation_Ischio_jambiers.md) | Musculation — Ischio-jambiers | P051, P052, P008 |
| [P060](../Prompts/07_Mouvements_musculation/P060_Musculation_Fessiers_et_hanches.md) | Musculation — Fessiers et hanches | P051, P052, P008 |
| [P061](../Prompts/07_Mouvements_musculation/P061_Musculation_Adducteurs_et_mollets.md) | Musculation — Adducteurs et mollets | P051, P052, P008 |
| [P062](../Prompts/07_Mouvements_musculation/P062_Musculation_Tronc_et_gainage.md) | Musculation — Tronc et gainage | P051, P052, P008 |
| [P063](../Prompts/07_Mouvements_musculation/P063_Musculation_Mouvements_composes_et_corps_entier.md) | Musculation — Mouvements composés et corps entier | P051, P052, P008 |

## Lot 08 — Marche, course, natation, rameur, vélo et autres pratiques initiales

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P064](../Prompts/08_Disciplines_sportives/P064_Marche_et_mouvement_du_quotidien.md) | Marche et mouvement du quotidien | P052 |
| [P065](../Prompts/08_Disciplines_sportives/P065_Course_tapis_piste_et_intervalles.md) | Course, tapis, piste et intervalles | P064 |
| [P066](../Prompts/08_Disciplines_sportives/P066_Natation_en_bassin_et_eau_libre.md) | Natation en bassin et eau libre | P065 |
| [P067](../Prompts/08_Disciplines_sportives/P067_Rameur_interieur_et_aviron.md) | Rameur intérieur et aviron | P066 |
| [P068](../Prompts/08_Disciplines_sportives/P068_Velo_exterieur_et_interieur.md) | Vélo extérieur et intérieur | P067 |
| [P069](../Prompts/08_Disciplines_sportives/P069_Cardio_interieur_et_appareils.md) | Cardio intérieur et appareils | P068 |
| [P070](../Prompts/08_Disciplines_sportives/P070_Fitness_et_circuits_composes.md) | Fitness et circuits composés | P069 |
| [P071](../Prompts/08_Disciplines_sportives/P071_Mobilite_et_etirements_par_zone_et_position.md) | Mobilité et étirements par zone et position | P070, P041 |
| [P072](../Prompts/08_Disciplines_sportives/P072_Yoga_Pilates_et_gymnastique_douce.md) | Yoga, Pilates et gymnastique douce | P071 |
| [P073](../Prompts/08_Disciplines_sportives/P073_Equilibre_et_autonomie.md) | Équilibre et autonomie | P072 |

## Lot 09 — Les onze autres objectifs par assemblage

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P074](../Prompts/09_Scenarios_sante/P074_OBJ_03_Prendre_de_la_masse_musculaire.md) | OBJ-03 — Prendre de la masse musculaire | P073, P054, P039, P048, P030 |
| [P075](../Prompts/09_Scenarios_sante/P075_OBJ_09_Ameliorer_sa_condition_physique.md) | OBJ-09 — Améliorer sa condition physique | P074, P064, P065, P066, P067, P068, P071, P073 |
| [P076](../Prompts/09_Scenarios_sante/P076_OBJ_01_Perdre_du_poids.md) | OBJ-01 — Perdre du poids | P075, P035, P036, P037, P064 |
| [P077](../Prompts/09_Scenarios_sante/P077_OBJ_04_Gerer_une_douleur.md) | OBJ-04 — Gérer une douleur | P076, P041, P071 |
| [P078](../Prompts/09_Scenarios_sante/P078_OBJ_05_Reperer_un_trouble_et_etre_oriente.md) | OBJ-05 — Repérer un trouble et être orienté | P077, P040, P041, P022 |
| [P079](../Prompts/09_Scenarios_sante/P079_OBJ_06_Preserver_du_temps_pour_soi.md) | OBJ-06 — Préserver du temps pour soi | P078, P045 |
| [P080](../Prompts/09_Scenarios_sante/P080_OBJ_07_Retrouver_le_calme_interieur.md) | OBJ-07 — Retrouver le calme intérieur | P079, P042, P043 |
| [P081](../Prompts/09_Scenarios_sante/P081_OBJ_08_Tenir_un_journal_personnel.md) | OBJ-08 — Tenir un journal personnel | P080, P044 |
| [P082](../Prompts/09_Scenarios_sante/P082_OBJ_10_Rajeunissement_et_vieillissement_en_bonne_sante.md) | OBJ-10 — Rajeunissement et vieillissement en bonne santé | P081, P048, P073 |
| [P083](../Prompts/09_Scenarios_sante/P083_OBJ_11_Ameliorer_son_bien_etre.md) | OBJ-11 — Améliorer son bien-être | P082, P045, P046 |
| [P084](../Prompts/09_Scenarios_sante/P084_OBJ_12_Prendre_soin_de_sa_sante_mentale.md) | OBJ-12 — Prendre soin de sa santé mentale | P083, P046, P047 |

## Lot 10 — Plein air, raquettes, collectifs, danse et arts martiaux

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P085](../Prompts/10_Extensions_sportives/P085_Plein_air_et_activites_par_environnement.md) | Plein air et activités par environnement | P084 |
| [P086](../Prompts/10_Extensions_sportives/P086_Sports_de_raquette.md) | Sports de raquette | P085 |
| [P087](../Prompts/10_Extensions_sportives/P087_Sports_collectifs.md) | Sports collectifs | P086, P029 |
| [P088](../Prompts/10_Extensions_sportives/P088_Danse_et_sequences_de_mouvements.md) | Danse et séquences de mouvements | P087 |
| [P089](../Prompts/10_Extensions_sportives/P089_Arts_martiaux_et_entrainement_technique.md) | Arts martiaux et entraînement technique | P088 |

## Lot 11 — Réception santé/sport/social avant ouverture des lots suivants

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P090](../Prompts/11_Recette_sante/P090_Recette_croisee_des_douze_objectifs_et_du_reseau.md) | Recette croisée des douze objectifs et du réseau | P089, P084 |
| [P091](../Prompts/11_Recette_sante/P091_Recette_visuelle_iPad_petits_ecrans_et_accessibilite.md) | Recette visuelle iPad, petits écrans et accessibilité | P090 |
| [P092](../Prompts/11_Recette_sante/P092_Resilience_permissions_et_performances.md) | Résilience, permissions et performances | P091 |
| [P093](../Prompts/11_Recette_sante/P093_Reception_finale_du_lot_sante_et_remise_utilisateur.md) | Réception finale du lot santé et remise utilisateur | P092 |

## Lot 12 — Ressources, personnes, budget et conditions universelles

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P094](../Prompts/12_Extensions_transversales/P094_Ressources_et_livrables_lies_aux_etapes.md) | Ressources et livrables liés aux étapes | P093 |
| [P095](../Prompts/12_Extensions_transversales/P095_Personnes_roles_et_besoins_de_competences.md) | Personnes, rôles et besoins de compétences | P094, P030 |
| [P096](../Prompts/12_Extensions_transversales/P096_Budget_financement_et_besoins_de_ressources.md) | Budget, financement et besoins de ressources | P095 |
| [P097](../Prompts/12_Extensions_transversales/P097_Conditions_blocages_et_replanification_du_graphe.md) | Conditions, blocages et replanification du graphe | P096 |

## Lot 13 — Treize scénarios exemplaires hors cursus initial

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P098](../Prompts/13_Scenarios_generiques/P098_EXT_01_Creer_une_chanson.md) | EXT-01 — Créer une chanson | P097 |
| [P099](../Prompts/13_Scenarios_generiques/P099_EXT_02_Creer_un_album.md) | EXT-02 — Créer un album | P097, P098 |
| [P100](../Prompts/13_Scenarios_generiques/P100_EXT_03_Preparer_un_concert.md) | EXT-03 — Préparer un concert | P097 |
| [P101](../Prompts/13_Scenarios_generiques/P101_EXT_04_Realiser_un_film.md) | EXT-04 — Réaliser un film | P097 |
| [P102](../Prompts/13_Scenarios_generiques/P102_EXT_05_Finaliser_un_MVP_logiciel.md) | EXT-05 — Finaliser un MVP logiciel | P097 |
| [P103](../Prompts/13_Scenarios_generiques/P103_EXT_06_Creer_une_entreprise.md) | EXT-06 — Créer une entreprise | P097 |
| [P104](../Prompts/13_Scenarios_generiques/P104_EXT_07_Lancer_un_produit.md) | EXT-07 — Lancer un produit | P097 |
| [P105](../Prompts/13_Scenarios_generiques/P105_EXT_08_Organiser_un_evenement.md) | EXT-08 — Organiser un événement | P097 |
| [P106](../Prompts/13_Scenarios_generiques/P106_EXT_09_Trouver_un_financement.md) | EXT-09 — Trouver un financement | P097 |
| [P107](../Prompts/13_Scenarios_generiques/P107_EXT_10_Apprendre_une_competence.md) | EXT-10 — Apprendre une compétence | P097 |
| [P108](../Prompts/13_Scenarios_generiques/P108_EXT_11_Preparer_un_marathon.md) | EXT-11 — Préparer un marathon | P097, P065, P052, P002 |
| [P109](../Prompts/13_Scenarios_generiques/P109_EXT_12_Organiser_une_grande_randonnee.md) | EXT-12 — Organiser une grande randonnée | P097, P085 |
| [P110](../Prompts/13_Scenarios_generiques/P110_EXT_13_Objectif_libre_et_extension_du_catalogue.md) | EXT-13 — Objectif libre et extension du catalogue | P097 |

## Lot 14 — Réception du moteur universel et passation

| Prompt | Tâche | Prérequis techniques |
| --- | --- | --- |
| [P111](../Prompts/14_Recette_universelle/P111_Reception_universelle_et_passation_du_dossier.md) | Réception universelle et passation du dossier | P098, P099, P100, P101, P102, P103, P104, P105, P106, P107, P108, P109, P110 |
