# États et jalons bloquants

Ces états décrivent le **chantier de développement**, pas la santé d'un utilisateur ni l'état d'une activité.

| État | Qui peut le constater ? | Condition de sortie |
| --- | --- | --- |
| A_FAIRE | Registre initial | L'utilisateur a autorisé cette tâche et ses prérequis sont réellement acceptés. |
| AUDIT_CIBLE | Codex | Outils, références, périmètre et manques identifiés. |
| DEMONSTRATION_ISOLEE | Codex | Unité courante affichable avec les vrais composants ; simulations signalées. |
| ATTENTE_VALIDATION_VISUELLE | Codex présente ; utilisateur décide | Accord utilisateur sur unité, révision, plateforme/états montrés et version du code. |
| AUTORISEE_INTEGRATION | Accord humain enregistré | Autorisation limitée à la seule unité approuvée. |
| INTEGRATION | Codex | L'unité approuvée est raccordée ; pas d'élargissement du périmètre. |
| TESTS_CODEX | Codex | Tests réels documentés ; aucune régression visible non approuvée. |
| ATTENTE_RECETTE_UTILISATEUR | Utilisateur | Toutes les unités de la tâche sont acceptées/intégrées et l'utilisateur teste la tâche entière. |
| TERMINEE | Accord final utilisateur + preuves Codex | Toutes les preuves correspondent à la version livrée. La suivante attend encore une consigne de poursuite. |
| BLOQUEE | Codex ou utilisateur | Le manque est résolu et le jalon concerné est repris, sans validation déduite. |

Une tâche peut boucler plusieurs fois sur démonstration/validation/intégration/tests pour ses unités. Chaque unité a son historique indépendant. Refus visuel : nouvelle révision et retour à démonstration. Défaut fonctionnel : correction et nouveaux tests ; nouvelle validation visuelle si la présentation ou le comportement perçu change.

Une tâche documentaire n'invente pas un écran : son document et son périmètre d'impact sont montrés et acceptés. L'accord clinique éventuel ne se substitue pas à la recette produit. Le code générique peut avancer avec des conseils cliniques exclus, mais aucune recommandation non revue ne doit être publiée.

## Format minimal d'une demande

`P007-V02 · r3 · iPad · commit réel … · carré étendu sur 3 cellules · chemin d'accès …`

Ces valeurs sont un **format d'exemple**, pas une validation réelle. Le dossier livré n'enregistre aucune validation. Conserver la réponse effective de l'utilisateur, sa portée et la date de décision. Ne pas attribuer une décision absente à une conversation précédente.

## Autorisations distinctes

Validation de design ≠ consentement de santé ≠ permission de capteur ≠ partage ≠ envoi de message ≠ validation clinique ≠ déploiement. Une instruction de poursuivre le développement ne donne aucun de ces accords par défaut.
