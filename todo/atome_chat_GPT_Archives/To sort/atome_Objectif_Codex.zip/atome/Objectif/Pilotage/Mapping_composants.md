# Mapping entre exigences et code réel

**À remplir par l'audit P001. Aucun symbole, chemin de code ou endpoint n'est présumé existant.** Les chemins du dossier Objectif désignent la documentation, pas les modules d'exécution.

| Capacité à retrouver | Chemin réel / symbole / connexion | Version observée | État constaté | Test existant | Réutilisation ou manque à résoudre |
| --- | --- | --- | --- | --- | --- |
| Matrice et carrés | Non vérifié | — | À auditer | — | — |
| Contrôles natifs / sliders | Non vérifié | — | À auditer | — | — |
| Projets et Dashboard | Non vérifié | — | À auditer | — | — |
| Finder, fichiers, médias et export | Non vérifié | — | À auditer | — | — |
| Calendrier, occurrences et alarmes | Non vérifié | — | À auditer | — | — |
| Outils de séance / étapes | Non vérifié | — | À auditer | — | — |
| Capteurs, connecteurs et permissions | Non vérifié | — | À auditer | — | — |
| Moniteur et observations | Non vérifié | — | À auditer | — | — |
| Contacts, avatars et invitations | Non vérifié | — | À auditer | — | — |
| Communication et groupes | Non vérifié | — | À auditer | — | — |
| Partage, droits et visibilité | Non vérifié | — | À auditer | — | — |
| Annuaire, rapprochement et modération | Non vérifié | — | À auditer | — | — |
| Assistant et MCP | Non vérifié | — | À auditer | — | — |
| Tests / WebDriverAgent / capture | Non vérifié | — | À auditer | — | — |

Pour chaque raccordement, distinguer modèle déjà documenté, code présent, prototype, code connecté et fonction testée. Ne créer une nouvelle capacité que si le manque est réel et son ajout approuvé.
