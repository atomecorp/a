# Parcours de réception transversaux

**À exécuter pendant le développement. Aucun de ces tests n'est déclaré passé dans cette archive.** Chaque prompt contient aussi ses propres tests. Les valeurs chiffrées ci-dessous sont des données d'essai du logiciel, pas des recommandations personnelles.

Pour chaque cas, noter le prompt/version, le chemin, le résultat technique, les limites, les unités montrées et l'accord utilisateur. La validation d'une ligne ne valide pas d'autres écrans. La revue clinique reste indépendante.

| Cas | Domaine | Procédure / invariant | État initial |
| --- | --- | --- | --- |
| RC-01 | Matrice | Projets → Créer → Objectif → brique → réglage → retour ; mêmes vrais carrés et contexte préservé. | À exécuter |
| RC-02 | Extension | Carré fermé → deux/trois unités → contrôle natif → refermer → rouvrir ; valeur et focus conservés. | À exécuter |
| RC-03 | Effort | Tester engagement ambitieux avec faible capacité : aucune intensité ou dose induite. | À exécuter |
| RC-04 | Temps | 20 min/j sur cinq jours = 100 min/sem ; temps nul ; budget dépassé avec refus du dépassement. | À exécuter |
| RC-05 | Composition | Refus Nutrition/Sport/Compléments respecté lors de la construction et de l’adaptation. | À exécuter |
| RC-06 | Multi-objectifs | Une séance commune à Masse et Condition ; un temps, une occurrence, une réalisation. | À exécuter |
| RC-07 | Sommeil | Scénario refait, faible engagement, données inconnues et absence de capteur ; aucune activité aléatoire. | À exécuter |
| RC-08 | Douleur/orientation | Précaution pertinente ou besoin d’aide : orientation validée, sans diagnostic automatisé. | À exécuter |
| RC-09 | Journal | Note multimédia avec outils natifs ; analyse limitée à la sélection autorisée. | À exécuter |
| RC-10 | Social initial | Oui/Non/Plus tard testés dans douze objectifs et un objectif libre ; préférences indépendantes. | À exécuter |
| RC-11 | Découverte | Deux comptes optants visibles selon thème choisi ; soi-même, profils non consentants et bloqués exclus. | À exécuter |
| RC-12 | Contact | Demande reçue/acceptée/refusée ; aucun accès aux résultats par le simple contact. | À exécuter |
| RC-13 | Partage | Une activité partagée avec aperçu exact ; journal, doses, examens et localisation non joints implicitement. | À exécuter |
| RC-14 | Protection | Retrait/blocage appliqués aux accès directs, indices et caches maîtrisés ; objectif privé conservé. | À exécuter |
| RC-15 | Machine | Ajouter appareil triceps et ses réglages propres ; éditer/archiver sans effacer les anciennes séances. | À exécuter |
| RC-16 | Musculation | Test 10 kg, 5×5 ; correction de la troisième série à 8 kg/4 ; prévu/réalisé conservés. | À exécuter |
| RC-17 | Natation | Bassin 25 m, douze longueurs déclarées = 300 m ; pas de longueur de bassin en eau libre. | À exécuter |
| RC-18 | Course/rameur | Distance/durée compatibles, allure min/km ou min/500 m ; pas de watts ou parcours inventés. | À exécuter |
| RC-19 | Positions | Passer à une planche et un étirement : durée/côté, pas de poids×répétitions obligatoire. | À exécuter |
| RC-20 | Compléments | Concentration, quantité/unité et horaire ; rappel ignoré ≠ prise déclarée. | À exécuter |
| RC-21 | Rendez-vous | Planifier/reporter puis recevoir un compte rendu ; date de réception différente de date d’examen. | À exécuter |
| RC-22 | Résultats | Original médical, résultat non sanguin, document qualitatif et observation sportive conservés. | À exécuter |
| RC-23 | CSV | Export limité aux données tabulaires ; caractères spéciaux, unités, dates, nulls et texte sécurisé. | À exécuter |
| RC-24 | Capteurs | Source autorisée/refusée/perdue, alternative manuelle et origine de chaque donnée. | À exécuter |
| RC-25 | Reprise | Interruption/réouverture sans doublon, correction non destructive et maintien de l’historique. | À exécuter |
| RC-26 | Plateformes | iPad prioritaire puis cibles réellement supportées ; aucune simulation présentée comme essai matériel. | À exécuter |
| RC-27 | MCP | Même opération par outil eVe et connexion MCP vérifiée, avec mêmes droits et mêmes données. | À exécuter |
| RC-28 | Rajeunissement | Apparence, fonction et prévention distinctes ; aucun nombre d’années gagné promis. | À exécuter |
| RC-29 | Santé mentale | Refus d’humeur/journal ; aide accessible selon contexte sans détour social imposé. | À exécuter |
| RC-30 | Universel | Album, marathon, film, entreprise, randonnée et libre avec les mêmes primitives. | À exécuter |
