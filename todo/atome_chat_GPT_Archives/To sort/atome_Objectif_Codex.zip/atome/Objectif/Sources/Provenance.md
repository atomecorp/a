# Provenance et conservation

Document de travail utilisé : `objectives_complete.md`, copie complète de `objectives.md` visible dans les échanges précédents. Dernier enregistrement distant cité dans cet historique : `file_00000000d28882108e00b57ffcdbcffa`, associé à `libfile_f50cbac957188191b790f4b00785036e`.

La copie conservée dans ce dossier est [objectives_original.md](objectives_original.md) : **187 340 octets, 2 421 lignes**, SHA-256 **`2927e7b985b746225eaa6c6d407da4be3feaa314cb799ef8d8af9cba3fb8064b`**. Elle est inchangée. Les noms et formulations historiques présents dans cette copie ne sont pas des choix typographiques nouveaux.

[Le cahier consolidé](../References/Cahier_des_charges_complet.md) contient le texte de cette base avec normalisation du nom atome, puis les sections 52 et 53 ajoutées. Les références thématiques et les douze extraits de scénario rendent le contenu exploitable sans charger le fichier complet à chaque tâche.

L'ajout social, le découpage et le protocole de validation proviennent des demandes de la présente conversation. Les références médicales et leurs anciennes dates de vérification sont héritées : cette livraison ne prétend pas les avoir revérifiées. Le prompt P002 organise cette étape avant publication.

**Cette archive est un livrable autonome. Elle n'atteste ni une modification du fichier distant de la bibliothèque, ni une installation du dossier dans le dépôt, ni une implémentation des fonctionnalités.**
