# Provenance et intégrité

Source complète récupérée localement : `objectives_complete.md`, issue du cahier `objectives.md` discuté le 11 octobre 2026.

- Taille exacte : 187,340 octets.
- Nombre de lignes : 2421.
- SHA-256 : `2927e7b985b746225eaa6c6d407da4be3feaa314cb799ef8d8af9cba3fb8064b`.
- Archive immuable dans ce paquet : `objectives_source_2026-10-11.md`.

Ce paquet est construit à partir de cette version récupérée. Aucune lecture fraîche de la bibliothèque ni écriture à `/atome/objectives` n’a pu être effectuée avec les outils disponibles dans cette session. Une version éventuellement modifiée ailleurs après cette source devra être comparée, pas écrasée aveuglément.

Les ajouts de ce paquet proviennent des demandes ultérieures de la conversation : réseau d’objectifs optionnel, Esthétique, carnet de santé transversal et validations successives. Ce paquet ne contient aucun dossier personnel de patient ni donnée clinique réelle. Les chiffres de tests restent explicitement fictifs.

Le document historique est conservé exactement, y compris sa typographie antérieure. Les nouveaux documents utilisent « atome » et « eVe ».
