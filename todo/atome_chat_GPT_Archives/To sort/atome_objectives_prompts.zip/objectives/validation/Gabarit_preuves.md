# Gabarit de preuves — à copier pour une tâche, sans inventer de validation

Tâche :
Sous-jalon / écran :
Statut : NON_COMMENCÉ
Date réelle de réalisation :
Périmètre :
Dépendances effectivement acceptées :
Dépôt / branche / commit de base :
Environnement de prévisualisation :
Appareil / système / résolution :
Références visuelles et fichiers composants vérifiés :
Structure proposée (outils, sélection, emplacement des options) :
Accès à l’écran interactif :
Version / build proposé :
Capture avant :
Capture de proposition :
Tests de prévisualisation (commande, résultat, preuve) :
Données fictives utilisées et provenance :
Incertitudes / blocages :

## Validation visuelle — Jeezs uniquement

Accord exact de Jeezs :
Date :
Version et écran explicitement couverts :
Corrections demandées :

**Laisser vide en l’absence d’accord réel.** Ni un test, ni un avis IA, ni l’accord sur le plan global ne remplissent cette section.

## Intégration après accord seulement

Version intégrée / commit :
Capture intégrée :
Différences par rapport à la proposition approuvée :
Nouvelle validation si différence visible :
Tests intégrés et régressions (commandes, résultats, preuves) :
Sauvegarde / migration / retour arrière si concernés :

## Recette de fin de tâche — Jeezs uniquement

Build testé :
Retours :
Acceptation exacte :
Date :
Corrections restantes :

## Clôture

Livrables réels :
Exigences couvertes :
Tests NON_TESTÉS/BLOQUÉS :
État final :
Prochaine tâche proposée, non démarrée :
Autorisation de démarrage suivante :
