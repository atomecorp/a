# Recette finale : ce que Jeezs teste après Codex

**État initial : aucune recette réalisée.** Codex doit livrer un build utilisable et ses résultats techniques avant cette étape.

## Parcours utilisateur

1. Créer ou reprendre un objectif depuis la matrice, décider de l’option sociale, régler Effort et Temps, accepter/refuser/modifier les briques.
2. Voir un programme conforme au temps choisi, l’accepter puis retrouver les mêmes occurrences dans le Dashboard et le calendrier.
3. Ouvrir une vraie activité, noter une étape, corriger, interrompre/reprendre et retrouver le résultat sauvegardé.
4. Essayer une activité libre depuis Activités, puis la rattacher à un objectif sans duplication.
5. Vérifier le scénario Sommeil sans sport/nutrition/complément forcés ; une séance bras avec machine personnelle et séries ; natation/course/rameur avec unités propres.
6. Ouvrir Esthétique, refuser les photos, créer une routine ou un rendez-vous, puis retrouver le document ou observation autorisés dans le carnet.
7. Consulter le carnet transversal, un résultat non sanguin, l’original, son évolution et l’export d’une sélection.
8. Avec deux comptes de test, accepter/refuser un contact, inviter à une activité, retirer la visibilité et vérifier que carnet, journal et photos ne sont pas exposés.
9. Mettre un programme en pause, changer le futur et constater que les résultats antérieurs sont inchangés.

Ces étapes s’appliquent aussi aux treize scénarios détaillés. Elles complètent, sans remplacer, les tests techniques Codex et les éventuelles revues compétentes de contenu médical.

## Retours

Pour chaque observation : tâche/écran/build, geste effectué, résultat attendu, constat, capture facultative, gravité d’usage. Un défaut visuel retourne à une proposition isolée et une nouvelle validation, pas à un ajustement silencieux du produit actif.

## Décision finale

Acceptation par Jeezs :
Date/build :
Réserves :
Prochaine tâche autorisée :
