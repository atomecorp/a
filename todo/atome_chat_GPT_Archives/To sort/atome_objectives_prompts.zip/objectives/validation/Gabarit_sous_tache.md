# Pxxx-A — Titre précis de la sous-tâche

**Statut : proposition de découpage, non autorisée à l’exécution.**

Parent :
Dépendances :
Passages source et exigence conservée :
Résultat utilisateur attendu :
Composants réellement identifiés :
Manques / questions ciblées :
Périmètre exact :
Hors périmètre :
Structure concrète des outils et options :

## Un écran, un arrêt

Jalon V01 :
Démonstration interactive et capture à présenter :
Tests de prévisualisation :
**STOP pour validation visuelle de Jeezs.**
Intégration seulement après accord sur cette version :
Tests après intégration :
Recette fonctionnelle en fin de tâche parent ou de sous-lot explicitement décidé :

## Décision de découpage

Accord exact de Jeezs :
Date :
Mise à jour du maître/plan/suivi :

Aucun champ d’approbation n’est rempli par l’agent. Une sous-tâche nouvelle ne peut ni élargir une autorisation d’envoi/paiement, ni supprimer une exigence du parent.
