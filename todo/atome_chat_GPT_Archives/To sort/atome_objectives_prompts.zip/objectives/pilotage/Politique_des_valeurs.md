# Politique des valeurs : ne pas confondre test, préférence et soin

| Catégorie | Exemple | Utilisation autorisée |
| --- | --- | --- |
| Interface / préférence | Cinq niveaux Effort ; budget choisi ; pas du curseur. | Configuration UX, modifiable, sans sens physiologique automatique. |
| Donnée de test | Machine 10 kg, cinq séries de cinq répétitions ; bassin 25 m. | Jeu fictif de vérification du moteur, jamais valeur d’entraînement imposée. |
| Donnée déclarée | Poids réellement saisi, produit et quantité que la personne déclare. | Stockage et restitution avec source ; pas d’approbation médicale implicite. |
| Mesure instrumentée | Distance/cadence émises par un capteur autorisé. | Utilisation dans les limites de la source ; précision et valeurs absentes conservées. |
| Repère de population | Volume d’activité ou repère nutritionnel tiré d’une recommandation. | Information sourcée avec population et limites, après revue ; pas prescription personnalisée. |
| Consigne professionnelle | Programme ou ordonnance documentés. | Conservation fidèle de la source, planification sur décision de l’utilisateur ; aucune modification médicale automatique. |
| Hypothèse / expérimental | Test d’âge biologique, produit exploratoire. | Documentation avec incertitudes ; aucune promesse de résultat démontré. |

Chaque paramètre de conseil conserve catégorie, unité, source, date, population et statut de revue. **Effort accepté ≠ capacité physique ≠ intensité d’exercice.** « Plus vite » ne lève aucune précaution. Ne pas introduire un troisième slider obligatoire pour résoudre cette distinction ; les contraintes/préférences restent révélées au besoin.

Une recommandation clinique non validée reste inactive. Les informations déclarées peuvent être enregistrées sans que l’application les approuve. Un champ vide ne devient ni zéro, ni normal, ni absence d’allergie, ni dose par défaut. Les règles de conversion conservent l’original ; par exemple les unités d’activité biologique d’une substance ne se convertissent pas par une formule générique applicable à toutes les substances.

## Jeux de test déterministes (fictifs)

- Temps : 20 min × cinq jours = 100 min/semaine ; zéro permet de préparer sans planifier.
- Musculation : cinq séries prévues à 10 kg × cinq répétitions ; troisième série réelle 8 kg × quatre. Historique prévu/réalisé distinct ; volume externe indicatif sur cet équipement comparable : 232 kg·rép.
- Piscine : 12 longueurs déclarées × 25 m = 300 m ; aucune longueur en eau libre par défaut.
- Course : 5 km en 30 min = 10 km/h et 6 min/km ; si durée ou distance manque, ne pas calculer.
- Rameur : 1 000 m en cinq minutes = 2:30/500 m. Notation corrigée : durée par 500 m, pas « m/500m ».

Aucun de ces jeux ne recommande un entraînement réel à une personne.
