# Sources et revue avant mise en service

## Nouvelles sources consultées le 12 octobre 2026

Ces pages servent à qualifier les nouveaux chantiers, pas à certifier le logiciel. Les règles de conception détaillées sont des exigences du projet ; les rares faits institutionnels ou de santé ci-dessous sont sourcés.

- **[N01] Agence du Numérique en Santé — Référencement Mon espace santé.** Un service tiers doit suivre les démarches de référencement et les conditions d’échange applicables ; le seul nom de carnet ne lui confère pas de statut officiel. <https://esante.gouv.fr/ens/offre/referencement-mon-espace-sante>
- **[N02] CNIL — Recommandations relatives aux applications mobiles**, page indiquant une mise à jour du 8 avril 2025. Référence de protection des données, notamment accès à des données sensibles et distinction entre permissions techniques et finalités. <https://cnil.fr/fr/recommandations-applications-mobiles>
- **[N03] Ministère chargé de la Santé — Injections et autres pratiques perforant la peau**, mise à jour indiquée le 6 janvier 2025. Référence sur les risques et l’encadrement des pratiques à visée esthétique. <https://sante.gouv.fr/soins-et-maladies/qualite-securite-et-pertinence-des-soins/securite-des-prises-en-charge/reglementation-de-securite-sanitaire-dans-les-etablissements-de-sante/securite-des-pratiques-esthetiques/article/injections-et-autres-pratiques-perforant-la-peau>
- **[N04] Assurance Maladie — Dangers du soleil : comment s’en protéger ?** Information de référence sur exposition et protection solaire ; le scénario ne transforme pas ces repères en prescription esthétique individuelle. <https://www.ameli.fr/assure/sante/themes/coup-soleil/prevention>
- **[N05] Mon espace santé — À propos.** Le service public comprend un dossier médical, des documents, un profil de santé et une messagerie ; ce n’est pas un statut automatiquement partagé par une application tierce. <https://www.monespacesante.fr/a-propos>

## Sources héritées du cahier

Les [S01] à [S17] sont reproduites dans `../specifications/sections/51_28.md` et l’archive. Leur mention de vérification du 11 octobre appartient au document historique. **Le présent découpage ne prétend pas avoir revalidé la totalité de ces sources ou tous les conseils associés.** Avant activation : consulter les références primaires actuelles, confirmer populations et limites, faire revoir les règles par les professionnels compétents.

## Registre à remplir pendant le développement

Pour chaque conseil : identifiant, version, phrase/valeur exacte, catégorie, source primaire, date de consultation, population cible, exclusions, auteur/relecteur qualifié, date et portée de validation, statut, date de revue suivante. Une donnée de test n’a pas besoin de devenir une recommandation ; elle reste confinée aux tests.

**État initial : aucune validation clinique, juridique ou institutionnelle obtenue par ce paquet.** Les fonctionnalités déclaratives peuvent être testées avec données fictives pendant l’attente. Les allégations officielles et les recommandations non revues restent désactivées.
