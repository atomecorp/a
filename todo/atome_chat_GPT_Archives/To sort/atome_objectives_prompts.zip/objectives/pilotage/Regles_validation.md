# Contrat de validation — applicable à chaque prompt

## Responsabilités

**Codex** inspecte le dépôt, réalise l’implémentation isolée, exécute les tests techniques et les régressions, fournit les preuves et corrige. **Jeezs** valide visuellement chaque proposition avant intégration, puis teste fonctionnellement la tâche terminée. Les professionnels compétents valident les contenus cliniques ou obligations juridiques lorsque nécessaires ; aucune de ces validations ne remplace les autres.

## Avant tout code ou maquette

Lire les règles du dépôt et identifier les références visuelles, outils, composants et connexions réellement accessibles. Annoncer l’assemblage : quels outils s’affichent, comment ils sont sélectionnés, où leurs options apparaissent et ce qui reste inconnu. Si un élément essentiel manque, poser une question ciblée et s’arrêter. Ne pas transformer l’absence d’une référence en liberté de reprendre un modèle desktop/gestion/réseau social standard.

## Proposition ≠ intégration

La proposition peut nécessiter du code, mais ce code reste dans un environnement de prévisualisation isolé (branche, variante ou mécanisme réversible **déjà adapté à l’architecture réelle**). Ne pas inventer des dépendances ou imposer un framework pour prévisualiser. Ne pas mettre cette proposition dans le produit actif, migrer des données réelles, lancer une campagne d’alarmes ou publier avant accord.

Chaque écran est démontré interactif, avec les vraies commandes. Une capture identifiée sert de preuve ; elle ne remplace pas l’écran utilisable. Si l’environnement n’est pas accessible, demander l’accès nécessaire ou classer BLOQUÉ. Ne pas dire « validé » pour une image générée ou une UI simulée.

## Arrêts stricts

Pour chaque écran/état nouvellement proposé : test technique de prévisualisation → présentation → **STOP_VISUEL** → accord explicite sur cet écran/version → intégration de cette version seulement → tests techniques intégrés → vérification du résultat visible. Ne pas commencer l’écran suivant pendant l’attente. Toute modification visible après accord réouvre la validation.

Un jalon peut mentionner plusieurs écrans par commodité de description : **le subdiviser en V01a, V01b, etc. avant exécution**. Par exemple Carnet/Allergies, Carnet/Vaccinations et Carnet/Traitements sont trois validations, pas une capture de groupe. La même règle s’applique aux variantes, erreurs, états vides ou permissions si leur présentation est nouvelle.

Ne pas recréer un contrôle visuel déjà validé pour une tâche purement technique. Montrer ses effets avec l’outil réel existant ; ne pas ajouter un panneau administratif pour justifier la validation.

## Fin de tâche

Tous les écrans de la tâche ont un accord réel ; leur version approuvée a été intégrée ; les tests passent ou des blocages sont explicitement documentés. Jeezs teste alors la tâche terminée. S’il signale un changement visible, le corriger dans une proposition isolée avec nouvelle validation. Une tâche bloquée n’est pas une tâche terminée.

Après la recette acceptée : mettre à jour le suivi, proposer la prochaine tâche admissible, **attendre l’autorisation de la démarrer**. Une dépendance satisfaite n’autorise pas l’avancement automatique.

## Preuves minimales

ID de tâche/jalon ; commit ou identifiant de version et build ; environnement/appareil ; références avant ; capture et accès à la proposition ; tests effectués, commandes, résultats et écarts ; texte exact de l’accord humain et sa date ; version intégrée ; capture intégrée ; tests intégrés ; recette finale de Jeezs ; éventuel retrait/rollback.

Les fichiers de suivi livrés ici sont **non commencés** et les champs d’approbation sont vides. Un agent ne signe jamais à la place de Jeezs ou d’un professionnel.

## Formulations de contrôle à employer

Présentation : « Pxxx / Vyy — proposition affichée dans [environnement], version [identifiant]. Tests de prévisualisation : [résultat réel]. Je m’arrête ici pour ta validation visuelle. »

Reprise : vérifier que l’accord concerne cette version et ce jalon ; intégrer uniquement son périmètre. À fin de tâche : « Pxxx — intégration et tests techniques terminés [preuves]. La tâche est prête pour ta recette fonctionnelle. »

Ne pas transformer ces exemples en assertions préremplies dans un rapport.
