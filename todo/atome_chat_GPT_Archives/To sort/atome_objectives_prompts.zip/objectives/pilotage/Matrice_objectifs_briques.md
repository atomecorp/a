# Correspondance des treize objectifs et briques

Toutes les entrées ci-dessous sont des **candidates selon le besoin**, pas des prescriptions ou obligations. Le catalogue clinique détaillé est dans les fiches sources. Tous les objectifs utilisent le même socle Effort/Temps/consentement/composition, proposent **BR-SOC-01** au début et permettent l’accès au même carnet **BR-CAR-01**, selon permissions.

| Objectif | Briques candidates (préfixe BR- omis) | Scénario / prompt |
| --- | --- | --- |
| OBJ-01 — Perdre du poids | NUT-01, NUT-02, NUT-03, NUT-05, ACT-01, ACT-03, SOM-02, SUI-03 | [Scénario](../specifications/scenarios/OBJ-01.md) · [P055](../prompts/07_scenarios/P055_obj-01_perdre_poids.md) |
| OBJ-02 — Mieux dormir et retrouver de l’énergie | SOM-01, SOM-02, SOM-03, SOM-04, SOM-05, SOM-06, MEN-02 | [Scénario](../specifications/scenarios/OBJ-02.md) · [P056](../prompts/07_scenarios/P056_obj-02_mieux_dormir.md) |
| OBJ-03 — Prendre de la masse musculaire | ACT-03, NUT-04, NUT-06, ACT-11, SUI-08, SOM-02 | [Scénario](../specifications/scenarios/OBJ-03.md) · [P057](../prompts/07_scenarios/P057_obj-03_masse_musculaire.md) |
| OBJ-04 — Gérer une douleur | SUI-02, SUI-03, SUI-10, ACT-07, MEN-02, SOM-01 | [Scénario](../specifications/scenarios/OBJ-04.md) · [P058](../prompts/07_scenarios/P058_obj-04_gerer_douleur.md) |
| OBJ-05 — Repérer un trouble et être orienté | SUI-01, SUI-03, SUI-04, SUI-05, SUI-10 | [Scénario](../specifications/scenarios/OBJ-05.md) · [P059](../prompts/07_scenarios/P059_obj-05_reperer_trouble.md) |
| OBJ-06 — Préserver du temps pour soi | VIE-01, VIE-05, VIE-02, VIE-04, MEN-04 | [Scénario](../specifications/scenarios/OBJ-06.md) · [P060](../prompts/07_scenarios/P060_obj-06_temps_pour_soi.md) |
| OBJ-07 — Retrouver le calme intérieur | MEN-01, MEN-02, MEN-03, MEN-04, VIE-02, ACT-01 | [Scénario](../specifications/scenarios/OBJ-07.md) · [P061](../prompts/07_scenarios/P061_obj-07_calme_interieur.md) |
| OBJ-08 — Tenir un journal personnel | VIE-03, SYS-07, SYS-08, MEN-05, VIE-02 | [Scénario](../specifications/scenarios/OBJ-08.md) · [P062](../prompts/07_scenarios/P062_obj-08_journal_personnel.md) |
| OBJ-09 — Améliorer sa condition physique | ACT-01, ACT-02, ACT-03, ACT-04, ACT-05, ACT-06, ACT-07, ACT-09, ACT-11 | [Scénario](../specifications/scenarios/OBJ-09.md) · [P063](../prompts/07_scenarios/P063_obj-09_condition_physique.md) |
| OBJ-10 — Rajeunissement / vieillir en bonne santé | AGE-01, AGE-02, AGE-03, AGE-04, AGE-05, AGE-06, ACT-03, ACT-09, NUT-03, SOM-02 | [Scénario](../specifications/scenarios/OBJ-10.md) · [P064](../prompts/07_scenarios/P064_obj-10_vieillir_sante.md) |
| OBJ-11 — Améliorer son bien-être | VIE-01, VIE-02, VIE-04, ACT-01, MEN-04, SOM-02 | [Scénario](../specifications/scenarios/OBJ-11.md) · [P065](../prompts/07_scenarios/P065_obj-11_bien_etre.md) |
| OBJ-12 — Prendre soin de sa santé mentale | MEN-07, MEN-06, MEN-08, VIE-04, SOM-01, ACT-01, MEN-02, MEN-05 | [Scénario](../specifications/scenarios/OBJ-12.md) · [P066](../prompts/07_scenarios/P066_obj-12_sante_mentale.md) |
| OBJ-13 — Esthétique — visage, corps et peau | EST-01, EST-02, EST-03, EST-04, EST-05, EST-06, AGE-03, SUI-03, SUI-05 | [Scénario](../specifications/scenarios/OBJ-13.md) · [P067](../prompts/07_scenarios/P067_obj-13_esthetique.md) |

Une activité peut contribuer à plusieurs objectifs ; elle n’a qu’une occurrence réelle. Les relations entre résultats et objectifs sont explicites et révocables. Le Moniteur n’interprète pas un résultat au-delà des données et autorisations disponibles. La suppression d’un objectif n’efface pas le carnet.
