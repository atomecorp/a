# Inventaire réel à remplir dans P001

Ce fichier ne certifie aucun composant disponible. Il doit être rempli à partir du dépôt et de démonstrations réelles.

| Capacité | Fichier/symbole réel | Comportement observé | Preuve/test | Réutilisation/adaptation/manque | Référence visuelle approuvée |
| --- | --- | --- | --- | --- | --- |
| Matrice/carrés/navigation | À vérifier | — | — | À auditer | — |
| Curseur/édition dans la cellule | À vérifier | — | — | À auditer | — |
| Projets/Dashboard | À vérifier | — | — | À auditer | — |
| Finder/import/fichiers | À vérifier | — | — | À auditer | — |
| Calendrier/rappels/occurrences | À vérifier | — | — | À auditer | — |
| Outil d’exécution/étapes | À vérifier | — | — | À auditer | — |
| Capteurs et permissions par plateforme | À vérifier | — | — | À auditer | — |
| Résultats/stockage/export/historique | À vérifier | — | — | À auditer | — |
| Moniteur | À vérifier | — | — | À auditer | — |
| Contacts/communication/groupes | À vérifier | — | — | À auditer | — |
| Découverte/blocage/signalement | À vérifier | — | — | À auditer | — |
| Permissions par donnée/carnet | À vérifier | — | — | À auditer | — |
| Bibliothèque de pictogrammes | À vérifier | — | — | À auditer | — |
| MCP et automatisation de tests | À vérifier | — | — | À auditer | — |

## Questions bloquantes ciblées

Dépôt/branche source :
Référence d’écran et dimensions de cellule :
Prévisualisation isolée accessible :
Appareils disponibles et iPad de référence :
Comptes de test et canaux sécurisés pour les secrets :
Publics concernés/territoires du carnet :
Capacité de stockage/synchronisation réellement présente :
Statut des revues cliniques et des raccordements officiels :

Ne pas remplir ces champs par inférence à partir d’un nom de projet, d’un ancien souvenir d’architecture ou d’un mockup généré.
