# Correspondance exhaustive : document source → tâches

L’archive d’origine est conservée byte pour byte. Les extraits ci-dessous partitionnent ses 2 421 lignes sans trou ni chevauchement. La colonne « prompts » indique les tâches qui doivent lire le passage ; un catalogue étendu demeure un catalogue à décliner et non une attestation d’implémentation de tous ses objectifs.

Les décisions 52–55 ajoutent Esthétique, réseau optionnel, carnet transversal et validations successives. Les références médicales héritées restent soumises à revue.

| Section | Lignes de la source | Prompts responsables/lecteurs | Extrait |
| --- | --- | --- | --- |
| titre | 1–2 | P001 | [Lire](../specifications/sections/titre.md) |
| 0 | 3–18 | P001, P075 | [Lire](../specifications/sections/0.md) |
| 1 | 19–90 | P002 | [Lire](../specifications/sections/1.md) |
| 2 | 91–130 | P002, P068 | [Lire](../specifications/sections/2.md) |
| 3 | 131–211 | P002 | [Lire](../specifications/sections/3.md) |
| 4 | 212–325 | P002, P008, P068 | [Lire](../specifications/sections/4.md) |
| 5 | 326–366 | P002, P010, P068 | [Lire](../specifications/sections/5.md) |
| 6 | 367–374 | P005, P074 | [Lire](../specifications/sections/6.md) |
| 7 | 375–421 | P069, P074 | [Lire](../specifications/sections/7.md) |
| 8 | 422–456 | P070, P074 | [Lire](../specifications/sections/8.md) |
| 9 | 457–481 | P074 | [Lire](../specifications/sections/9.md) |
| 10 | 482–506 | P074 | [Lire](../specifications/sections/10.md) |
| 11 | 507–536 | P074 | [Lire](../specifications/sections/11.md) |
| 12 | 537–576 | P071, P074 | [Lire](../specifications/sections/12.md) |
| 13 | 577–603 | P071, P074 | [Lire](../specifications/sections/13.md) |
| 14 | 604–633 | P074 | [Lire](../specifications/sections/14.md) |
| 15 | 634–664 | P074 | [Lire](../specifications/sections/15.md) |
| 16 | 665–689 | P040, P073, P074 | [Lire](../specifications/sections/16.md) |
| 17 | 690–714 | P051, P072, P074 | [Lire](../specifications/sections/17.md) |
| 18 | 715–739 | P074 | [Lire](../specifications/sections/18.md) |
| 19 | 740–764 | P074 | [Lire](../specifications/sections/19.md) |
| 20 | 765–783 | P074 | [Lire](../specifications/sections/20.md) |
| 21 | 784–808 | P074 | [Lire](../specifications/sections/21.md) |
| 22 | 809–833 | P074 | [Lire](../specifications/sections/22.md) |
| 23 | 834–858 | P074 | [Lire](../specifications/sections/23.md) |
| 24 | 859–878 | P074 | [Lire](../specifications/sections/24.md) |
| 25 | 879–901 | P005, P068, P074 | [Lire](../specifications/sections/25.md) |
| 26 | 902–939 | P002, P010, P068 | [Lire](../specifications/sections/26.md) |
| 27 | 940–978 | P022, P023, P024, P071 | [Lire](../specifications/sections/27.md) |
| 28 | 979–1017 | P071 | [Lire](../specifications/sections/28.md) |
| 29 | 1018–1043 | P017 | [Lire](../specifications/sections/29.md) |
| 30 | 1044–1064 | P007, P011, P013, P024 | [Lire](../specifications/sections/30.md) |
| 31 | 1065–1083 | P014 | [Lire](../specifications/sections/31.md) |
| 32 | 1084–1106 | P008 | [Lire](../specifications/sections/32.md) |
| 33 | 1107–1144 | P005, P011 | [Lire](../specifications/sections/33.md) |
| 34 | 1145–1175 | P012 | [Lire](../specifications/sections/34.md) |
| 35 | 1176–1200 | P020, P021 | [Lire](../specifications/sections/35.md) |
| 36 | 1201–1225 | P002, P010, P068, P069 | [Lire](../specifications/sections/36.md) |
| 37 | 1226–1244 | P011, P020, P021 | [Lire](../specifications/sections/37.md) |
| 38 | 1245–1265 | P002, P017, P021, P076 | [Lire](../specifications/sections/38.md) |
| 39 | 1266–1286 | P002, P021, P068 | [Lire](../specifications/sections/39.md) |
| 40 | 1287–1311 | P021, P068 | [Lire](../specifications/sections/40.md) |
| 41 | 1312–1328 | P013, P014 | [Lire](../specifications/sections/41.md) |
| 42 | 1329–1357 | P001, P068, P080 | [Lire](../specifications/sections/42.md) |
| 43 | 1358–1386 | P069, P070, P071, P072, P073, P074 | [Lire](../specifications/sections/43.md) |
| 44 | 1387–1413 | P079 | [Lire](../specifications/sections/44.md) |
| 45 | 1414–1482 | P069, P070, P071, P072, P073, P075, P076, P079 | [Lire](../specifications/sections/45.md) |
| 46 | 1483–1494 | P001 | [Lire](../specifications/sections/46.md) |
| 47 | 1495–1510 | P080 | [Lire](../specifications/sections/47.md) |
| 48 | 1511–1534 | P076, P079, P080 | [Lire](../specifications/sections/48.md) |
| 49 | 1535–1562 | P001, P080 | [Lire](../specifications/sections/49.md) |
| 50 | 1563–1566 | P001 | [Lire](../specifications/sections/50.md) |
| 50.1 | 1567–1574 | P001, P003 | [Lire](../specifications/sections/50_1.md) |
| 50.2 | 1575–1596 | P004 | [Lire](../specifications/sections/50_2.md) |
| 50.3 | 1597–1603 | P003, P005 | [Lire](../specifications/sections/50_3.md) |
| 50.4 | 1604–1632 | P010, P012, P013, P014 | [Lire](../specifications/sections/50_4.md) |
| 50.5 | 1633–1641 | P009 | [Lire](../specifications/sections/50_5.md) |
| 50.6 | 1642–1649 | P001, P009, P020 | [Lire](../specifications/sections/50_6.md) |
| 50.7 | 1650–1674 | P075 | [Lire](../specifications/sections/50_7.md) |
| 50.8 | 1675–1694 | P033 | [Lire](../specifications/sections/50_8.md) |
| 50.9 | 1695–1731 | P014, P015, P016, P040, P043, P044, P045 | [Lire](../specifications/sections/50_9.md) |
| 50.10 | 1732–1757 | P017, P018, P019, P028 | [Lire](../specifications/sections/50_10.md) |
| 50.11 | 1758–1767 | P013, P028, P033 | [Lire](../specifications/sections/50_11.md) |
| 50.12 | 1768–1791 | P077 | [Lire](../specifications/sections/50_12.md) |
| 51 | 1792–1795 | P001 | [Lire](../specifications/sections/51.md) |
| 51.1 | 1796–1816 | P005 | [Lire](../specifications/sections/51_1.md) |
| 51.2 | 1817–1835 | P003, P008, P010, P011, P012, P020, P022, P055, P056, P057, P058, P059, P060, P061, P062, P063, P064, P065, P066, P067 | [Lire](../specifications/sections/51_2.md) |
| 51.3 | 1836–1871 | P004, P006, P007, P011, P021, P053, P055, P056, P057, P058, P059, P060, P061, P062, P063, P064, P065, P066, P067 | [Lire](../specifications/sections/51_3.md) |
| 51.4 | 1872–1891 | P009, P016, P031, P034, P038 | [Lire](../specifications/sections/51_4.md) |
| 51.5 | 1892–1913 | P032, P034, P078 | [Lire](../specifications/sections/51_5.md) |
| 51.6 | 1914–1921 | P008, P055, P056, P057, P058, P059, P060, P061, P062, P063, P064, P065, P066, P067 | [Lire](../specifications/sections/51_6.md) |
| 51.7 | 1922–1939 | P032, P055 | [Lire](../specifications/sections/51_7.md) |
| 51.8 | 1940–1967 | P034, P056 | [Lire](../specifications/sections/51_8.md) |
| 51.9 | 1968–1981 | P032, P057 | [Lire](../specifications/sections/51_9.md) |
| 51.10 | 1982–1993 | P037, P058 | [Lire](../specifications/sections/51_10.md) |
| 51.11 | 1994–2005 | P037, P059 | [Lire](../specifications/sections/51_11.md) |
| 51.12 | 2006–2017 | P036, P060 | [Lire](../specifications/sections/51_12.md) |
| 51.13 | 2018–2029 | P035, P061 | [Lire](../specifications/sections/51_13.md) |
| 51.14 | 2030–2041 | P036, P062 | [Lire](../specifications/sections/51_14.md) |
| 51.15 | 2042–2055 | P063 | [Lire](../specifications/sections/51_15.md) |
| 51.16 | 2056–2076 | P038, P064 | [Lire](../specifications/sections/51_16.md) |
| 51.17 | 2077–2088 | P035, P036, P065 | [Lire](../specifications/sections/51_17.md) |
| 51.18 | 2089–2102 | P035, P066 | [Lire](../specifications/sections/51_18.md) |
| 51.19 | 2103–2123 | P010, P077 | [Lire](../specifications/sections/51_19.md) |
| 51.20 | 2124–2234 | P009, P015, P040, P041, P042, P043, P044, P045, P046, P047, P048, P049, P050, P051, P052, P053, P054 | [Lire](../specifications/sections/51_20.md) |
| 51.21 | 2235–2264 | P031, P032 | [Lire](../specifications/sections/51_21.md) |
| 51.22 | 2265–2290 | P032, P033 | [Lire](../specifications/sections/51_22.md) |
| 51.23 | 2291–2301 | P013, P017, P018, P019, P028, P037 | [Lire](../specifications/sections/51_23.md) |
| 51.24 | 2302–2331 | P007, P077 | [Lire](../specifications/sections/51_24.md) |
| 51.25 | 2332–2355 | P001, P002, P015, P016, P017, P020, P076 | [Lire](../specifications/sections/51_25.md) |
| 51.26 | 2356–2373 | P078 | [Lire](../specifications/sections/51_26.md) |
| 51.27 | 2374–2398 | P019, P044, P075, P077 | [Lire](../specifications/sections/51_27.md) |
| 51.28 | 2399–2421 | P078 | [Lire](../specifications/sections/51_28.md) |
| 52 | Nouvel ajout | P005, P009, P039, P054, P067, P077, P078 | [Lire](../specifications/sections/52.md) |
| 53 | Nouvel ajout | P008, P009, P022, P023, P024, P025, P029, P055, P056, P057, P058, P059, P060, P061, P062, P063, P064, P065, P066, P067, P077 | [Lire](../specifications/sections/53.md) |
| 54 | Nouvel ajout | P008, P009, P018, P025, P026, P027, P028, P029, P030, P055, P056, P057, P058, P059, P060, P061, P062, P063, P064, P065, P066, P067, P076, P077, P078 | [Lire](../specifications/sections/54.md) |
| 55 | Nouvel ajout | P047, P079, P080 | [Lire](../specifications/sections/55.md) |
