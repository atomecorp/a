# Catalogue de 89 briques de spécification

**72 briques du cahier précédent + 17 briques de composition pour Réseau, Esthétique et Carnet.** Les BR-* sont des identifiants documentaires à mapper aux outils réels. Ce ne sont ni des fonctions d’API disponibles, ni 89 widgets à recréer. Les modules du carnet/réseau se composent notamment de stockage, permissions, contacts et calendrier communs.

Chaque fiche réelle doit porter : ID stable, but, paramètres utiles/unités, contrôles natifs, conditions de disponibilité, sources possibles, droits, sortie/résultats, tâches consommatrices et statut de validation. Catalogue ≠ programme : seules les briques choisies sont activées.

**Réutilisations à préserver :** photoprotection BR-AGE-03 partagée avec Esthétique ; résultats BR-SUI-05 et stockage BR-SYS-07 partagés avec carnet ; contacts/lien social et BR-SOC-* ne recréent pas la messagerie ; consentements BR-COM-06 et BR-SYS-08 sont raccordés à la même politique réelle.

L’exemple historique `BR-ACT-MARCHE` doit être rapproché de `BR-ACT-01` pendant l’audit, pas créé comme doublon.

| ID | Domaine | Fonction | Tâche pilote | État |
| --- | --- | --- | --- | --- |
| BR-COM-01 | Démarrage | intention | [P005](../prompts/01_socle/P005_entree_objectifs.md) | À AUDITER |
| BR-COM-02 | Démarrage | situation de départ | [P008](../prompts/01_socle/P008_collecte_progressive.md) | À AUDITER |
| BR-COM-03 | Démarrage | effort souhaité | [P006](../prompts/01_socle/P006_effort.md) | À AUDITER |
| BR-COM-04 | Démarrage | temps disponible | [P007](../prompts/01_socle/P007_temps.md) | À AUDITER |
| BR-COM-05 | Démarrage | contraintes/préférences | [P008](../prompts/01_socle/P008_collecte_progressive.md) | À AUDITER |
| BR-COM-06 | Démarrage | consentements | [P008](../prompts/01_socle/P008_collecte_progressive.md) | À AUDITER |
| BR-COM-07 | Démarrage | validation et adaptation | [P010](../prompts/01_socle/P010_composition.md) | À AUDITER |
| BR-SOM-01 | Sommeil | journal sommeil | [P034](../prompts/05_briques_sante/P034_sommeil.md) | À AUDITER |
| BR-SOM-02 | Sommeil | régularité lever/coucher | [P034](../prompts/05_briques_sante/P034_sommeil.md) | À AUDITER |
| BR-SOM-03 | Sommeil | lumière/rythme | [P034](../prompts/05_briques_sante/P034_sommeil.md) | À AUDITER |
| BR-SOM-04 | Sommeil | environnement/rituel | [P034](../prompts/05_briques_sante/P034_sommeil.md) | À AUDITER |
| BR-SOM-05 | Sommeil | stimulants et horaires | [P034](../prompts/05_briques_sante/P034_sommeil.md) | À AUDITER |
| BR-SOM-06 | Sommeil | orientation TCC-I / évaluation clinique | [P034](../prompts/05_briques_sante/P034_sommeil.md) | À AUDITER |
| BR-NUT-01 | Nutrition | habitudes / bilan alimentaire | [P031](../prompts/05_briques_sante/P031_nutrition_repas.md) | À AUDITER |
| BR-NUT-02 | Nutrition | choix de repas | [P031](../prompts/05_briques_sante/P031_nutrition_repas.md) | À AUDITER |
| BR-NUT-03 | Nutrition | qualité des aliments et variété | [P031](../prompts/05_briques_sante/P031_nutrition_repas.md) | À AUDITER |
| BR-NUT-04 | Nutrition | protéines | [P032](../prompts/05_briques_sante/P032_nutrition_reperes.md) | À AUDITER |
| BR-NUT-05 | Nutrition | légumes/fruits/fibres | [P032](../prompts/05_briques_sante/P032_nutrition_reperes.md) | À AUDITER |
| BR-NUT-06 | Nutrition | énergie/alimentation suffisante | [P032](../prompts/05_briques_sante/P032_nutrition_reperes.md) | À AUDITER |
| BR-NUT-07 | Nutrition | hydratation | [P032](../prompts/05_briques_sante/P032_nutrition_reperes.md) | À AUDITER |
| BR-NUT-08 | Nutrition | courses/préparation | [P031](../prompts/05_briques_sante/P031_nutrition_repas.md) | À AUDITER |
| BR-NUT-09 | Nutrition | allergies, intolérances et adaptation | [P031](../prompts/05_briques_sante/P031_nutrition_repas.md) | À AUDITER |
| BR-ACT-01 | Activité physique | marche | [P046](../prompts/06_sport/P046_course_marche.md) | À AUDITER |
| BR-ACT-02 | Activité physique | endurance/course | [P046](../prompts/06_sport/P046_course_marche.md) | À AUDITER |
| BR-ACT-03 | Activité physique | musculation | [P043](../prompts/06_sport/P043_seance_musculation.md) | À AUDITER |
| BR-ACT-04 | Activité physique | natation | [P045](../prompts/06_sport/P045_natation.md) | À AUDITER |
| BR-ACT-05 | Activité physique | rameur | [P047](../prompts/06_sport/P047_rameur.md) | À AUDITER |
| BR-ACT-06 | Activité physique | vélo | [P048](../prompts/06_sport/P048_cyclisme.md) | À AUDITER |
| BR-ACT-07 | Activité physique | mobilité/étirements | [P050](../prompts/06_sport/P050_mobilite_postures.md) | À AUDITER |
| BR-ACT-08 | Activité physique | yoga/pilates | [P050](../prompts/06_sport/P050_mobilite_postures.md) | À AUDITER |
| BR-ACT-09 | Activité physique | équilibre | [P050](../prompts/06_sport/P050_mobilite_postures.md) | À AUDITER |
| BR-ACT-10 | Activité physique | autres sports extensibles | [P040](../prompts/06_sport/P040_catalogue_sports.md) | À AUDITER |
| BR-ACT-11 | Activité physique | récupération/repos | [P015](../prompts/01_socle/P015_execution.md) | À AUDITER |
| BR-ACT-12 | Activité physique | mouvement du quotidien | [P046](../prompts/06_sport/P046_course_marche.md) | À AUDITER |
| BR-MEN-01 | Calme et émotions | respiration confortable | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-02 | Calme et émotions | relaxation | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-03 | Calme et émotions | méditation/attention | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-04 | Calme et émotions | pauses et stress | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-05 | Calme et émotions | repérage de l'humeur | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-06 | Calme et émotions | activation comportementale | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-07 | Calme et émotions | soutien et aide professionnelle | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-MEN-08 | Calme et émotions | plan de sécurité personnalisé avec professionnel lorsque nécessaire | [P035](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | À AUDITER |
| BR-VIE-01 | Vie personnelle | temps pour soi | [P036](../prompts/05_briques_sante/P036_vie_journal.md) | À AUDITER |
| BR-VIE-02 | Vie personnelle | loisirs/création | [P036](../prompts/05_briques_sante/P036_vie_journal.md) | À AUDITER |
| BR-VIE-03 | Vie personnelle | journal privé | [P036](../prompts/05_briques_sante/P036_vie_journal.md) | À AUDITER |
| BR-VIE-04 | Vie personnelle | liens sociaux | [P036](../prompts/05_briques_sante/P036_vie_journal.md) | À AUDITER |
| BR-VIE-05 | Vie personnelle | limites/disponibilité | [P036](../prompts/05_briques_sante/P036_vie_journal.md) | À AUDITER |
| BR-VIE-06 | Vie personnelle | organisation des routines | [P036](../prompts/05_briques_sante/P036_vie_journal.md) | À AUDITER |
| BR-SUI-01 | Santé et suivi | symptômes | [P037](../prompts/05_briques_sante/P037_douleur_orientation.md) | À AUDITER |
| BR-SUI-02 | Santé et suivi | douleur | [P037](../prompts/05_briques_sante/P037_douleur_orientation.md) | À AUDITER |
| BR-SUI-03 | Santé et suivi | consultations/rendez-vous | [P028](../prompts/04_carnet_sante/P028_parcours_soins.md) | À AUDITER |
| BR-SUI-04 | Santé et suivi | examens / prévention | [P028](../prompts/04_carnet_sante/P028_parcours_soins.md) | À AUDITER |
| BR-SUI-05 | Santé et suivi | résultats multi-formats | [P018](../prompts/02_resultats/P018_import_resultats.md) | À AUDITER |
| BR-SUI-06 | Santé et suivi | mesures / capteurs | [P016](../prompts/01_socle/P016_capteurs.md) | À AUDITER |
| BR-SUI-07 | Santé et suivi | traitements déclarés | [P027](../prompts/04_carnet_sante/P027_rubriques_medicales.md) | À AUDITER |
| BR-SUI-08 | Santé et suivi | compléments déclarés/proposés | [P033](../prompts/05_briques_sante/P033_complements.md) | À AUDITER |
| BR-SUI-09 | Santé et suivi | suivi longitudinal | [P020](../prompts/02_resultats/P020_moniteur.md) | À AUDITER |
| BR-SUI-10 | Santé et suivi | orientation et signaux d'alerte | [P037](../prompts/05_briques_sante/P037_douleur_orientation.md) | À AUDITER |
| BR-AGE-01 | Prévention et vieillissement | prévention et suivi adapté | [P038](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | À AUDITER |
| BR-AGE-02 | Prévention et vieillissement | santé fonctionnelle/autonomie | [P038](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | À AUDITER |
| BR-AGE-03 | Prévention et vieillissement | peau et photoprotection | [P038](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | À AUDITER |
| BR-AGE-04 | Prévention et vieillissement | capacités cognitives / activités enrichissantes | [P038](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | À AUDITER |
| BR-AGE-05 | Prévention et vieillissement | santé bucco-dentaire | [P038](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | À AUDITER |
| BR-AGE-06 | Prévention et vieillissement | prévention chutes/équilibre | [P038](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | À AUDITER |
| BR-SYS-01 | Orchestration (déjà unifiée conceptuellement) | matrice de sélection | [P003](../prompts/01_socle/P003_matrice_navigation.md) | À AUDITER |
| BR-SYS-02 | Orchestration (déjà unifiée conceptuellement) | projet Dashboard | [P012](../prompts/01_socle/P012_dashboard_projet.md) | À AUDITER |
| BR-SYS-03 | Orchestration (déjà unifiée conceptuellement) | calendrier/occurrences | [P013](../prompts/01_socle/P013_calendrier.md) | À AUDITER |
| BR-SYS-04 | Orchestration (déjà unifiée conceptuellement) | alarmes | [P014](../prompts/01_socle/P014_alarmes.md) | À AUDITER |
| BR-SYS-05 | Orchestration (déjà unifiée conceptuellement) | outil de séance | [P015](../prompts/01_socle/P015_execution.md) | À AUDITER |
| BR-SYS-06 | Orchestration (déjà unifiée conceptuellement) | Moniteur | [P020](../prompts/02_resultats/P020_moniteur.md) | À AUDITER |
| BR-SYS-07 | Orchestration (déjà unifiée conceptuellement) | stockage/export | [P017](../prompts/02_resultats/P017_stockage_observations.md) | À AUDITER |
| BR-SYS-08 | Orchestration (déjà unifiée conceptuellement) | consentements/partage | [P008](../prompts/01_socle/P008_collecte_progressive.md) | À AUDITER |
| BR-SOC-01 | Réseau optionnel | Option initiale par objectif | [P022](../prompts/03_reseau/P022_option_initiale.md) | À AUDITER |
| BR-SOC-02 | Réseau optionnel | Profil partageable et visibilité | [P022](../prompts/03_reseau/P022_option_initiale.md) | À AUDITER |
| BR-SOC-03 | Réseau optionnel | Découverte et demande réciproque | [P023](../prompts/03_reseau/P023_mise_en_relation.md) | À AUDITER |
| BR-SOC-04 | Réseau optionnel | Échanges et activité commune | [P024](../prompts/03_reseau/P024_echanges_activites.md) | À AUDITER |
| BR-SOC-05 | Réseau optionnel | Retrait, blocage, signalement | [P025](../prompts/03_reseau/P025_confidentialite_moderation.md) | À AUDITER |
| BR-EST-01 | Esthétique | Zone et demande esthétique | [P039](../prompts/05_briques_sante/P039_esthetique.md) | À AUDITER |
| BR-EST-02 | Esthétique | Routine et produits déclarés | [P039](../prompts/05_briques_sante/P039_esthetique.md) | À AUDITER |
| BR-EST-03 | Esthétique | Tolérance et observations de peau | [P039](../prompts/05_briques_sante/P039_esthetique.md) | À AUDITER |
| BR-EST-04 | Esthétique | Photos privées de suivi | [P039](../prompts/05_briques_sante/P039_esthetique.md) | À AUDITER |
| BR-EST-05 | Esthétique | Consultation et suivi de soin | [P039](../prompts/05_briques_sante/P039_esthetique.md) | À AUDITER |
| BR-EST-06 | Esthétique | Catalogue de soins extensible | [P039](../prompts/05_briques_sante/P039_esthetique.md) | À AUDITER |
| BR-CAR-01 | Carnet de santé | Vue transversale et personne | [P026](../prompts/04_carnet_sante/P026_carnet_transversal.md) | À AUDITER |
| BR-CAR-02 | Carnet de santé | Profil de santé structuré | [P027](../prompts/04_carnet_sante/P027_rubriques_medicales.md) | À AUDITER |
| BR-CAR-03 | Carnet de santé | Vaccinations et actes | [P027](../prompts/04_carnet_sante/P027_rubriques_medicales.md) | À AUDITER |
| BR-CAR-04 | Carnet de santé | Provenance et statut documentaire | [P017](../prompts/02_resultats/P017_stockage_observations.md) | À AUDITER |
| BR-CAR-05 | Carnet de santé | Synthèse, export et partage sélectif | [P029](../prompts/04_carnet_sante/P029_export_partage_carnet.md) | À AUDITER |
| BR-CAR-06 | Carnet de santé | Raccordement officiel conditionnel | [P030](../prompts/04_carnet_sante/P030_statut_officiel.md) | À AUDITER |
