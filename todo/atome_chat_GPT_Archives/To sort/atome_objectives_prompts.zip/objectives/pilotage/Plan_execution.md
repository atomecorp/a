# Ordre de réalisation et dépendances

**80 prompts**. Les numéros sont des identifiants stables et des repères de classement, pas une obligation d’exécuter aveuglément tous les fichiers dans l’ordre numérique. L’ordre ci-dessous respecte les dépendances et permet un premier pilote Sommeil avant l’ensemble du catalogue sportif.

Aucune tâche n’est commencée dans ce paquet. **Une seule tâche et un seul jalon visibles actifs à la fois.** Choisir une branche admissible nécessite l’accord de Jeezs. Les tâches de raccordement officiel peuvent conclure à un blocage documenté du raccordement sans simuler une intégration ; le carnet local garde un statut non officiel.

## Ordre proposé

| Rang | Prompt | Dépendances techniques/fonctionnelles |
| --- | --- | --- |
| 1 | [P001 — Inventorier les références et les composants réels](../prompts/01_socle/P001_audit_existant.md) | Aucune |
| 2 | [P002 — Raccorder les objets, les identifiants et l’historique](../prompts/01_socle/P002_contrats_et_migrations.md) | P001 |
| 3 | [P003 — Matrice commune de carrés et navigation profonde](../prompts/01_socle/P003_matrice_navigation.md) | P001, P002 |
| 4 | [P004 — Carré extensible et réglage natif intégré](../prompts/01_socle/P004_carre_reglage.md) | P003 |
| 5 | [P005 — Présenter les treize objectifs et l’objectif libre](../prompts/01_socle/P005_entree_objectifs.md) | P003 |
| 6 | [P006 — Curseur Effort : cinq niveaux d’engagement](../prompts/01_socle/P006_effort.md) | P004, P005 |
| 7 | [P007 — Curseur Temps et budget jour/semaine](../prompts/01_socle/P007_temps.md) | P004, P006 |
| 8 | [P008 — Collecte minimale, préférences et autorisations](../prompts/01_socle/P008_collecte_progressive.md) | P002, P005, P006, P007 |
| 9 | [P009 — Panneau Activités : bibliothèque commune de briques](../prompts/01_socle/P009_activites.md) | P003, P004, P008 |
| 10 | [P010 — Composer et valider les briques une par une](../prompts/01_socle/P010_composition.md) | P009, P006, P007, P008 |
| 11 | [P011 — Prévisualiser le programme, sa charge et les conflits](../prompts/01_socle/P011_apercu_programme.md) | P010, P007 |
| 12 | [P012 — Projet Dashboard : activités du jour et suivi](../prompts/01_socle/P012_dashboard_projet.md) | P011 |
| 13 | [P013 — Calendrier commun et occurrences planifiées](../prompts/01_socle/P013_calendrier.md) | P011, P012 |
| 14 | [P014 — Alarmes et ouverture du bon contexte](../prompts/01_socle/P014_alarmes.md) | P013, P001 |
| 15 | [P015 — Moteur commun d’exécution des activités](../prompts/01_socle/P015_execution.md) | P002, P009, P012, P014 |
| 16 | [P016 — Capteurs disponibles, permissions et suivi manuel](../prompts/01_socle/P016_capteurs.md) | P015, P008 |
| 17 | [P017 — Stockage commun des observations et originaux](../prompts/02_resultats/P017_stockage_observations.md) | P002, P015 |
| 18 | [P018 — Importer un résultat et vérifier l’extraction](../prompts/02_resultats/P018_import_resultats.md) | P017, P009 |
| 19 | [P019 — Évolutions comparables et export CSV](../prompts/02_resultats/P019_evolutions_csv.md) | P017, P018 |
| 20 | [P020 — Moniteur commun : bilan et provenance](../prompts/02_resultats/P020_moniteur.md) | P019, P012, P016 |
| 21 | [P021 — Adapter, suspendre et reprendre un programme](../prompts/02_resultats/P021_adaptation.md) | P020, P011 |
| 22 | [P022 — Proposer la mise en relation au début de chaque objectif](../prompts/03_reseau/P022_option_initiale.md) | P005, P008 |
| 23 | [P026 — Créer le carnet de santé transversal](../prompts/04_carnet_sante/P026_carnet_transversal.md) | P009, P017, P008 |
| 24 | [P027 — Structurer les rubriques du carnet](../prompts/04_carnet_sante/P027_rubriques_medicales.md) | P026 |
| 25 | [P028 — Consultations, examens, ordonnances et suivis](../prompts/04_carnet_sante/P028_parcours_soins.md) | P027, P013, P018 |
| 26 | [P034 — Briques Sommeil refaites et orientation appropriée](../prompts/05_briques_sante/P034_sommeil.md) | P009, P008, P017, P028 |
| 27 | [P056 — OBJ-02 — Mieux dormir et retrouver de l’énergie](../prompts/07_scenarios/P056_obj-02_mieux_dormir.md) | P012, P021, P022, P026, P034 |
| 28 | [P023 — Trouver et demander un contact partageant l’objectif](../prompts/03_reseau/P023_mise_en_relation.md) | P022, P009 |
| 29 | [P024 — Échanger et organiser une activité commune](../prompts/03_reseau/P024_echanges_activites.md) | P023, P013, P015 |
| 30 | [P025 — Blocage, signalement, départ et confidentialité sociale](../prompts/03_reseau/P025_confidentialite_moderation.md) | P024 |
| 31 | [P029 — Exporter et partager une sélection du carnet](../prompts/04_carnet_sante/P029_export_partage_carnet.md) | P028, P019 |
| 32 | [P030 — Qualifier le statut officiel et les raccordements santé](../prompts/04_carnet_sante/P030_statut_officiel.md) | P026, P029, P001 |
| 33 | [P031 — Nutrition : habitudes, repas et préparation](../prompts/05_briques_sante/P031_nutrition_repas.md) | P009, P010, P008 |
| 34 | [P032 — Repères nutritionnels et cibles documentées](../prompts/05_briques_sante/P032_nutrition_reperes.md) | P031, P017 |
| 35 | [P033 — Compléments : catalogue, saisie, dose et prises](../prompts/05_briques_sante/P033_complements.md) | P031, P013, P017, P028 |
| 36 | [P035 — Calme, émotions et soutien en santé mentale](../prompts/05_briques_sante/P035_calme_sante_mentale.md) | P009, P008, P017, P028 |
| 37 | [P036 — Temps pour soi, loisirs et journal privé](../prompts/05_briques_sante/P036_vie_journal.md) | P009, P013, P017, P008 |
| 38 | [P037 — Douleur, symptômes et orientation vers les soins](../prompts/05_briques_sante/P037_douleur_orientation.md) | P009, P008, P017, P028 |
| 39 | [P038 — Prévention, capacités et vieillissement en bonne santé](../prompts/05_briques_sante/P038_prevention_vieillissement.md) | P009, P028, P017 |
| 40 | [P039 — Briques Esthétique : visage, corps, peau et soins](../prompts/05_briques_sante/P039_esthetique.md) | P009, P008, P028, P017 |
| 41 | [P040 — Catalogue sportif et contrats de discipline extensibles](../prompts/06_sport/P040_catalogue_sports.md) | P009, P015, P017 |
| 42 | [P041 — Groupes musculaires, mouvements, positions et variantes](../prompts/06_sport/P041_mouvements.md) | P040 |
| 43 | [P042 — Ajouter et modifier une machine personnelle](../prompts/06_sport/P042_machines.md) | P041, P004 |
| 44 | [P043 — Configurer une séance de musculation détaillée](../prompts/06_sport/P043_seance_musculation.md) | P042, P010, P013 |
| 45 | [P044 — Exécuter et enregistrer les séries au toucher](../prompts/06_sport/P044_series_interactives.md) | P043, P015, P017, P016 |
| 46 | [P054 — Pictogrammes : produire seulement les références manquantes](../prompts/06_sport/P054_pictogrammes.md) | P001, P041, P039 |
| 47 | [P057 — OBJ-03 — Prendre de la masse musculaire](../prompts/07_scenarios/P057_obj-03_masse_musculaire.md) | P012, P021, P022, P026, P032, P033, P044 |
| 48 | [P055 — OBJ-01 — Perdre du poids](../prompts/07_scenarios/P055_obj-01_perdre_poids.md) | P012, P021, P022, P026, P031, P032, P037 |
| 49 | [P045 — Natation : bassin, nages, longueurs et intervalles](../prompts/06_sport/P045_natation.md) | P040, P015, P013, P017, P016 |
| 50 | [P046 — Course, marche et tapis : distance, temps et allure](../prompts/06_sport/P046_course_marche.md) | P040, P015, P013, P017, P016 |
| 51 | [P047 — Rameur intérieur et aviron : cadence et allure](../prompts/06_sport/P047_rameur.md) | P040, P015, P013, P017, P016 |
| 52 | [P048 — Vélo extérieur, VTT et vélo d’intérieur](../prompts/06_sport/P048_cyclisme.md) | P040, P015, P013, P017, P016 |
| 53 | [P049 — Cardio intérieur, fitness et circuits](../prompts/06_sport/P049_cardio_circuits.md) | P040, P015, P013, P017 |
| 54 | [P050 — Mobilité, postures, yoga, Pilates et équilibre](../prompts/06_sport/P050_mobilite_postures.md) | P040, P015, P017 |
| 55 | [P051 — Sports de plein air et environnements](../prompts/06_sport/P051_plein_air.md) | P040, P015, P017, P016 |
| 56 | [P052 — Danse, raquettes, collectifs et combat](../prompts/06_sport/P052_sports_standard.md) | P040, P015, P017, P024 |
| 57 | [P053 — Sport adapté et activité non cataloguée](../prompts/06_sport/P053_adaptation_sport_libre.md) | P040, P050, P008 |
| 58 | [P063 — OBJ-09 — Améliorer sa condition physique](../prompts/07_scenarios/P063_obj-09_condition_physique.md) | P012, P021, P022, P026, P044, P045, P046, P047, P048, P050, P053 |
| 59 | [P058 — OBJ-04 — Gérer une douleur](../prompts/07_scenarios/P058_obj-04_gerer_douleur.md) | P012, P021, P022, P026, P035, P037 |
| 60 | [P059 — OBJ-05 — Repérer un trouble et être orienté](../prompts/07_scenarios/P059_obj-05_reperer_trouble.md) | P012, P018, P021, P022, P026, P028, P037 |
| 61 | [P060 — OBJ-06 — Préserver du temps pour soi](../prompts/07_scenarios/P060_obj-06_temps_pour_soi.md) | P012, P021, P022, P026, P036 |
| 62 | [P061 — OBJ-07 — Retrouver le calme intérieur](../prompts/07_scenarios/P061_obj-07_calme_interieur.md) | P012, P021, P022, P026, P035, P036 |
| 63 | [P062 — OBJ-08 — Tenir un journal personnel](../prompts/07_scenarios/P062_obj-08_journal_personnel.md) | P012, P021, P022, P026, P036 |
| 64 | [P064 — OBJ-10 — Rajeunissement / vieillir en bonne santé](../prompts/07_scenarios/P064_obj-10_vieillir_sante.md) | P012, P021, P022, P026, P032, P038, P039 |
| 65 | [P065 — OBJ-11 — Améliorer son bien-être](../prompts/07_scenarios/P065_obj-11_bien_etre.md) | P012, P021, P022, P026, P035, P036, P038 |
| 66 | [P066 — OBJ-12 — Prendre soin de sa santé mentale](../prompts/07_scenarios/P066_obj-12_sante_mentale.md) | P012, P021, P022, P025, P026, P035, P036, P037 |
| 67 | [P067 — OBJ-13 — Esthétique — visage, corps et peau](../prompts/07_scenarios/P067_obj-13_esthetique.md) | P012, P021, P022, P026, P029, P033, P038, P039 |
| 68 | [P068 — Objectif libre, sous-objectifs et parcours composables](../prompts/08_extension_generale/P068_objectif_libre.md) | P010, P021, P022 |
| 69 | [P069 — Scénario historique : créer un album](../prompts/08_extension_generale/P069_scenario_album.md) | P068, P013, P024 |
| 70 | [P070 — Scénario historique : réaliser un film](../prompts/08_extension_generale/P070_scenario_film.md) | P068, P013, P024 |
| 71 | [P071 — Scénario historique : entreprise, équipe et financement](../prompts/08_extension_generale/P071_entreprise_financement.md) | P068, P024, P013 |
| 72 | [P072 — Scénario historique : organiser une randonnée](../prompts/08_extension_generale/P072_scenario_randonnee.md) | P068, P051, P013, P024 |
| 73 | [P073 — Scénario historique : objectif marathon](../prompts/08_extension_generale/P073_scenario_marathon.md) | P068, P046, P032, P037 |
| 74 | [P074 — Préserver le catalogue historique et créer les prochaines tâches](../prompts/08_extension_generale/P074_catalogue_et_decoupage.md) | P068, P069, P070, P071, P072, P073 |
| 75 | [P075 — Accessibilité, tailles d’écran et modes d’usage](../prompts/09_validation/P075_accessibilite_modes.md) | P067, P054 |
| 76 | [P076 — Persistance, synchronisation, permissions et récupération](../prompts/09_validation/P076_persistance_securite.md) | P029, P025, P021, P044 |
| 77 | [P077 — Tests de bout en bout : treize objectifs, activités et carnet](../prompts/09_validation/P077_parcours_integres.md) | P055, P056, P057, P058, P059, P060, P061, P062, P063, P064, P065, P066, P067, P025, P029, P054 |
| 78 | [P078 — Revue clinique, juridique et éditoriale avant activation](../prompts/09_validation/P078_revue_contenus.md) | P032, P033, P034, P035, P037, P038, P039, P030 |
| 79 | [P079 — Recette fonctionnelle finale par Jeezs](../prompts/09_validation/P079_recette_utilisateur.md) | P075, P076, P077, P078 |
| 80 | [P080 — Clôturer le lot et préparer la suite sans l’exécuter](../prompts/09_validation/P080_livraison_progressive.md) | P079 |

## Tranches utiles

**Première tranche :** auditer puis faire valider la matrice, le carré extensible, les curseurs et la composition. Aucun nouveau sport n’est nécessaire pour valider ces fondations.

**Premier parcours complet :** P034 + P056, une fois leurs dépendances prêtes : Sommeil, refus des activités non souhaitées, agenda, exécution, résultat et carnet. L’option sociale P022 est visible au début, sans imposer de participer au réseau.

**Deuxième démonstrateur :** P040–P044 puis P057 : machine personnelle, séance bras, séries au toucher, correction, budget et historique partagés. Les autres sports réutilisent ce moteur.

**Élargissement :** autres briques, réseau pleinement fonctionnel, carnet/export, Esthétique et les douze autres scénarios. Chaque nouvelle surface déclenche sa validation, même si elle utilise un composant déjà vu.

**Clôture :** recette technique et confidentialité, revue compétente des conseils et allégations, recette de Jeezs, livraison. Les recettes ne peuvent pas être remplacées par le présent plan.

## Sous-découpage pendant l’exécution

Si une tâche dépasse un changement isolé vérifiable, rédiger Pxxx-A/Pxxx-B… au moyen du gabarit, avec dépendances et un jalon par écran. Soumettre ce sous-découpage à Jeezs avant de l’exécuter. Mettre à jour plan et suivi sans retirer les exigences sources. Un sous-découpage n’accorde pas l’autorisation de traiter tous ses morceaux d’un coup.
