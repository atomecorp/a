# atome/eVe — objectifs : dossier de réalisation

**À ouvrir d’abord : [Objectif.md](Objectif.md).** Le prompt maître y est prêt à transmettre à Codex.

Contenu : cahier complet consolidé, 80 prompts par tâches, treize scénarios, catalogue de 89 briques de spécification, dépendances, traçabilité et gabarits de validation. Les ajouts Réseau optionnel, Esthétique et Carnet de santé sont intégrés.

## Dépôt dans la bibliothèque

Destination demandée : `/atome/objectives`. Le ZIP contient un dossier racine `objectives/`. Déposer **son contenu** dans le dossier déjà créé, sans créer involontairement `objectives/objectives`.

Le paquet a été créé localement et n’a pas été téléversé dans la bibliothèque par un outil d’écriture. Il n’écrase pas le fichier historique à la racine de la bibliothèque. La source complète récupérée est conservée dans `sources/` ; comparer toute version plus récente avant remplacement.

## Démarrage

Donner `Objectif.md` et le dossier à Codex, puis commencer seulement P001. À chaque nouvel écran : tests de prévisualisation, affichage, arrêt pour accord visuel, intégration, tests intégrés. Jeezs fait la recette fonctionnelle en fin de tâche. Aucune avancée automatique.

## État réel

Seuls la documentation et son archive ont été produits. Aucun code applicatif, panneau, pictogramme, test sur appareil, agrément ou validation médicale n’est présenté comme déjà réalisé. Les registres sont vierges.

[Contrôle d’intégrité du paquet](VERIFICATION.md) · [Suivi des tâches](pilotage/Suivi_taches.md)
