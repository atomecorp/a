# P078 — Revue clinique, juridique et éditoriale avant activation

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P078**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Ne pas assimiler un programme de code sans bugs à un conseil médical validé.

## Dépendances

- [P032 — Repères nutritionnels et cibles documentées](../05_briques_sante/P032_nutrition_reperes.md) ; vérifier sa recette réelle.
- [P033 — Compléments : catalogue, saisie, dose et prises](../05_briques_sante/P033_complements.md) ; vérifier sa recette réelle.
- [P034 — Briques Sommeil refaites et orientation appropriée](../05_briques_sante/P034_sommeil.md) ; vérifier sa recette réelle.
- [P035 — Calme, émotions et soutien en santé mentale](../05_briques_sante/P035_calme_sante_mentale.md) ; vérifier sa recette réelle.
- [P037 — Douleur, symptômes et orientation vers les soins](../05_briques_sante/P037_douleur_orientation.md) ; vérifier sa recette réelle.
- [P038 — Prévention, capacités et vieillissement en bonne santé](../05_briques_sante/P038_prevention_vieillissement.md) ; vérifier sa recette réelle.
- [P039 — Briques Esthétique : visage, corps, peau et soins](../05_briques_sante/P039_esthetique.md) ; vérifier sa recette réelle.
- [P030 — Qualifier le statut officiel et les raccordements santé](../04_carnet_sante/P030_statut_officiel.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.5](../../specifications/sections/51_5.md) — lignes source 1892–1913.
- [Section 51.26](../../specifications/sections/51_26.md) — lignes source 2356–2373.
- [Section 51.28](../../specifications/sections/51_28.md) — lignes source 2399–2421.
- [Décision 52 du présent lot](../../specifications/sections/52.md).
- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Revoir chaque conseil/valeur/condition avec source actuelle primaire, population, limites et professionnel compétent responsable de la revue.
2. Séparer tests numériques, exemple UX et recommandation ; garder désactivée une préconisation non validée, sans bloquer le stockage d’une donnée déclarée.
3. Qualifier protections de données, public cible, éventuel dispositif médical et allégations de carnet officiel avec les personnes responsables, sans autodéclaration de conformité.
4. Prévoir retrait d’un contenu, version et mise à jour sans corrompre l’historique ; une ancienne consigne ne s’applique pas automatiquement à une nouvelle situation.
5. Archiver les validations humaines réelles, pas des champs automatiquement marqués approuvés.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Voir une recommandation en attente de revue et un suivi déclaratif toujours utilisable.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Après vraie revue seulement, afficher le contenu activé avec information nécessaire à la demande, sans surcharge visuelle.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Traçabilité de toutes les valeurs actives vers une source et un statut de revue.
- Aucune « validation médicale Codex » fictive ni logo officiel non autorisé.
- Retrait d’un conseil et conservation des dossiers historiques.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
