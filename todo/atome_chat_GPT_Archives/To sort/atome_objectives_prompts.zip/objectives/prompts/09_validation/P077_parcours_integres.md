# P077 — Tests de bout en bout : treize objectifs, activités et carnet

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P077**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Vérifier le produit intégré sans se limiter à l’apparence des écrans.

## Dépendances

- [P055 — OBJ-01 — Perdre du poids](../07_scenarios/P055_obj-01_perdre_poids.md) ; vérifier sa recette réelle.
- [P056 — OBJ-02 — Mieux dormir et retrouver de l’énergie](../07_scenarios/P056_obj-02_mieux_dormir.md) ; vérifier sa recette réelle.
- [P057 — OBJ-03 — Prendre de la masse musculaire](../07_scenarios/P057_obj-03_masse_musculaire.md) ; vérifier sa recette réelle.
- [P058 — OBJ-04 — Gérer une douleur](../07_scenarios/P058_obj-04_gerer_douleur.md) ; vérifier sa recette réelle.
- [P059 — OBJ-05 — Repérer un trouble et être orienté](../07_scenarios/P059_obj-05_reperer_trouble.md) ; vérifier sa recette réelle.
- [P060 — OBJ-06 — Préserver du temps pour soi](../07_scenarios/P060_obj-06_temps_pour_soi.md) ; vérifier sa recette réelle.
- [P061 — OBJ-07 — Retrouver le calme intérieur](../07_scenarios/P061_obj-07_calme_interieur.md) ; vérifier sa recette réelle.
- [P062 — OBJ-08 — Tenir un journal personnel](../07_scenarios/P062_obj-08_journal_personnel.md) ; vérifier sa recette réelle.
- [P063 — OBJ-09 — Améliorer sa condition physique](../07_scenarios/P063_obj-09_condition_physique.md) ; vérifier sa recette réelle.
- [P064 — OBJ-10 — Rajeunissement / vieillir en bonne santé](../07_scenarios/P064_obj-10_vieillir_sante.md) ; vérifier sa recette réelle.
- [P065 — OBJ-11 — Améliorer son bien-être](../07_scenarios/P065_obj-11_bien_etre.md) ; vérifier sa recette réelle.
- [P066 — OBJ-12 — Prendre soin de sa santé mentale](../07_scenarios/P066_obj-12_sante_mentale.md) ; vérifier sa recette réelle.
- [P067 — OBJ-13 — Esthétique — visage, corps et peau](../07_scenarios/P067_obj-13_esthetique.md) ; vérifier sa recette réelle.
- [P025 — Blocage, signalement, départ et confidentialité sociale](../03_reseau/P025_confidentialite_moderation.md) ; vérifier sa recette réelle.
- [P029 — Exporter et partager une sélection du carnet](../04_carnet_sante/P029_export_partage_carnet.md) ; vérifier sa recette réelle.
- [P054 — Pictogrammes : produire seulement les références manquantes](../06_sport/P054_pictogrammes.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.24](../../specifications/sections/51_24.md) — lignes source 2302–2331.
- [Section 51.27](../../specifications/sections/51_27.md) — lignes source 2374–2398.
- [Décision 52 du présent lot](../../specifications/sections/52.md).
- [Décision 53 du présent lot](../../specifications/sections/53.md).
- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Rejouer chaque objectif : choix social, collecte, effort, temps, décisions de briques, aperçu, agenda, activité réelle, résultat, carnet autorisé, Moniteur et adaptation.
2. Effectuer une première passe avec les outils de l’interface eVe uniquement ; une seconde par les MCP réellement exposés, sans simuler leur existence ni contourner les autorisations.
3. Inclure cas refus, inconnus, capteur absent, prise non confirmée, résultat non numérique, machine personnelle, compte secondaire et activité partagée.
4. Mesurer réactivité, mémoire et processeur dans les scénarios réels ; objectifs de performance à reprendre du dépôt, pas succès annoncé à partir d’une capture.
5. Rapprocher les résultats des validations visuelles et de l’intégration, avec preuves et blocages.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Démontrer le pilote Sommeil complet puis une séance Musculation et le carnet réellement alimenté ; un parcours à la fois.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Montrer Esthétique, réseau optionnel et un résultat non sanguin ; chaque nouveauté doit déjà avoir son accord.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V03 — proposition à montrer

Présenter les régressions visuelles éventuelles séparément, avant correction/intégration.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Treize scénarios exécutés et assertions de données vérifiées, pas seulement clics.
- UI et MCP : résultats séparés avec PASS/FAIL/BLOQUÉ/NON TESTÉ.
- Aucune fuite de santé, fausse mesure, prescription ou publication sociale silencieuse.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
