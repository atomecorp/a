# P076 — Persistance, synchronisation, permissions et récupération

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P076**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Garantir la cohérence des données et tester la récupération sans prétendre récupérer un stockage détruit.

## Dépendances

- [P029 — Exporter et partager une sélection du carnet](../04_carnet_sante/P029_export_partage_carnet.md) ; vérifier sa recette réelle.
- [P025 — Blocage, signalement, départ et confidentialité sociale](../03_reseau/P025_confidentialite_moderation.md) ; vérifier sa recette réelle.
- [P021 — Adapter, suspendre et reprendre un programme](../02_resultats/P021_adaptation.md) ; vérifier sa recette réelle.
- [P044 — Exécuter et enregistrer les séries au toucher](../06_sport/P044_series_interactives.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 38](../../specifications/sections/38.md) — lignes source 1245–1265.
- [Section 45](../../specifications/sections/45.md) — lignes source 1414–1482.
- [Section 48](../../specifications/sections/48.md) — lignes source 1511–1534.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.
- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Tester arrêt/reprise, réseau absent, échecs d’écriture, synchronisation concurrente et changement d’appareil avec les mécanismes réels.
2. Tester réinstallation/effacement de cache uniquement sur compte et données de test, avec sauvegarde préalable et autorisation de l’action destructive.
3. Distinguer données locales supprimées et données restaurables via sauvegarde/synchronisation existante ; documenter les limites.
4. Contrôler permissions carnet/social/capteurs/fichiers, traces, secrets et accès croisés ; chiffrage et hébergement nécessitent preuves réelles.
5. Toute correction migratoire prévoit sauvegarde, rollback et conservation de l’historique non destructif.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Même programme et carnet avant/après reprise puis restauration de test.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Vue d’un second compte non autorisé et révocation ; aucune donnée sensible visible.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Sessions, séries, documents et liens exacts après reprise.
- Pas de duplication lors de conflit/offline.
- Aucune perte silencieuse ; scénario de restauration réellement démontré ou marqué bloqué.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
