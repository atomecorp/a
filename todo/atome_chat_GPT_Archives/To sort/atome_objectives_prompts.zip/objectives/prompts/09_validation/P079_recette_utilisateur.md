# P079 — Recette fonctionnelle finale par Jeezs

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P079**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Faire tester le résultat fonctionnel par Jeezs après les tests techniques de Codex.

## Dépendances

- [P075 — Accessibilité, tailles d’écran et modes d’usage](P075_accessibilite_modes.md) ; vérifier sa recette réelle.
- [P076 — Persistance, synchronisation, permissions et récupération](P076_persistance_securite.md) ; vérifier sa recette réelle.
- [P077 — Tests de bout en bout : treize objectifs, activités et carnet](P077_parcours_integres.md) ; vérifier sa recette réelle.
- [P078 — Revue clinique, juridique et éditoriale avant activation](P078_revue_contenus.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 44](../../specifications/sections/44.md) — lignes source 1387–1413.
- [Section 45](../../specifications/sections/45.md) — lignes source 1414–1482.
- [Section 48](../../specifications/sections/48.md) — lignes source 1511–1534.
- [Décision 55 du présent lot](../../specifications/sections/55.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Livrer un build identifié, les tâches intégrées, les validations visuelles associées et les tests techniques effectivement passés.
2. Présenter le parcours utilisateur final sans demander à Jeezs de refaire les tests techniques unitaires.
3. Laisser Jeezs tester librement puis consigner retours et résultat de recette ; aucun consentement déduit du silence.
4. Corriger une observation dans une petite tâche de retour ; toute nouvelle différence visuelle repasse par son jalon humain.
5. Ne pas publier ni ouvrir à des utilisateurs réels sur la seule base de cette recette si des gates réglementaires ou cliniques restent bloqués.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Présenter l’ensemble intégré et son parcours de test dans le vrai environnement, pas une vidéo seule.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Présenter chaque correction visible demandée, puis la version finale après intégration.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Tous les bugs bloquants résolus ou explicitement identifiés ; pas de fausse recette complète.
- Build et captures correspondent au code testé.
- Acceptation de fin de tâche et de périmètre conservée textuellement.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
