# P075 — Accessibilité, tailles d’écran et modes d’usage

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P075**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Vérifier les interfaces validées sur les contextes réellement pris en charge.

## Dépendances

- [P067 — OBJ-13 — Esthétique — visage, corps et peau](../07_scenarios/P067_obj-13_esthetique.md) ; vérifier sa recette réelle.
- [P054 — Pictogrammes : produire seulement les références manquantes](../06_sport/P054_pictogrammes.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 0](../../specifications/sections/0.md) — lignes source 3–18.
- [Section 45](../../specifications/sections/45.md) — lignes source 1414–1482.
- [Section 50.7](../../specifications/sections/50_7.md) — lignes source 1650–1674.
- [Section 51.27](../../specifications/sections/51_27.md) — lignes source 2374–2398.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Tester iPad en priorité pour iOS, puis autres appareils disponibles, web et macOS selon les cibles du dépôt ; ne pas affirmer une couverture sans accès.
2. Toucher, souris, clavier et technologies d’assistance : navigation profonde, slider accessible, focus conservé, grandes cibles utiles et noms parlants.
3. Tester débutant/intermédiaire/expert et modes d’usage existants en utilisant leurs vrais noms dans le code ; ne pas renommer arbitrairement Consultation/Consumer ou Performance/Exécution.
4. Verifier changements d’orientation, échelles et animations réduites sans modifier les proportions et références approuvées.
5. Toute correction visible ouvre un nouveau jalon visuel, même si elle résout un bug technique.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Même parcours approuvé sur iPad puis petit écran ; valider chaque divergence à corriger.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Parcours clavier/lecteur d’écran et modes d’expertise ; montrer les commandes réellement disponibles.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Pas de contrôle inaccessible, texte coupé ou focus perdu.
- Les données et permissions ne changent pas selon le niveau visuel.
- Couverture détaillée par plateforme, aucun test indisponible marqué réussi.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
