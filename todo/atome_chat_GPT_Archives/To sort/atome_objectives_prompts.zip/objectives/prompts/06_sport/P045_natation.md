# P045 — Natation : bassin, nages, longueurs et intervalles

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P045**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Adapter le suivi de natation à la piscine ou à l’eau libre.

## Dépendances

- [P040 — Catalogue sportif et contrats de discipline extensibles](P040_catalogue_sports.md) ; vérifier sa recette réelle.
- [P015 — Moteur commun d’exécution des activités](../01_socle/P015_execution.md) ; vérifier sa recette réelle.
- [P013 — Calendrier commun et occurrences planifiées](../01_socle/P013_calendrier.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P016 — Capteurs disponibles, permissions et suivi manuel](../01_socle/P016_capteurs.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.9](../../specifications/sections/50_9.md) — lignes source 1695–1731.
- [Section 51.20](../../specifications/sections/51_20.md) — lignes source 2124–2234.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Décliner Piscine/Eau libre → nage/séance : crawl, brasse, dos, papillon, éducatifs et aquagym selon contexte.
2. Piscine : longueur réelle du bassin, nombre de longueurs, séries/intervalles et repos. Eau libre : pas de longueur de bassin inventée.
3. Permettre suivi manuel, saisie après sortie de l’eau et montre compatible autorisée ; ne pas demander de manipuler un téléphone pendant la nage.
4. Distance calculée uniquement depuis longueurs confirmées et longueur de bassin fiable ; dater les changements de bassin.
5. Cas de test : bassin 25 m, douze longueurs déclarées = 300 m. Ce cas n’est pas une prescription.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Piscine, nage, bassin et longueurs dans les matrices avec valeurs utiles seulement.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Suivi sans montre, correction puis bilan ; présenter séparément le parcours Eau libre.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- 25×12 = 300 m seulement pour réalisations validées.
- Absence de montre, temps inconnu et correction rétroactive.
- Aucune longueur inventée en eau libre ni capteur déclaré actif sans source.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
