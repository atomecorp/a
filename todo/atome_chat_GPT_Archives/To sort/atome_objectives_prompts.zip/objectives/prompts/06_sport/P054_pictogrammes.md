# P054 — Pictogrammes : produire seulement les références manquantes

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P054**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Associer à chaque brique et mouvement une représentation lisible conforme au projet.

## Dépendances

- [P001 — Inventorier les références et les composants réels](../01_socle/P001_audit_existant.md) ; vérifier sa recette réelle.
- [P041 — Groupes musculaires, mouvements, positions et variantes](P041_mouvements.md) ; vérifier sa recette réelle.
- [P039 — Briques Esthétique : visage, corps, peau et soins](../05_briques_sante/P039_esthetique.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.20](../../specifications/sections/51_20.md) — lignes source 2124–2234.
- [Décision 52 du présent lot](../../specifications/sections/52.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Inventorier les SVG/icônes déjà utilisés et leurs droits ; conserver exactement leurs proportions, couleurs et comportement.
2. Établir les lacunes par famille : discipline, biceps/triceps/autres mouvements, positions et Esthétique. Une machine personnelle peut reprendre le mouvement et une photo autorisée.
3. Proposer une seule petite famille manquante à la fois ; vérifier compréhension du mouvement et cohérence anatomique avant intégration.
4. Afficher dans la vraie cellule en états clair/sombre et aux tailles réellement prises en charge, avec libellé accessible.
5. Aucune génération d’image ou validation visuelle n’est réputée accomplie par la présence de ce prompt.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Comparaison des références existantes et d’une seule famille proposée, dans leurs vraies cellules.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Pour chaque famille suivante : nouveau point d’arrêt ; valider aussi les variantes et états réellement différents.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- SVG valides, droits, absence d’asset manquant et noms stables.
- Lisibilité aux tailles réelles et contraste/focus/accessibilité.
- Aucun pictogramme décoratif substitué au module fonctionnel.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
