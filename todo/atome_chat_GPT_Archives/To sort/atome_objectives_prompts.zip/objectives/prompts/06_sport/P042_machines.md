# P042 — Ajouter et modifier une machine personnelle

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P042**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Permettre des machines spécifiques sans développement d’un écran par appareil.

## Dépendances

- [P041 — Groupes musculaires, mouvements, positions et variantes](P041_mouvements.md) ; vérifier sa recette réelle.
- [P004 — Carré extensible et réglage natif intégré](../01_socle/P004_carre_reglage.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.20](../../specifications/sections/51_20.md) — lignes source 2124–2234.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Matrice Matériel → Ajouter → Machine : nom, type, mouvements associés, position, charge affichée ou assistance, unité, pas disponibles et réglages propres connus.
2. Photo/picto et lieu sont facultatifs et privés par défaut ; valeurs inconnues laissées vides.
3. Distinguer résistance et assistance, ainsi que niveau d’appareil et masse. Ne pas comparer directement des charges de machines à poulies/leviers différents.
4. Ajouter des réglages natifs extensibles typés (siège, poignée, niveau) sans exécuter des scripts utilisateur ; conserver valeurs historiques.
5. Archiver un équipement conserve les séances qui le référencent. Connecter un appareil électronique uniquement après identification et autorisation du vrai connecteur.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Créer « Machine triceps de ma salle » dans les matrices et régler ses champs utiles.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Réutiliser la machine dans un exercice puis modifier/archiver sans perdre une séance passée.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Nom doublonné, unités, pas, champ inconnu et migration de fiche.
- Assistance n’est pas interprétée comme résistance croissante.
- Pas de capteur déduit d’une photo ou d’un nom commercial.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
