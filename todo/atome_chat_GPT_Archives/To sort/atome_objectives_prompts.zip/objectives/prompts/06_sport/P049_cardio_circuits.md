# P049 — Cardio intérieur, fitness et circuits

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P049**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Assembler des séances multisports sans forcer les mêmes champs sur tous les appareils.

## Dépendances

- [P040 — Catalogue sportif et contrats de discipline extensibles](P040_catalogue_sports.md) ; vérifier sa recette réelle.
- [P015 — Moteur commun d’exécution des activités](../01_socle/P015_execution.md) ; vérifier sa recette réelle.
- [P013 — Calendrier commun et occurrences planifiées](../01_socle/P013_calendrier.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.20](../../specifications/sections/51_20.md) — lignes source 2124–2234.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Adapter elliptique, stepper, escaliers, corde et ski-erg par définitions de paramètres : durée, cadence, répétitions ou niveaux propres selon appareil.
2. Composer circuits avec exercice, durée ou répétitions, repos et tours ; réutiliser l’exécution commune.
3. Une séance rameur → renforcement → marche conserve une session parent et des segments, pas trois séances doublement comptées.
4. Ne pas suggérer HIIT ou échec musculaire par défaut ; méthodes avancées seulement dans contexte et contenu revus.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Un appareil de cardio intérieur avec ses champs spécifiques.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Circuit de trois briques, repos et tours ; présenter chaque nouvel adaptateur d’appareil séparément.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Pas de distance inventée pour un appareil sans distance.
- Tours/étapes parent/enfant et temps actif/repos cohérents.
- Type d’appareil inconnu conserve un suivi manuel honnête.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
