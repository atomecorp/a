# P014 — Alarmes et ouverture du bon contexte

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P014**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Ouvrir le bon projet et la bonne activité au moment prévu selon les capacités autorisées.

## Dépendances

- [P013 — Calendrier commun et occurrences planifiées](P013_calendrier.md) ; vérifier sa recette réelle.
- [P001 — Inventorier les références et les composants réels](P001_audit_existant.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 31](../../specifications/sections/31.md) — lignes source 1065–1083.
- [Section 41](../../specifications/sections/41.md) — lignes source 1312–1328.
- [Section 50.4](../../specifications/sections/50_4.md) — lignes source 1604–1632.
- [Section 50.9](../../specifications/sections/50_9.md) — lignes source 1695–1731.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Raccorder l’alarme existante à l’occurrence ; différencier application active, arrière-plan, verrouillée ou arrêtée.
2. En avant-plan, ouvrir le contexte autorisé dans atome. Si la plateforme exige une action sur la notification, prévoir le lien qui reprend exactement ce contexte.
3. Aucune technique de contournement OS ni promesse de premier plan automatique universel ; vérifier la documentation native pendant l’audit technique.
4. Une alarme n’atteste pas une activité réalisée ou un complément pris. Ne pas révéler de détails de santé sur écran verrouillé.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Alarme dans atome actif : affichage de la bonne activité.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Notification sur appareil réellement verrouillé puis ouverture par l’action autorisée ; présentation discrète.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Refus des notifications, report, suppression et récurrence.
- Redémarrage et ouverture à froid avec identité/session restaurée.
- Pas de capteur démarré du seul fait d’une notification affichée.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
