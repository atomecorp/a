# P002 — Raccorder les objets, les identifiants et l’historique

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P002**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Conserver une seule vérité pour objectif, programme, brique, activité, occurrence et résultat.

## Dépendances

- [P001 — Inventorier les références et les composants réels](P001_audit_existant.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 1](../../specifications/sections/1.md) — lignes source 19–90.
- [Section 2](../../specifications/sections/2.md) — lignes source 91–130.
- [Section 3](../../specifications/sections/3.md) — lignes source 131–211.
- [Section 4](../../specifications/sections/4.md) — lignes source 212–325.
- [Section 5](../../specifications/sections/5.md) — lignes source 326–366.
- [Section 26](../../specifications/sections/26.md) — lignes source 902–939.
- [Section 36](../../specifications/sections/36.md) — lignes source 1201–1225.
- [Section 38](../../specifications/sections/38.md) — lignes source 1245–1265.
- [Section 39](../../specifications/sections/39.md) — lignes source 1266–1286.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Mapper les entités du cahier au modèle réel ; définir les relations manquantes au plus petit périmètre. Préserver les projets existants.
2. Distinguer un type de brique réutilisable de son paramétrage et de l’occurrence effectivement réalisée. Un lien à deux objectifs ne crée pas deux séances.
3. Définir les statuts, versions, unités, dates, auteurs, source, droits et valeurs absentes. Ne pas confondre non renseigné et zéro.
4. Préparer une migration versionnée et réversible avec sauvegarde ; utiliser le stockage et les identités du projet. Un rollback conserve les résultats réellement acquis.
5. Prévoir les rôles source utilisateur, appareil, document importé, professionnel vérifié et interprétation IA ; aucun titre « validé médicalement » dérivé d’un simple import.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Montrer dans la surface de projet existante un jeu fictif explicitement identifié : un objectif, une activité, deux liens et une seule réalisation. Pour cette tâche de données, ne pas inventer une UI de gestion.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Montrer le même projet après sauvegarde/rechargement et après migration de test ; présenter toute différence visible avant intégration.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Migration aller/retour sur une copie des données et reprise sans corruption.
- Ajout répété d’un même événement : une réalisation unique.
- Une correction historisée n’efface pas la valeur source ; droits distincts sur les résultats.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
