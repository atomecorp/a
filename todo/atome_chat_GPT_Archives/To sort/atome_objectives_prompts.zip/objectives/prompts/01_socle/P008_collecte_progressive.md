# P008 — Collecte minimale, préférences et autorisations

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P008**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Poser seulement les questions qui changent la prochaine décision.

## Dépendances

- [P002 — Raccorder les objets, les identifiants et l’historique](P002_contrats_et_migrations.md) ; vérifier sa recette réelle.
- [P005 — Présenter les treize objectifs et l’objectif libre](P005_entree_objectifs.md) ; vérifier sa recette réelle.
- [P006 — Curseur Effort : cinq niveaux d’engagement](P006_effort.md) ; vérifier sa recette réelle.
- [P007 — Curseur Temps et budget jour/semaine](P007_temps.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 4](../../specifications/sections/4.md) — lignes source 212–325.
- [Section 32](../../specifications/sections/32.md) — lignes source 1084–1106.
- [Section 51.2](../../specifications/sections/51_2.md) — lignes source 1817–1835.
- [Section 51.6](../../specifications/sections/51_6.md) — lignes source 1914–1921.
- [Décision 53 du présent lot](../../specifications/sections/53.md).
- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Consulter les données pertinentes existantes uniquement avec permission ; conserver leur origine, date et éventuelle incertitude.
2. Afficher une question/brique à la fois avec Je ne sais pas/Plus tard si la donnée n’est pas indispensable ; expliquer un vrai blocage sans inventer une réponse.
3. Demander la capacité du moment et le matériel à l’activation du sport, les allergies à la sélection nutritionnelle, pas tout le carnet à la création.
4. Le refus d’accès au carnet, au journal, aux capteurs ou au réseau social n’empêche pas le parcours autonome pertinent.
5. Distinguer « état de départ » fonctionnel et diagnostic médical ; ne pas employer le diagnostic automatique de la source générale pour la santé.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Entrée minimale puis une donnée manquante ciblée ; choix Plus tard.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Autorisation de lecture d’une donnée du carnet et refus ; vérifier le parcours manuel de secours.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Aucune lecture avant consentement/politique d’accès vérifiée.
- Absence, obsolescence, contradiction et retrait d’autorisation gérés explicitement.
- Même jeu de préférences réutilisé sans questionnaire dupliqué.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
