# P013 — Calendrier commun et occurrences planifiées

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P013**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Raccorder les occurrences acceptées au calendrier déjà présent.

## Dépendances

- [P011 — Prévisualiser le programme, sa charge et les conflits](P011_apercu_programme.md) ; vérifier sa recette réelle.
- [P012 — Projet Dashboard : activités du jour et suivi](P012_dashboard_projet.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 30](../../specifications/sections/30.md) — lignes source 1044–1064.
- [Section 41](../../specifications/sections/41.md) — lignes source 1312–1328.
- [Section 50.4](../../specifications/sections/50_4.md) — lignes source 1604–1632.
- [Section 50.11](../../specifications/sections/50_11.md) — lignes source 1758–1767.
- [Section 51.23](../../specifications/sections/51_23.md) — lignes source 2291–2301.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Créer ou lier des occurrences avec date, durée, fuseau, rappel et récurrence après accord.
2. Utiliser la même mécanique pour sport, nutrition, complément, rendez-vous et bilan ; ne pas créer un agenda santé parallèle.
3. Distinguer planifié, reporté, annulé et effectué. La modification d’une récurrence future ne réécrit pas les événements passés.
4. Détecter les événements externes indisponibles et éviter toute promesse de réservation réelle sans connexion.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Prévisualisation de créneaux puis insertion acceptée dans le calendrier réel.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Report d’une occurrence et modification d’une série future ; les résultats passés restent visibles.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Horaires/fuseaux/changement d’heure et cas récurrent.
- Validation répétée et synchronisation sans doublons.
- Aucun événement extérieur créé avant choix explicite.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
