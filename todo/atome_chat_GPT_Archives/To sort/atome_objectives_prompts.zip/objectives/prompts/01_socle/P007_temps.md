# P007 — Curseur Temps et budget jour/semaine

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P007**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Construire un budget unique de temps réellement disponible.

## Dépendances

- [P004 — Carré extensible et réglage natif intégré](P004_carre_reglage.md) ; vérifier sa recette réelle.
- [P006 — Curseur Effort : cinq niveaux d’engagement](P006_effort.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 30](../../specifications/sections/30.md) — lignes source 1044–1064.
- [Section 51.3](../../specifications/sections/51_3.md) — lignes source 1836–1871.
- [Section 51.24](../../specifications/sections/51_24.md) — lignes source 2302–2331.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Demander la valeur initiale ; zéro permet de préparer sans planifier. Jour et semaine sont deux vues du même budget.
2. Permettre les jours réellement disponibles ; 20 min/j sur cinq jours donne 100 min/semaine, pas 140.
3. Utiliser les amplitudes UX 0–120 min/j et 0–840 min/semaine et pas de cinq minutes uniquement comme proposition révisable ; autoriser une saisie explicite au-delà.
4. Compter une séance partagée une seule fois. Séparer temps actif, repos occupant le créneau, préparation et trajet selon les choix utilisateur.
5. Si le programme dépasse le budget, proposer réduire ou reporter ; ne jamais imposer un dépassement ou des horaires supplémentaires.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Temps jour/semaine, conversion et jours choisis dans la matrice.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Budget de 90 minutes, dépassement et réduction proposée ; démontrer également zéro minute.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Conversions aller/retour sans dérive ni multiplication des jours erronée.
- Une occurrence commune à deux objectifs débite une seule fois.
- Gestion des créneaux, fuseaux et conflits sans écrasement silencieux.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
