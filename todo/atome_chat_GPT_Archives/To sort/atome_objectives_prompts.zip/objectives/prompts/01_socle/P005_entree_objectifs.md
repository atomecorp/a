# P005 — Présenter les treize objectifs et l’objectif libre

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P005**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Proposer la même entrée matricielle pour créer ou reprendre un projet-objectif.

## Dépendances

- [P003 — Matrice commune de carrés et navigation profonde](P003_matrice_navigation.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 6](../../specifications/sections/6.md) — lignes source 367–374.
- [Section 25](../../specifications/sections/25.md) — lignes source 879–901.
- [Section 33](../../specifications/sections/33.md) — lignes source 1107–1144.
- [Section 50.3](../../specifications/sections/50_3.md) — lignes source 1597–1603.
- [Section 51.1](../../specifications/sections/51_1.md) — lignes source 1796–1816.
- [Décision 52 du présent lot](../../specifications/sections/52.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Utiliser les treize intitulés OBJ-01 à OBJ-13 du catalogue actif ; conserver les neuf initiaux et les quatre ajouts, dont Esthétique.
2. Distinguer l’objectif Esthétique (visage, corps, peau et soins) du vieillissement en bonne santé ; les briques peuvent être partagées.
3. Prévoir l’expression libre d’un objectif avec le même moteur, sans inventer ses scénarios ni changer la liste initiale.
4. Reprendre un projet existant sans le recréer. Une entrée non encore disponible en développement ne doit pas simuler un parcours fonctionnel ; convenir de sa visibilité de prévisualisation.
5. Réserver le raccordement du choix social P022 immédiatement après le choix de l’objectif ; aucun partage à ce stade.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Matrice Projets et entrée Créer/Reprendre, puis choix des treize objectifs.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Entrée Esthétique et objectif libre ; vérifier les libellés, la cohérence et le retour.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Identifiants stables et treize objectifs distincts sans renommage de l’historique.
- Reprendre le même objectif ne duplique pas son programme.
- Aucune donnée médicale ni sociale rendue publique à la création.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
