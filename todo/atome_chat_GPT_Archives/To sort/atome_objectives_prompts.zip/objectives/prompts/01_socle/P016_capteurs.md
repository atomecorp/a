# P016 — Capteurs disponibles, permissions et suivi manuel

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P016**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Utiliser seulement les données réellement accessibles et autorisées.

## Dépendances

- [P015 — Moteur commun d’exécution des activités](P015_execution.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](P008_collecte_progressive.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.9](../../specifications/sections/50_9.md) — lignes source 1695–1731.
- [Section 51.4](../../specifications/sections/51_4.md) — lignes source 1872–1891.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Inventorier les capteurs et intégrations installés sur chaque plateforme ; distinguer téléphone, montre et équipement externe.
2. Montrer source, autorisation, disponibilité et type de mesure. Ne pas compter plusieurs représentations du même capteur comme plusieurs mesures indépendantes.
3. Activer les capteurs pertinents au démarrage effectif autorisé ; interrompre ou libérer ce qui est propre à la session à son arrêt.
4. En absence de capteur ou autorisation, proposer déclaration manuelle ou laisser la valeur absente.
5. Ne pas inférer stades de sommeil, longueurs, charges ou fréquence cardiaque sans une source adaptée vérifiée.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Choix des sources réellement disponibles et refus d’une permission.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Activité identique avec puis sans capteur ; provenance visible dans les résultats.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Capteur absent, perte de connexion, refus et retrait de permission.
- Pas de doublon de source ni de données fictives en fallback.
- Collecte bornée dans le temps, cycle de vie et consommation mesurés.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
