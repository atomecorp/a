# P010 — Composer et valider les briques une par une

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P010**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Permettre d’accepter, modifier, refuser ou reporter chaque brique.

## Dépendances

- [P009 — Panneau Activités : bibliothèque commune de briques](P009_activites.md) ; vérifier sa recette réelle.
- [P006 — Curseur Effort : cinq niveaux d’engagement](P006_effort.md) ; vérifier sa recette réelle.
- [P007 — Curseur Temps et budget jour/semaine](P007_temps.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](P008_collecte_progressive.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 5](../../specifications/sections/5.md) — lignes source 326–366.
- [Section 26](../../specifications/sections/26.md) — lignes source 902–939.
- [Section 36](../../specifications/sections/36.md) — lignes source 1201–1225.
- [Section 50.4](../../specifications/sections/50_4.md) — lignes source 1604–1632.
- [Section 51.2](../../specifications/sections/51_2.md) — lignes source 1817–1835.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Proposer peu de briques pertinentes ; expliquer à la demande intérêt, temps et prérequis sans remplir la grille de texte.
2. Chaque choix ouvre l’activité et ses contrôles natifs. Nutrition, sport, complément, rendez-vous, capteur et partage restent indépendamment facultatifs.
3. Conserver un brouillon tant que la personne n’a pas validé le programme ; aucun rendez-vous, publication ou rappel activé par simple consultation.
4. Refuser une brique ne la réintroduit pas sous un autre nom. Proposer une alternative pertinente ou accepter un programme réduit.
5. Référencer les sources des suggestions et leur statut éditorial ; les contenus de santé non validés ne deviennent pas des recommandations personnalisées.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Composition de deux briques avec les quatre décisions, dont une refusée.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Modification des paramètres dans l’outil réel puis reprise du brouillon sans perte.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Aucun effet de bord avant validation du programme.
- Refus nutrition/sport respecté lors de recalcul.
- Idempotence des validations et absence de duplication de briques.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
