# P003 — Matrice commune de carrés et navigation profonde

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P003**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Réutiliser la matrice d’atome comme structure des projets, objectifs et activités.

## Dépendances

- [P001 — Inventorier les références et les composants réels](P001_audit_existant.md) ; vérifier sa recette réelle.
- [P002 — Raccorder les objets, les identifiants et l’historique](P002_contrats_et_migrations.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.1](../../specifications/sections/50_1.md) — lignes source 1567–1574.
- [Section 50.3](../../specifications/sections/50_3.md) — lignes source 1597–1603.
- [Section 51.2](../../specifications/sections/51_2.md) — lignes source 1817–1835.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Réutiliser le moteur et le style de matrice existants : carrés, proportions, teintes, espacements, icônes et focus.
2. Raccorder un carré à son objet réel ; ouvrir une matrice fille et revenir au parent en conservant sélection, position et choix.
3. Adapter le nombre de colonnes à l’espace disponible sans transformer la grille en cartes rectangulaires arbitraires.
4. Conserver les autres modes spécialisés déjà prévus ; ce chantier unifie la sélection/configuration, pas le rendu de tous les médias.
5. Conserver les règles de niveau d’expertise existantes ; le moteur supporte la profondeur, mais ne force pas l’affichage d’un arbre expert en mode débutant.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Matrice racine avec vrais carrés et navigation parent/fille sur l’écran de référence.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Même navigation sur petit écran et en rotation ; retour avec état conservé.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Navigation tactile, souris, clavier et lecteur d’écran selon plateforme.
- Retour/reprise/rechargement sans doublon ni perte de contexte.
- Absence de chevauchement, recadrage parasite et rétrécissement inattendu.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
