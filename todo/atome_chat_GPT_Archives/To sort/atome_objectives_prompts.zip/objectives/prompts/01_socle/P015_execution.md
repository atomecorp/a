# P015 — Moteur commun d’exécution des activités

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P015**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Faire avancer une séance ou une routine par étapes enregistrées.

## Dépendances

- [P002 — Raccorder les objets, les identifiants et l’historique](P002_contrats_et_migrations.md) ; vérifier sa recette réelle.
- [P009 — Panneau Activités : bibliothèque commune de briques](P009_activites.md) ; vérifier sa recette réelle.
- [P012 — Projet Dashboard : activités du jour et suivi](P012_dashboard_projet.md) ; vérifier sa recette réelle.
- [P014 — Alarmes et ouverture du bon contexte](P014_alarmes.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.9](../../specifications/sections/50_9.md) — lignes source 1695–1731.
- [Section 51.20](../../specifications/sections/51_20.md) — lignes source 2124–2234.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Construire le déroulement préparée/démarrée/pause/reprise/étape validée/terminée/interrompue sur les objets réels.
2. Un appui sur la commande principale enregistre l’étape courante puis affiche la suivante. Utiliser une zone tactile accessible, sans interception arbitraire de tout l’écran.
3. Prévoir corriger, annuler le dernier appui, passer et arrêter ; protéger contre double-appui et contre validation accidentelle.
4. Une fin de chronomètre ne prouve pas une série, longueur ou posture accomplie ; distinguer passage prévu et confirmation effective.
5. Faire persister chaque étape de manière robuste et conserver valeurs prévues/réalisées séparées.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Activité de trois étapes : démarrer, valider une étape, voir la suivante.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Pause/reprise, correction d’une étape et interruption ; montrer le bilan réel obtenu.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Double clic/appui, reprise après interruption et sauvegarde d’étape.
- Aucune mesure inventée ou unité uniforme imposée.
- Arrêt de collecte au terme de l’activité lorsque la session l’a ouverte.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
