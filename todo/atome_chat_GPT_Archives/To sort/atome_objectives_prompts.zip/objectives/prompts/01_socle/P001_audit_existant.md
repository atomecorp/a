# P001 — Inventorier les références et les composants réels

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P001**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Obtenir la carte vérifiée de ce qui existe avant toute proposition d’interface.

## Dépendances

Aucune : première tâche.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 0](../../specifications/sections/0.md) — lignes source 3–18.
- [Section 46](../../specifications/sections/46.md) — lignes source 1483–1494.
- [Section 49](../../specifications/sections/49.md) — lignes source 1535–1562.
- [Section 50.1](../../specifications/sections/50_1.md) — lignes source 1567–1574.
- [Section 50.6](../../specifications/sections/50_6.md) — lignes source 1642–1649.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Lire les consignes du dépôt réellement ouvert, son architecture, ses tests et les références visuelles présentes ; relever branche et commit de départ. Ne pas supposer que les souvenirs de technologies du projet décrivent encore son état.
2. Repérer les vrais outils matrice, curseur, projet, Dashboard, Finder, calendrier, alarmes, contacts, communication, capteurs, stockage et Moniteur. Pour chaque composant : fichier, symbole, comportement observé, test reproductible, capacité absente ou incertaine.
3. Associer chaque BR-* du catalogue aux composants existants : réutilisation, adaptation, besoin nouveau. Les identifiants du cahier sont des identifiants de spécification, jamais des API inventées.
4. Choisir avec Jeezs l’écran de référence, les dimensions de cellule et les plateformes de démonstration. Pour iOS, privilégier l’iPad disponible ; examiner WebDriverAgent seulement si réellement configuré.
5. Préparer un environnement de prévisualisation isolé et réversible sans modifier le produit actif. Documenter les accès manquants sans chercher ou exposer de secrets.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Afficher les écrans actuels Projets, Activités s’il existe, matrice et options natives, sans les redessiner. Jeezs confirme les références de départ.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Présenter la structure proposée par assemblage des composants identifiés, avec leurs emplacements et options ; si une référence essentielle manque, arrêter avant de fabriquer une maquette.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Reproduire un démarrage de la version de base ; relever les échecs déjà présents.
- Vérifier les chemins/symboles et une utilisation réelle de chaque composant cité.
- Documenter précisément les plateformes et outils de test accessibles.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Aucun nouveau panneau, refonte, installation de dépendance, migration, backend ou déploiement. Une illustration inventée ne remplace pas un composant introuvable.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
