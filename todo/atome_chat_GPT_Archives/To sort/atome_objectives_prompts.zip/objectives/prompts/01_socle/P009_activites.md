# P009 — Panneau Activités : bibliothèque commune de briques

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P009**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Accéder directement aux vraies activités hors de tout programme.

## Dépendances

- [P003 — Matrice commune de carrés et navigation profonde](P003_matrice_navigation.md) ; vérifier sa recette réelle.
- [P004 — Carré extensible et réglage natif intégré](P004_carre_reglage.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](P008_collecte_progressive.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.5](../../specifications/sections/50_5.md) — lignes source 1633–1641.
- [Section 50.6](../../specifications/sections/50_6.md) — lignes source 1642–1649.
- [Section 51.4](../../specifications/sections/51_4.md) — lignes source 1872–1891.
- [Section 51.20](../../specifications/sections/51_20.md) — lignes source 2124–2234.
- [Décision 52 du présent lot](../../specifications/sections/52.md).
- [Décision 53 du présent lot](../../specifications/sections/53.md).
- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Assembler le panneau Activités à partir de la matrice et des modules réels. Domaines : Nutrition, Sport, Sommeil, Calme, Vie personnelle, Compléments, Examens/Résultats, Esthétique et accès au carnet.
2. Chaque catégorie descend vers ses briques puis paramètres ; ne pas remplacer une activité par une simple icône décorative.
3. Utiliser les mêmes références de briques en activité libre et en programme. Rattacher après coup une réalisation à un objectif sans la recopier.
4. Différencier catégorie de navigation, outil réel et données de configuration. Ne montrer que ce qui est réellement implémenté dans le produit actif.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Panneau Activités et catégories dans la matrice, en reprenant les composants de référence.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Accès libre à une activité puis même activité depuis un objectif ; options natives identiques.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Un même ID de brique et mêmes paramètres entre les deux accès.
- Retour à Activités sans recréation de programme ni perte du suivi.
- Catégorie vide/non installée honnêtement gérée.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
