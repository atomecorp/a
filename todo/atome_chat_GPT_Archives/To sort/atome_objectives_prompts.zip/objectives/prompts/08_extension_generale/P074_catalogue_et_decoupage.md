# P074 — Préserver le catalogue historique et créer les prochaines tâches

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P074**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Conserver toute l’ambition du cahier initial sans présenter des centaines de scénarios comme déjà réalisés.

## Dépendances

- [P068 — Objectif libre, sous-objectifs et parcours composables](P068_objectif_libre.md) ; vérifier sa recette réelle.
- [P069 — Scénario historique : créer un album](P069_scenario_album.md) ; vérifier sa recette réelle.
- [P070 — Scénario historique : réaliser un film](P070_scenario_film.md) ; vérifier sa recette réelle.
- [P071 — Scénario historique : entreprise, équipe et financement](P071_entreprise_financement.md) ; vérifier sa recette réelle.
- [P072 — Scénario historique : organiser une randonnée](P072_scenario_randonnee.md) ; vérifier sa recette réelle.
- [P073 — Scénario historique : objectif marathon](P073_scenario_marathon.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 6](../../specifications/sections/6.md) — lignes source 367–374.
- [Section 7](../../specifications/sections/7.md) — lignes source 375–421.
- [Section 8](../../specifications/sections/8.md) — lignes source 422–456.
- [Section 9](../../specifications/sections/9.md) — lignes source 457–481.
- [Section 10](../../specifications/sections/10.md) — lignes source 482–506.
- [Section 11](../../specifications/sections/11.md) — lignes source 507–536.
- [Section 12](../../specifications/sections/12.md) — lignes source 537–576.
- [Section 13](../../specifications/sections/13.md) — lignes source 577–603.
- [Section 14](../../specifications/sections/14.md) — lignes source 604–633.
- [Section 15](../../specifications/sections/15.md) — lignes source 634–664.
- [Section 16](../../specifications/sections/16.md) — lignes source 665–689.
- [Section 17](../../specifications/sections/17.md) — lignes source 690–714.
- [Section 18](../../specifications/sections/18.md) — lignes source 715–739.
- [Section 19](../../specifications/sections/19.md) — lignes source 740–764.
- [Section 20](../../specifications/sections/20.md) — lignes source 765–783.
- [Section 21](../../specifications/sections/21.md) — lignes source 784–808.
- [Section 22](../../specifications/sections/22.md) — lignes source 809–833.
- [Section 23](../../specifications/sections/23.md) — lignes source 834–858.
- [Section 24](../../specifications/sections/24.md) — lignes source 859–878.
- [Section 25](../../specifications/sections/25.md) — lignes source 879–901.
- [Section 43](../../specifications/sections/43.md) — lignes source 1358–1386.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Relire le catalogue historique complet dans les spécifications ; classer musique, vidéo, graphisme, écriture, logiciel, entreprise, financement, carrière, voyage, relations, maison, science, éducation et engagement.
2. Associer chaque entrée à une famille existante et à un statut : modèle disponible, données à compléter, brique manquante, scénario à spécifier. Aucune entrée source ne disparaît silencieusement.
3. Pour chaque nouvel objectif choisi, rédiger un prompt petit et autonome avec dépendances, écrans, tests, sources et exclusions selon le gabarit.
4. Soumettre le nouveau découpage avant exécution : le master ne s’autorise pas à fabriquer puis exécuter toute une feuille de route sans validation.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Présenter le classement du catalogue dans les matrices existantes, sans fausses disponibilités.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Présenter le parcours d’un seul objectif nouvellement choisi ; attendre l’accord sur le découpage avant code.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Toutes les sections historiques 6–25 restent traçables.
- Aucune tâche nouvelle lancée sans acceptation du périmètre.
- Une capacité non disponible ne se transforme pas en bouton de simulation.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
