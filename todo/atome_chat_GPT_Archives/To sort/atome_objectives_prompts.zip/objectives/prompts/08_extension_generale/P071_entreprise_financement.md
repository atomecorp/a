# P071 — Scénario historique : entreprise, équipe et financement

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P071**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Conserver les parcours entreprise et financement sans automatiser des décisions financières.

## Dépendances

- [P068 — Objectif libre, sous-objectifs et parcours composables](P068_objectif_libre.md) ; vérifier sa recette réelle.
- [P024 — Échanger et organiser une activité commune](../03_reseau/P024_echanges_activites.md) ; vérifier sa recette réelle.
- [P013 — Calendrier commun et occurrences planifiées](../01_socle/P013_calendrier.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 12](../../specifications/sections/12.md) — lignes source 537–576.
- [Section 13](../../specifications/sections/13.md) — lignes source 577–603.
- [Section 27](../../specifications/sections/27.md) — lignes source 940–978.
- [Section 28](../../specifications/sections/28.md) — lignes source 979–1017.
- [Section 43](../../specifications/sections/43.md) — lignes source 1358–1386.
- [Section 45](../../specifications/sections/45.md) — lignes source 1414–1482.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Assembler définition d’activité, ressources, équipe, jalons et financement selon besoins exprimés.
2. Budget estimé, dépense réelle, financement recherché et obtenu sont des états distincts ; aucune donnée bancaire inventée.
3. Réutiliser outils de contacts/fichiers/conditions existants ; confirmer tout contact externe, paiement, publication ou dépôt.
4. La validation d’une maquette de parcours ne constitue pas l’autorisation d’une transaction ou démarche légale.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Matrice d’objectif entreprise puis brique de financement, séparément validées.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Ressource ou contact manquant, plan corrigé et preuve de réalisation.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Test Entreprise du cahier et branche manque de financement.
- Totaux budgétaires vérifiables, montants absents non assimilés à zéro.
- Zéro transaction, envoi ou engagement externe implicite.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
