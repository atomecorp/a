# P068 — Objectif libre, sous-objectifs et parcours composables

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P068**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Traiter un but non prévu sans retourner à une application de gestion générique.

## Dépendances

- [P010 — Composer et valider les briques une par une](../01_socle/P010_composition.md) ; vérifier sa recette réelle.
- [P021 — Adapter, suspendre et reprendre un programme](../02_resultats/P021_adaptation.md) ; vérifier sa recette réelle.
- [P022 — Proposer la mise en relation au début de chaque objectif](../03_reseau/P022_option_initiale.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 2](../../specifications/sections/2.md) — lignes source 91–130.
- [Section 4](../../specifications/sections/4.md) — lignes source 212–325.
- [Section 5](../../specifications/sections/5.md) — lignes source 326–366.
- [Section 25](../../specifications/sections/25.md) — lignes source 879–901.
- [Section 26](../../specifications/sections/26.md) — lignes source 902–939.
- [Section 36](../../specifications/sections/36.md) — lignes source 1201–1225.
- [Section 39](../../specifications/sections/39.md) — lignes source 1266–1286.
- [Section 40](../../specifications/sections/40.md) — lignes source 1287–1311.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Exprimer un but libre, critères de réussite et ressources ; construire un graphe d’étapes avec dépendances, options, branches et maintien.
2. Réutiliser les vraies briques disponibles, sous-objectifs et outils ; toute capacité absente constitue une tâche séparée à faire approuver.
3. Préserver décision humaine, budget, dates, preuves et historique ; automatisation à niveau défini sans achat/envoi/partage silencieux.
4. Présenter le parcours dans les mêmes matrices, incluant l’option de contact par objectif.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Créer un objectif non répertorié et montrer sa composition réelle.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Changer une branche, suspendre/reprendre et montrer ses preuves de réussite.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Objectif non prévu crée un parcours valable sans code spécifique à son nom.
- Pas de boucle de dépendance ni sous-objectif inaccessible.
- Étapes alternatives, non applicables et maintien correctement représentés.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
