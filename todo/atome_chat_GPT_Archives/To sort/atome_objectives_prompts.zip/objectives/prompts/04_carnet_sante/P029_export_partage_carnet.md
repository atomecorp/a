# P029 — Exporter et partager une sélection du carnet

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P029**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Rendre le carnet portable tout en limitant chaque transmission.

## Dépendances

- [P028 — Consultations, examens, ordonnances et suivis](P028_parcours_soins.md) ; vérifier sa recette réelle.
- [P019 — Évolutions comparables et export CSV](../02_resultats/P019_evolutions_csv.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Décision 54 du présent lot](../../specifications/sections/54.md).
- [Décision 53 du présent lot](../../specifications/sections/53.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Réutiliser l’export natif ; inclure sélection structurée, provenance, unités et originaux associés. Le CSV ne porte que les séries tabulaires.
2. Proposer sélection de rubriques/périodes/documents et destinataire réel, puis aperçu exact avant transmission.
3. Gérer accès professionnel, proche et éventuel accès temporaire selon capacités vérifiées ; l’expiration d’un lien ne rappelle pas les copies déjà reçues.
4. Aucun partage du carnet vers le réseau d’objectifs par défaut. Autoriser distinctement lecture par Moniteur/IA et transmission externe.
5. Ne produire un document PDF de synthèse que via les capacités existantes confirmées, en conservant auteur et limites ; pas d’imitation d’une ordonnance officielle.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Choisir ce qui est exporté, aperçu et résultat réel ouvrable.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Sélection/destinataire/confirmation, puis retrait d’un accès partagé côté autre compte.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Export complet des pièces sélectionnées et aucun document non autorisé.
- Contrôles de droits à chaque lecture ; pas uniquement un masquage UI.
- Réimport ou restauration d’un paquet de test sans perte d’unité, d’auteur ni d’original.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
