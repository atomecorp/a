# P026 — Créer le carnet de santé transversal

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P026**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Créer un carnet durable indépendant des objectifs, et non un journal de plus.

## Dépendances

- [P009 — Panneau Activités : bibliothèque commune de briques](../01_socle/P009_activites.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](../01_socle/P008_collecte_progressive.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Assembler dans la matrice les modules d’identité médicale, allergies/antécédents, traitements/vaccinations, consultations, examens, résultats et documents selon leur disponibilité réelle.
2. Un seul carnet par personne concernée, avec identité explicite. Un objectif fermé ou supprimé ne supprime pas le carnet par effet de cascade.
3. Réutiliser Résultats et documents, calendrier, contacts, permissions et historique ; le carnet est leur vue de santé organisée, pas une seconde base divergente.
4. Prévoir un accès direct et depuis chaque objectif, sans imposer sa consultation complète à un scénario.
5. Intitulé produit : « Carnet de santé ». Le statut officiel est une ambition à qualifier dans P030 ; aucun badge officiel, certifié ou synchronisé non prouvé.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Matrice du carnet et accès direct, sans panneaux de dossier médical génériques.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Accès au même résultat depuis le carnet et deux objectifs, avec retour au contexte d’origine.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Isolation entre personnes, contrôle d’accès par entrée et même ID de résultat.
- Suppression d’un objectif conserve les données du carnet sauf décision distincte.
- Refus d’accès au carnet n’empêche pas l’objectif autonome.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
