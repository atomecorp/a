# P030 — Qualifier le statut officiel et les raccordements santé

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P030**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Traiter explicitement l’ambition de carnet officiel sans inventer un agrément.

## Dépendances

- [P026 — Créer le carnet de santé transversal](P026_carnet_transversal.md) ; vérifier sa recette réelle.
- [P029 — Exporter et partager une sélection du carnet](P029_export_partage_carnet.md) ; vérifier sa recette réelle.
- [P001 — Inventorier les références et les composants réels](../01_socle/P001_audit_existant.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Décision 54 du présent lot](../../specifications/sections/54.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Établir une note de qualification avec sources institutionnelles actuelles : finalité revendiquée, statut du carnet local, obligations applicables, responsabilités et territoires.
2. Examiner Mon espace santé/DMP seulement par leurs procédures et interfaces réellement autorisées : éligibilité, référencement, accès, consentement, identités et interopérabilité. Une présence au catalogue ne certifie pas tous les conseils médicaux.
3. Auditer les exigences d’hébergement, sécurité, traçabilité, droits et éventuelle qualification de dispositif médical ; ne pas les déclarer satisfaites par simple écriture de ce prompt.
4. Faire valider un sous-lot d’intégration externe séparé avant installation, connexion ou échange réel. Prévoir un fonctionnement local/export lorsque ce raccordement n’est pas accessible.
5. Présenter honnêtement les états de disponibilité ; un bouton de connexion ne doit pas simuler une connexion à un service national.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Montrer dans le carnet le libellé et le statut proposés, sans badge officiel non justifié.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Après autorisation du sous-lot externe seulement : démontrer une vraie connexion ou l’état indisponible et le chemin export local.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Sources datées, exigences et preuves distinguées ; revue juridique/clinique humaine identifiée.
- Aucune API, homologation ou garantie de chiffrement inventée.
- Pas d’échange réel avant autorisations, accès technique et conformité qualifiée.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Cette tâche livre d’abord un audit et une décision de raccordement. Elle n’accorde ni habilitation, ni référencement, ni statut officiel ; les demandes et validations externes restent explicitement bloquantes pour ces allégations.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
