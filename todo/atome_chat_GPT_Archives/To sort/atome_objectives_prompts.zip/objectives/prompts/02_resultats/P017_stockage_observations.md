# P017 — Stockage commun des observations et originaux

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P017**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Conserver durablement les réalisations et résultats de toute nature.

## Dépendances

- [P002 — Raccorder les objets, les identifiants et l’historique](../01_socle/P002_contrats_et_migrations.md) ; vérifier sa recette réelle.
- [P015 — Moteur commun d’exécution des activités](../01_socle/P015_execution.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 29](../../specifications/sections/29.md) — lignes source 1018–1043.
- [Section 38](../../specifications/sections/38.md) — lignes source 1245–1265.
- [Section 50.10](../../specifications/sections/50_10.md) — lignes source 1732–1757.
- [Section 51.23](../../specifications/sections/51_23.md) — lignes source 2291–2301.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Raccorder les observations sportives, qualitatives et médicales au stockage existant, avec unités/types/provenance.
2. Préserver originaux, valeur source, correction et versions ; les historiques ne sont pas remplacés par la dernière valeur.
3. Lier facultativement un résultat à une occurrence, un document ou plusieurs objectifs sans duplication.
4. Gérer sauvegarde, erreurs d’écriture et contrôle d’accès ; aucun stockage en clair ajouté sans revue des garanties réelles.
5. Concevoir pour la conservation durable et la portabilité, tout en prévoyant les droits de suppression et les obligations éventuelles à qualifier.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Résultat de séance, observation qualitative et document dans la surface existante des résultats.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Une correction historisée et le même résultat lié à deux objectifs.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Persistance après fermeture/reprise et erreur réseau.
- Lecture refusée pour un autre compte sans autorisation.
- Valeur absente, zéro, texte et pièce jointe correctement distingués.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
