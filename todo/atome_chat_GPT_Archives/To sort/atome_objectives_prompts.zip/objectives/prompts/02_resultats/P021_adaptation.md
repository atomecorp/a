# P021 — Adapter, suspendre et reprendre un programme

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P021**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Faire évoluer le programme sans effacer son histoire ni augmenter l’effort en silence.

## Dépendances

- [P020 — Moniteur commun : bilan et provenance](P020_moniteur.md) ; vérifier sa recette réelle.
- [P011 — Prévisualiser le programme, sa charge et les conflits](../01_socle/P011_apercu_programme.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 35](../../specifications/sections/35.md) — lignes source 1176–1200.
- [Section 37](../../specifications/sections/37.md) — lignes source 1226–1244.
- [Section 38](../../specifications/sections/38.md) — lignes source 1245–1265.
- [Section 39](../../specifications/sections/39.md) — lignes source 1266–1286.
- [Section 40](../../specifications/sections/40.md) — lignes source 1287–1311.
- [Section 51.3](../../specifications/sections/51_3.md) — lignes source 1836–1871.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Proposer maintenir, alléger, déplacer, retirer ou progresser graduellement selon observations et choix utilisateur.
2. Prévisualiser les changements, leur coût en temps et leur portée future ; obtenir une validation explicite.
3. Versionner le programme et ses paramètres ; les valeurs déjà réalisées restent attribuées à la version correspondante.
4. Permettre pause/reprise, abandon sans culpabilisation, objectif atteint et maintien facultatif.
5. Une préférence « plus vite » n’autorise pas suppression de repos, dose augmentée ou restriction plus forte.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Proposition d’allègement après séance difficile, comparée au programme actif.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Pause, reprise et historique des versions ; vérifier le calendrier futur.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Refus de proposition conserve le programme actuel.
- Modifications futures n’altèrent pas les résultats passés.
- Reprise ne relance pas les rappels anciens et ne duplique pas les séances.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
