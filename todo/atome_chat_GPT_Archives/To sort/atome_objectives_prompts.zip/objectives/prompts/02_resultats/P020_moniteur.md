# P020 — Moniteur commun : bilan et provenance

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P020**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Présenter les progrès et incertitudes sans diagnostic ni bénéfice fictif.

## Dépendances

- [P019 — Évolutions comparables et export CSV](P019_evolutions_csv.md) ; vérifier sa recette réelle.
- [P012 — Projet Dashboard : activités du jour et suivi](../01_socle/P012_dashboard_projet.md) ; vérifier sa recette réelle.
- [P016 — Capteurs disponibles, permissions et suivi manuel](../01_socle/P016_capteurs.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 35](../../specifications/sections/35.md) — lignes source 1176–1200.
- [Section 37](../../specifications/sections/37.md) — lignes source 1226–1244.
- [Section 50.6](../../specifications/sections/50_6.md) — lignes source 1642–1649.
- [Section 51.2](../../specifications/sections/51_2.md) — lignes source 1817–1835.
- [Section 51.25](../../specifications/sections/51_25.md) — lignes source 2332–2355.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Assembler le Moniteur existant avec les observations autorisées ; séparer réalisé, déclaré, mesuré et interprété.
2. Présenter durée, régularité, ressenti et résultats par objectif, en tenant compte des données manquantes.
3. Une séance partagée reste unique ; chaque objectif garde ses critères propres. Une association temporelle n’est pas une causalité.
4. Proposer bilan et accès aux sources ; aucune analyse automatique du journal intime ni publication sociale.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Bilan d’un objectif avec activité réalisée et données manquantes, sans score médical arbitraire.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Bilan multi-objectifs et retour à la source d’un résultat autorisé.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Autorisations par donnée et retrait immédiat d’accès.
- Aucun compte double ni progrès inventé à partir d’un simple rappel.
- Contradictions et mesures non comparables explicites.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
