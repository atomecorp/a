# P019 — Évolutions comparables et export CSV

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P019**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Retrouver les évolutions et exporter les données structurables sans destruction.

## Dépendances

- [P017 — Stockage commun des observations et originaux](P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P018 — Importer un résultat et vérifier l’extraction](P018_import_resultats.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.10](../../specifications/sections/50_10.md) — lignes source 1732–1757.
- [Section 51.23](../../specifications/sections/51_23.md) — lignes source 2291–2301.
- [Section 51.27](../../specifications/sections/51_27.md) — lignes source 2374–2398.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Comparer seulement des valeurs compatibles en type, unité, méthode et contexte ; conserver une rupture de série lorsqu’elles ne le sont pas.
2. Réutiliser l’outil de représentation existant ; l’historique sportif ou médical ne doit pas être un tableau générique permanent.
3. Exporter en CSV les valeurs tabulaires avec identifiants, dates, unités, provenance et références vers les originaux ; garder un paquet structuré pour métadonnées et pièces jointes.
4. Prévenir les injections de formules à l’export tableur, préserver encodage, décimales et dates sans conversion ambiguë.
5. Conserver la valeur source après harmonisation ; montrer explicitement toute valeur calculée.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Deux observations comparables puis deux incompatibles : évolution correcte ou comparaison suspendue.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Choix d’export, aperçu des données incluses et fichier obtenu réellement ouvrable.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Aller/retour CSV UTF-8, virgules, guillemets, unités et valeurs nulles.
- Valeurs calculées vérifiables sans réécrire le source.
- Exports non tabulaires gardent leurs originaux ; absence de fuite d’autres résultats.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
