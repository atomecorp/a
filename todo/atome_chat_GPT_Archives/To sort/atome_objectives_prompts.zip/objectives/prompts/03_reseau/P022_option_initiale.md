# P022 — Proposer la mise en relation au début de chaque objectif

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P022**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Proposer un réseau entre personnes partageant un objectif, sans rendre ce choix obligatoire.

## Dépendances

- [P005 — Présenter les treize objectifs et l’objectif libre](../01_socle/P005_entree_objectifs.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](../01_socle/P008_collecte_progressive.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 27](../../specifications/sections/27.md) — lignes source 940–978.
- [Section 51.2](../../specifications/sections/51_2.md) — lignes source 1817–1835.
- [Décision 53 du présent lot](../../specifications/sections/53.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Après le choix ou lors de la reprise initiale d’un objectif, présenter une brique optionnelle portant la question « Souhaitez-vous être en contact avec des personnes qui partagent le même objectif que vous ? ». Ne pas interrompre une orientation urgente pour la proposer.
2. Choix explicites Oui, Non, Plus tard, sans Oui précoché ; le programme reste utilisable en solo. Mémoriser la décision par objectif et permettre sa modification ultérieure.
3. Un Oui ouvre les choix de visibilité et de recherche : ce n’est pas l’autorisation globale de diffuser un dossier, un nom d’objectif sensible ou un profil.
4. Dissocier recherche de partenaires, présence visible dans les résultats et contact accepté. Ne pas réutiliser des données de santé, d’humeur, de corps ou du carnet pour un classement caché.
5. Utiliser les vrais outils de contacts/communication vérifiés ; aucun fil de publications, « likes » ou mur social conventionnel ajouté pour meubler cette brique.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Question optionnelle dans la matrice de démarrage ; chemin Non/Plus tard vers le programme.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Chemin Oui : choix limités de visibilité et possibilité de revenir en mode solo.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Tester Oui/Non/Plus tard sur chacun des treize objectifs et un objectif libre.
- Zéro indexation publique, contact envoyé ou publication avant autorisation correspondante.
- Retrait et changement d’objectif ne propagent pas le consentement à d’autres objectifs.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
