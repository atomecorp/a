# P023 — Trouver et demander un contact partageant l’objectif

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P023**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Relier des personnes consentantes sur un objectif déclaré compatible.

## Dépendances

- [P022 — Proposer la mise en relation au début de chaque objectif](P022_option_initiale.md) ; vérifier sa recette réelle.
- [P009 — Panneau Activités : bibliothèque commune de briques](../01_socle/P009_activites.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 27](../../specifications/sections/27.md) — lignes source 940–978.
- [Décision 53 du présent lot](../../specifications/sections/53.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Utiliser le service réel d’identité et de découverte ; si aucune capacité vérifiée n’existe, documenter un sous-lot backend à approuver avant développement.
2. Rechercher uniquement parmi les profils ayant accepté ce niveau de visibilité et sur les champs autorisés : objectif partageable, préférence d’activité, langue ou disponibilité choisie.
3. Afficher les contacts avec leur composant carré natif ; exclure l’utilisateur courant, les personnes bloquées et les profils non visibles.
4. Une demande de mise en relation requiert un acte explicite ; son acceptation réciproque conditionne la relation. Aucune localisation précise ou carnet de santé dévoilé.
5. Prévoir aucun résultat, demande en attente, refus, retrait et expiration. Ne pas fabriquer de personnes ou de messages pour une démonstration sans les marquer fictifs.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Matrice de personnes disponibles, périmètre de profil visible et état vide.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Demande explicite, réception côté second compte de test et acceptation/refus.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Deux comptes réels de test, visibilité contrôlée côté serveur et non seulement dans l’UI.
- Pas de résultat issu de données médicales cachées, ni de retour d’utilisateur bloqué.
- Idempotence des invitations et révocation effective.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
