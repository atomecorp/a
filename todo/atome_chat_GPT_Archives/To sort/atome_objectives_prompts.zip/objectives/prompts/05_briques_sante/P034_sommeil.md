# P034 — Briques Sommeil refaites et orientation appropriée

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P034**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Fournir les briques de sommeil fondées sur le besoin réel, sans activités aléatoires.

## Dépendances

- [P009 — Panneau Activités : bibliothèque commune de briques](../01_socle/P009_activites.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](../01_socle/P008_collecte_progressive.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P028 — Consultations, examens, ordonnances et suivis](../04_carnet_sante/P028_parcours_soins.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.8](../../specifications/sections/51_8.md) — lignes source 1940–1967.
- [Section 51.4](../../specifications/sections/51_4.md) — lignes source 1872–1891.
- [Section 51.5](../../specifications/sections/51_5.md) — lignes source 1892–1913.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Implémenter BR-SOM-01 à 06 : journal volontaire, régularité, lumière/rythme contextualisés, environnement/rituel, stimulants/horaires, orientation vers évaluation ou TCC-I.
2. Distinguer manque de temps de sommeil, décalage de rythme, difficultés persistantes et demande de confort ; ne pas demander à l’utilisateur de poser un diagnostic.
3. Ne pas imposer natation, régime, mélatonine ou appareil connecté. Ne pas certifier les stades de sommeil issus de montres.
4. La prise en charge d’une insomnie chronique et les techniques thérapeutiques telles que restriction du temps au lit requièrent un parcours professionnel revu ; pas de calcul automatique dans cette tâche.
5. Conserver fonctionnement diurne, tolérance et observations utiles ; ne pas ajouter de suivi qui dépasse le budget ou aggrave la préoccupation du sommeil.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Journal sommeil minimal et refus du suivi automatique ; valider cet écran avant le suivant.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Brique rythme/rituel choisie, réglages et aperçu d’activité.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V03 — proposition à montrer

Orientation clinique, rendez-vous et état sans capteur ; aucune prescription affichée.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Source autorisée et déclarée vs instrumentée distinguée.
- Refus sport/nutrition/compléments respecté.
- Travail posté ou contexte incompatible ne reçoit pas le même horaire matinal par défaut.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
