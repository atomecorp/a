# P037 — Douleur, symptômes et orientation vers les soins

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P037**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Organiser les observations et l’orientation sans diagnostiquer ni imposer des examens.

## Dépendances

- [P009 — Panneau Activités : bibliothèque commune de briques](../01_socle/P009_activites.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](../01_socle/P008_collecte_progressive.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P028 — Consultations, examens, ordonnances et suivis](../04_carnet_sante/P028_parcours_soins.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.10](../../specifications/sections/51_10.md) — lignes source 1982–1993.
- [Section 51.11](../../specifications/sections/51_11.md) — lignes source 1994–2005.
- [Section 51.23](../../specifications/sections/51_23.md) — lignes source 2291–2301.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Proposer une observation datée, localisation/retentissement/évolution selon ce que la personne souhaite renseigner.
2. Une échelle éventuelle est déclarative, source/version explicite ; absence de score n’égale pas absence de douleur.
3. Prévoir une orientation sur signes d’alerte revus par un professionnel, sans algorithme inventé de diagnostic ou de triage certifié.
4. Une activité potentiellement aggravante peut être suspendue sans fermer tout le projet ; conserver le chemin vers consultation et résultats.
5. Ne jamais programmer systématiquement une prise de sang ou modifier un traitement depuis une douleur.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Observation de symptôme ou douleur, source et inconnu.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Orientation et activité suspendue avec alternative, puis rendez-vous et compte rendu.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Pas de diagnostic affiché en résultat d’un score.
- Conservation du récit original et corrections.
- Demande urgente accessible sans exiger un questionnaire complet.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
