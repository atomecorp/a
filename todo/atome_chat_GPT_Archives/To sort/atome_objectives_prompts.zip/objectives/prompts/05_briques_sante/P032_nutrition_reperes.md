# P032 — Repères nutritionnels et cibles documentées

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P032**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Différencier information scientifique générale, cible consentie et prescription.

## Dépendances

- [P031 — Nutrition : habitudes, repas et préparation](P031_nutrition_repas.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.5](../../specifications/sections/51_5.md) — lignes source 1892–1913.
- [Section 51.7](../../specifications/sections/51_7.md) — lignes source 1922–1939.
- [Section 51.9](../../specifications/sections/51_9.md) — lignes source 1968–1981.
- [Section 51.21](../../specifications/sections/51_21.md) — lignes source 2235–2264.
- [Section 51.22](../../specifications/sections/51_22.md) — lignes source 2265–2290.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Classer chaque valeur : exemple UX, donnée de test, repère de population, valeur utilisateur ou consigne professionnelle. Conserver source/date/population/limites.
2. Prévoir qualité/variété, protéines, fibres, énergie suffisante et hydratation via les BR-NUT-* existantes ; ne pas créer une dose personnalisée depuis un poids supposé.
3. Une cible chiffrée est facultative et justifiée ; restrictions, pathologies, grossesse, fragilité ou troubles alimentaires nécessitent les règles spécifiques revues.
4. La validation médicale des conseils et seuils est indépendante des tests de code ; un repère non revu reste désactivé comme recommandation.
5. Les chiffres de la source sont conservés pour audit, pas injectés silencieusement comme valeurs par défaut.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Brique nutritionnelle sans cible numérique, puis cible déclarée avec source.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Information générale distinguée d’une consigne professionnelle et cas où aucune valeur n’est suggérée.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Aucune cible extrapolée depuis Effort 5 ou l’urgence souhaitée.
- Calculs dimensionnels et valeurs absentes.
- Rejet ou suspension d’une recommandation non applicable sans effacer la donnée déclarée.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
