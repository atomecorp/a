# P035 — Calme, émotions et soutien en santé mentale

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P035**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Proposer du soutien choisi et un accès humain adapté sans diagnostic automatisé.

## Dépendances

- [P009 — Panneau Activités : bibliothèque commune de briques](../01_socle/P009_activites.md) ; vérifier sa recette réelle.
- [P008 — Collecte minimale, préférences et autorisations](../01_socle/P008_collecte_progressive.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P028 — Consultations, examens, ordonnances et suivis](../04_carnet_sante/P028_parcours_soins.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.13](../../specifications/sections/51_13.md) — lignes source 2018–2029.
- [Section 51.17](../../specifications/sections/51_17.md) — lignes source 2077–2088.
- [Section 51.18](../../specifications/sections/51_18.md) — lignes source 2089–2102.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Assembler respiration confortable, relaxation, méditation facultative, pauses, ressenti volontaire et contact professionnel selon les BR-MEN-*.
2. Prévoir arrêt/passer à tout instant ; ne pas forcer une respiration, une méditation ou une exposition thérapeutique inadaptée.
3. Questionnaires éventuels seulement après vérification de leurs droits d’usage, version, limites et procédure d’interprétation ; pas de score prédictif de suicide.
4. Prévoir un accès discret et rapide à l’aide humaine pour détresse/urgence, ressources localisées et revues à la mise en service ; ne pas attendre l’agenda.
5. Ne jamais analyser le journal intime, modifier un psychotrope ou recruter des partenaires sur le ressenti sans permissions distinctes.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Choix d’une activité apaisante et commande arrêter/passer.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Ressenti facultatif et refus de saisie, puis soutien professionnel.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V03 — proposition à montrer

Chemin de demande d’aide urgente et liens réels vérifiés, sans écran médical fictif.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Refus de questionnaire conserve accès à l’aide.
- Aucune inférence de diagnostic sur texte privé ou montre.
- Ressources adaptées au territoire et connectivité absente gérées sans fausse prise en charge.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
