# P033 — Compléments : catalogue, saisie, dose et prises

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P033**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Suivre les compléments choisis sans automatiser une prescription.

## Dépendances

- [P031 — Nutrition : habitudes, repas et préparation](P031_nutrition_repas.md) ; vérifier sa recette réelle.
- [P013 — Calendrier commun et occurrences planifiées](../01_socle/P013_calendrier.md) ; vérifier sa recette réelle.
- [P017 — Stockage commun des observations et originaux](../02_resultats/P017_stockage_observations.md) ; vérifier sa recette réelle.
- [P028 — Consultations, examens, ordonnances et suivis](../04_carnet_sante/P028_parcours_soins.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 50.8](../../specifications/sections/50_8.md) — lignes source 1675–1694.
- [Section 50.11](../../specifications/sections/50_11.md) — lignes source 1758–1767.
- [Section 51.22](../../specifications/sections/51_22.md) — lignes source 2265–2290.

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Proposer un catalogue de produits réellement référencés et une saisie manuelle ; distinguer produit, formulation, concentration par unité et quantité prise.
2. Renseigner dose déclarée, unité, horaires, jours, fréquence, durée/période et source éventuelle. La quantité d’actif ne se déduit que d’une composition connue.
3. Suggestions facultatives et sourcées : statut distinct du produit enregistré. Ne pas imposer supplément, cure, achat ou augmentation de dose.
4. Lier les prises acceptées à l’agenda commun, avec prise déclarée, oubli, report et arrêt. Un rappel ignoré ne vaut ni prise ni dose à rattraper.
5. Relier rendez-vous de revue et résultats au carnet ; les risques/contre-indications nécessitent un contenu revu et une orientation professionnelle.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Choisir un produit et saisir manuellement un autre ; concentration et unité dans les carrés étendus.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Horaires, rappel ignoré et prise déclarée ; arrêt puis consultation des résultats dans le carnet.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- mg/µg/g/mL/unités de produit non confondus ; pas de conversion d’UI générique entre substances.
- Modification de formulation conserve la composition historique de chaque prise.
- Ni rattrapage automatique, ni prescription, ni achat silencieux.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas étendre le périmètre aux tâches voisines. Aucun déploiement, migration destructive, partage, envoi, achat ou raccordement externe implicite. Les données de démonstration sont fictives et identifiées.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
