# P057 — OBJ-03 — Prendre de la masse musculaire

**Statut initial : NON_COMMENCÉE.** Ce fichier est un prompt à donner à Codex, pas une attestation de développement.

## Instruction à Codex

Tu interviens dans **atome/eVe**. Exécute uniquement **P057**, au prochain jalon autorisé, et arrête-toi aux validations prévues. Lis [le fichier maître Objectif.md](../../Objectif.md) et [le contrat de validation](../../pilotage/Regles_validation.md) avant toute modification. Ne passe pas au prompt suivant de ta propre initiative.

## Résultat attendu

Une séance réellement exécutable avec alimentation et récupération facultativement associées.

## Dépendances

- [P012 — Projet Dashboard : activités du jour et suivi](../01_socle/P012_dashboard_projet.md) ; vérifier sa recette réelle.
- [P021 — Adapter, suspendre et reprendre un programme](../02_resultats/P021_adaptation.md) ; vérifier sa recette réelle.
- [P022 — Proposer la mise en relation au début de chaque objectif](../03_reseau/P022_option_initiale.md) ; vérifier sa recette réelle.
- [P026 — Créer le carnet de santé transversal](../04_carnet_sante/P026_carnet_transversal.md) ; vérifier sa recette réelle.
- [P032 — Repères nutritionnels et cibles documentées](../05_briques_sante/P032_nutrition_reperes.md) ; vérifier sa recette réelle.
- [P033 — Compléments : catalogue, saisie, dose et prises](../05_briques_sante/P033_complements.md) ; vérifier sa recette réelle.
- [P044 — Exécuter et enregistrer les séries au toucher](../06_sport/P044_series_interactives.md) ; vérifier sa recette réelle.

Une dépendance notée dans le plan mais non réellement intégrée/testée reste bloquante. Lorsqu’une capacité externe est indisponible, consigner son absence ; ne pas la remplacer par une simulation présentée comme fonctionnelle.

## Passages à lire

- [Section 51.9](../../specifications/sections/51_9.md) — lignes source 1968–1981.
- [Section 51.2](../../specifications/sections/51_2.md) — lignes source 1817–1835.
- [Section 51.3](../../specifications/sections/51_3.md) — lignes source 1836–1871.
- [Section 51.6](../../specifications/sections/51_6.md) — lignes source 1914–1921.
- [Décision 53 du présent lot](../../specifications/sections/53.md).
- [Décision 54 du présent lot](../../specifications/sections/54.md).
- [Scénario complet OBJ-03](../../specifications/scenarios/OBJ-03.md).

La version archivée peut contenir des choix historiques ; les décisions 52–55 et le maître prévalent. Les conseils de santé respectent [la politique des valeurs](../../pilotage/Politique_des_valeurs.md).

## Avant la proposition

Inspecte les vrais fichiers/composants et les captures disponibles. Décris brièvement l’assemblage concret : outils affichés, sélection, emplacement des options natives, données et connexions réellement utilisables. Réutilise le design, les proportions et la logique d’atome/eVe. Si une référence essentielle manque, pose une question ciblée et **STOP**. Aucun panneau, formulaire ou comportement générique n’est autorisé par défaut.

## Travail limité à cette tâche

1. Lire la fiche complète correspondante dans specifications/scenarios/OBJ-03.md ; elle contient le scénario source et ses conditions. Cette tâche assemble les briques déjà implémentées : ne pas créer un nouveau calendrier, Dashboard ou Moniteur.
2. Au début, offrir la mise en relation facultative P022. Puis état initial minimal, Effort, Temps, briques acceptées une par une et aperçu du programme ; préserver les refus.
3. Assembler Musculation, récupération et Nutrition suffisante selon ce qui est accepté ; charge initiale non présumée.
4. Permettre la machine personnelle, séries et paramètres propres à chaque exercice ; lier à l’agenda et au suivi.
5. Les protéines/compléments sont des options conditionnelles sourcées, pas un lot imposé ; priorité à la pertinence et au contexte.
6. Décrire pour chaque branche : ce que fait la personne, valeur/source utilisée, action réellement exécutée, résultat enregistré et décision suivante. Tout nouveau contenu visuel requiert sa validation.
7. Après acceptation : agenda → ouverture autorisée → vraie activité → résultat/carnet selon permissions → Moniteur → adaptation proposée. Tester aussi une activité libre ensuite rattachée au programme.

## Jalons visuels obligatoires

### V01 — proposition à montrer

Montrer l’entrée propre à cet objectif et l’option sociale ; chaque écran nouveau s’arrête avant le suivant.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V02 — proposition à montrer

Montrer la première composition et ses paramètres spécifiques ; refus, modification et alternative.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V03 — proposition à montrer

Montrer l’aperçu de temps puis le Dashboard résultant ; valider séparément toute nouvelle disposition.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V04 — proposition à montrer

Montrer une exécution concrète avec pause/correction et résultat effectivement sauvegardé.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

### V05 — proposition à montrer

Montrer carnet/résultats autorisés puis bilan/adaptation, sans exposer le journal privé.

**STOP : attendre la validation explicite de Jeezs pour cet écran et cette version avant intégration ou écran suivant.** Si ce jalon mentionne plusieurs surfaces, les traiter une à une en sous-jalons.

## Tests techniques à mener par Codex

- Machine triceps personnelle, 5×5 de test, correction de série et reprise : historique complet.
- Partager une séance avec OBJ-09 : occurrence et budget comptés une seule fois ; refus des compléments respecté.
- Scénario complet testé par Codex sur données fictives ; aucun conseil de santé non revu activé comme prescription.
- Jeu Effort minimum puis ambitieux ; temps zéro/limité ; refus d’une brique ; même occurrence multi-objectifs ; reprise sans perte.
- Tester la prévisualisation puis l’intégration approuvée ; joindre commandes, résultats et environnement réels. L’utilisateur ne remplace pas ces tests techniques.
- Pour chaque nouveau parcours : vérifier la commande réelle, l’état résultant et la persistance, pas seulement une capture.
- Distinguer RÉUSSI, ÉCHEC, BLOQUÉ et NON_TESTÉ. L’absence d’appareil, de secret, de service ou de capteur n’est jamais un succès.

## Intégration et recette

Préparer la proposition dans un environnement isolé et réversible avec les composants réels. Après chaque accord visuel, intégrer **uniquement la version approuvée** et tester les régressions. Présenter toute différence apparue après intégration pour une nouvelle validation. Une fois la tâche entière intégrée et les tests techniques terminés, laisser **Jeezs faire sa recette fonctionnelle**. Ne pas fermer cette tâche ou démarrer la suivante sans acceptation explicite.

## Preuves et exclusions

Remplir [le gabarit de preuves](../../validation/Gabarit_preuves.md) pour chaque jalon, puis [le suivi des tâches](../../pilotage/Suivi_taches.md). Aucun champ d’approbation humaine prérempli.

Ne pas recopier les briques communes ni inventer les composants manquants. Toute valeur physiologique ou thérapeutique reste soumise à la politique éditoriale ; les exemples chiffrés du cahier ne sont pas des prescriptions.

**Contraintes invariantes :** JavaScript et architecture réelle du projet ; pas de TypeScript sans demande ; pas d’API ou connexion MCP supposée ; pas de duplication des modules ; carrés matriciels et réglages natifs ; aucune « validation médicale » produite par un simple test logiciel.
