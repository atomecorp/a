> Extrait de la source archivée, lignes 1–2. Lire les décisions actuelles 52–55 en priorité. Les repères cliniques hérités demandent une revue avant activation.

# atome / eVe — Cahier des charges du système d’objectifs et scénarios pré-câblés
