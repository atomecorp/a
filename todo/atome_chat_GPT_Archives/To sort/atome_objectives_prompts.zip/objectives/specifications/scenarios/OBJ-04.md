# OBJ-04 — Gérer une douleur

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P058.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.10. OBJ-04 — Gérer une douleur

**Matrice** : `Douleur → Type / Localisation / Évolution → Précautions → Effort → Temps → [Journal / Mouvement adapté / Relaxation / Professionnel] → Activité → Suivi`.

**Entrée** : localisation, apparition/évolution, retentissement fonctionnel, ce qui aggrave/soulage selon le ressenti, antécédents suivis par un médecin. Évaluer d'abord si la douleur est **nouvelle, intense, inhabituelle ou associée à des signes alarmants** (traumatisme majeur, déficit neurologique brutal, douleur thoracique, etc.) ; déclencher orientation urgente **sans diagnostic** au lieu d'afficher des étirements. Une douleur persistante ou inexpliquée nécessite une évaluation. Ne pas prendre une valeur de douleur `6/10` comme indication automatique à faire plus ou moins de sport.

**Briques envisagées** : `BR-SUI-02` journal de douleur, `BR-SUI-03` consultation/kiné selon situation, `BR-ACT-07` mouvement doux **si approprié**, `BR-ACT-01` marche adaptée, `BR-MEN-02` relaxation, `BR-SOM-01` observation du sommeil si impact, `BR-SUI-05` compte rendu thérapeutique. Pour douleur chronique primaire, les recommandations peuvent comprendre exercice supervisé et approches psychologiques [S09]. Aucun antalgique ni supplément n'est automatiquement conseillé.

**Programme** : un débutant peut seulement consigner son retentissement et préparer un rendez-vous ; une personne déjà suivie peut reprendre **la séquence prescrite** (ex. mouvements de kiné, amplitude autorisée, répétitions indiquées). Chaque exercice doit conserver `autorisé par`, `date`, `restrictions` et `arrêter si...` lorsque cela vient d'un professionnel.

**Exécution** : rappel du soin ou de l'exercice validé, séance ouverte avec positions et répétitions **approuvées** ; un appui passe à l'étape suivante et enregistre l'exécution. Toute aggravation inhabituelle entraîne proposition de suspendre et de contacter le professionnel. **Bilan : fonction vécue et activités réalisables**, pas seulement suppression complète de douleur. Ne pas interpréter une simple corrélation « sport → douleur » comme un diagnostic causal.
