# OBJ-05 — Repérer un trouble et être orienté

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P059.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.11. OBJ-05 — Repérer un trouble et orienter vers le bon professionnel

**Matrice** : `Comprendre ce qui m'arrive → Ce que j'observe → Depuis quand / Retentissement → [Urgence ? / Journal / Consultation / Résultats] → Planifier → Préparer → Suivre`.

**Départ** : recueil **facultatif et limité** des symptômes, début, évolution, facteurs contextuels, traitements déclarés et documents existants. En cas de détresse aiguë, douleur thoracique, difficulté respiratoire sévère, déficit neurologique soudain, confusion aiguë ou autre signe alarmant, **recommander les services d'urgence** plutôt que lancer un parcours d'auto-observation. La liste complète des urgences doit être validée par un professionnel ; les symptômes typés ne suffisent pas à établir un diagnostic.

**Briques** : `BR-SUI-01` observations structurées, `BR-SUI-05` résultats (PDF/image/texte/valeurs) et provenance, `BR-SUI-03` prise de rendez-vous, `BR-SUI-10` orientation/contextualisation, `BR-VIE-03` note privée si demandée, `BR-SUI-09` évolution. L'outil n'ordonne **aucun bilan sanguin ni examen d'imagerie** de sa propre initiative ; il peut préparer une liste de questions pour le médecin et stocker les examens recommandés par celui-ci.

**Programme exemple** : `Observation → Type / Intensité ressentie / Fréquence / Date → Enregistrer` (sans inventer de valeur normale) ; `Rendez-vous → Professionnel → Date/lieu confirmés par l'utilisateur → Rappel` ; `Résultat reçu → Importer le compte rendu original → Valider extraction facultative → Lier au rendez-vous`. L'utilisateur peut partager **une sélection** de données avec le professionnel après accord, pas tout le journal personnel.

**Bilan** : suivi des consultations et de la symptomatologie ; `avis médical reçu`, `examen demandé`, `examen planifié`, `résultat reçu` et `interprétation du médecin` sont **cinq états distincts**. L'IA n'attribue jamais une maladie à un indicateur isolé. La périodicité des bilans est décidée selon le risque et les recommandations, non « tous les mois » par défaut.
