# OBJ-08 — Tenir un journal personnel

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P062.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.14. OBJ-08 — Tenir un journal personnel

**Matrice** : `Journal → [Écrire / Dicter / Photo / Dessiner / Humeur / Bilan libre] → Fréquence souhaitée → Confidentialité → Commencer`.

**Départ** : demander si le journal vise mémoire, expression artistique, gratitude, réflexion ou événements de santé, et **quel contenu la personne accepte de partager avec le Moniteur**. **Par défaut : journal intégralement privé**, pas de lecture automatique par l'IA ni d'exploitation à des fins de performance. Une note intime ne devient pas une observation de santé par défaut.

**Briques** : `BR-VIE-03` note/son/image/dessin natif, `BR-MEN-05` humeur si choisie, `BR-VIE-02` création, `BR-SYS-07` archive/export, `BR-SYS-08` consentement sélectif. Réutiliser les véritables outils Texte, Audio, Photo, Dessin et leurs formats d'atome quand vérifiés, plutôt qu'une imitation de prise de notes.

**Programme** : effort 1 → page libre **1–2 fois par semaine** ; effort 2 → **2–5 min** par session choisie ; effort supérieur → pages thématiques et bilans rétrospectifs, sans « streak » culpabilisant. `Journal → Nouvelle note → Texte / Audio / Dessin → Enregistrer` ; possibilité de trier sans exiger une nomenclature.

**Exécution / résultat** : ouverture au premier plan de l'outil natif à l'heure choisie ou à la demande ; sauvegarde datée avec modification, suppression et export contrôlés. **Bilan** facultatif : fréquence, utilité ressentie, thématiques **uniquement si l'utilisateur demande une analyse et désigne les notes concernées**. Éviter de transformer automatiquement une mention négative en diagnostic.
