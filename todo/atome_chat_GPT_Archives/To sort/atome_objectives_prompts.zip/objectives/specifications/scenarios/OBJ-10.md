# OBJ-10 — Rajeunissement / vieillir en bonne santé

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P064.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.16. OBJ-10 — Rajeunissement / vieillir en bonne santé

**Définition honnête :** l'objectif couvre **(a) préserver l'autonomie et les capacités** et **(b) prendre soin de l'apparence**, selon le souhait de l'utilisateur. Il **n'annonce pas une inversion du vieillissement humain**. L'âge biologique estimé par un test commercial, s'il est importé, est une **estimation dépendante de la méthode**, non un résultat de rajeunissement validé.

**Matrice** : `Rajeunissement → [Capacités / Peau et apparence / Prévention / Cognition / Liens sociaux] → Effort → Temps → Briques choisies → Activités / Rendez-vous → Suivi`.

**Départ** : choisir si la priorité est **forme, mobilité, aspect cutané, prévention ou autonomie** ; demander les habitudes et limites uniquement pour les briques choisies. En cas de demande d'acte esthétique médical, proposer un **rendez-vous dermatologique / médical**, non une procédure automatisée.

**Briques de première intention soutenues** :

- **Capacités** : `BR-ACT-03/02/09/11` force, endurance, équilibre et récupération individualisés ; `BR-AGE-02` fonction au quotidien. **Critère : conserver ou améliorer une fonction**, pas revenir fictivement à l'âge X.
- **Nutrition / sommeil** : `BR-NUT-03/04/05`, `BR-SOM-02` si un besoin réel existe ; repères du 51.5 sans diète « rajeunissante » unique.
- **Peau/apparence** : `BR-AGE-03 → Photoprotection → SPF 30+ large spectre / habitudes d'exposition → Rappel si souhaité`. Dermatologue si maladie de peau, tache évolutive, traitement demandé. Un traitement topique actif (ex. rétinoïde) n'est **pas programmé par l'IA** ; ses contre-indications nécessitent vérification.
- **Prévention / autonomie** : `BR-AGE-01/05/06` bilans de prévention et soins bucco-dentaires *selon âge, facteurs de risque, antécédents et professionnel*, dépistages recommandés, activité cognitive plaisante `BR-AGE-04`, liens sociaux `BR-VIE-04`.

**Briques explicitement non recommandées par défaut** : prétendus « anti-âge » garantis, **NMN/NAD boosters, resvératrol, fisétine, sénolytiques, peptides, hormone de croissance, rapamycine hors indication, protocole de « détox »**. Si l'utilisateur veut seulement **documenter** un produit déjà utilisé, `BR-SUI-08` conserve sa déclaration et sa source ; l'interface le marque `preuve clinique insuffisante / expérimental` quand c'est le cas et peut orienter vers un professionnel pour interactions/sécurité. L'application ne convertit pas ces intérêts en prescription ni en score de gain d'années.

**Exemple de programme** : effort 2 → une sortie/marche adaptée, deux sessions de force convenables **si déjà autorisées**, protection solaire choisie lors des expositions ; temps additionné et respecté. `Prévention → Rendez-vous selon indication → Agenda`, puis `Résultats → Import original → Historique`. Le suivi est sur plusieurs mois, avec mesures comparables et conséquences fonctionnelles/subjectives distinctes.

**Indicateurs possibles** : force/fonction, équilibre, activité et confort de peau rapporté, habitudes UV et rendez-vous, mais **pas de promesse de « peau rajeunie de 10 ans »**. Références OMS vieillissement en bonne santé [S14] et AAD photoprotection [S13].
