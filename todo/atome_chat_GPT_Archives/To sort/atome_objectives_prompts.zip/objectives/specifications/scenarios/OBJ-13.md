# OBJ-13 — Esthétique — visage, corps et peau

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P067.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

# 52. Objectif Esthétique — treizième objectif de santé et de bien-être

**Décision utilisateur consolidée le 12 octobre 2026. Statut : exigence à réaliser, pas fonctionnalité déjà livrée.**

Ajouter **OBJ-13 — Esthétique : visage, corps, peau et soins** aux douze objectifs précédents. Conserver tous leurs identifiants ; ne remplacer ni Rajeunissement / vieillir en bonne santé, ni Bien-être, ni Santé mentale. La matrice d’entrée contient désormais treize objectifs de cette famille, plus l’accès à un objectif libre. Le catalogue général hors santé reste conservé.

## 52.1. But et briques

L’utilisateur exprime lui-même la zone et l’amélioration souhaitée. Le système n’invente pas un défaut, une maladie de peau, un idéal physique ou une note d’attractivité. **Visage**, **Corps** et **Peau** sont des chemins d’exploration qui peuvent renvoyer à une même zone et un même soin ; ils ne créent pas des dossiers concurrents.

| Identifiant de spécification | Fonction composée | Outils et données à réutiliser après audit |
| --- | --- | --- |
| BR-EST-01 | Zone et demande esthétique | Sélection matricielle, préférences, zone corporelle déclarée. |
| BR-EST-02 | Routine et produits de soin déclarés | Outils de paramètres, activité récurrente, catalogue extensible et saisie libre. |
| BR-EST-03 | Tolérance et observations de peau | Observations datées, résultat qualitatif, source ; aucun diagnostic. |
| BR-EST-04 | Photos de suivi privées | Photo/média, original, date et permissions ; comparaisons consenties. |
| BR-EST-05 | Consultation et suivi de soin | Contacts, agenda, document professionnel, carnet de santé et Résultats. |
| BR-EST-06 | Catalogue de soins extensible | Types de soins et paramètres réellement documentés, variantes, références. |

**Photoprotection : réutiliser BR-AGE-03**, déjà définie, plutôt que créer une brique redondante. Un traitement prescrit reste une donnée de BR-SUI-07 avec son document ; le scénario Esthétique ne le transforme pas en conseil automatisé.

## 52.2. Scénario complet

1. **Choisir Esthétique**, puis proposer la mise en relation facultative décrite en section 53. Un refus n’empêche aucune routine personnelle.
2. **Préciser la demande** : visage, corps ou peau ; confort, soin courant, aspect souhaité, suivi d’un soin déjà effectué ou consultation d’information. Demander seulement contexte/contraintes utiles : routine actuelle, réaction connue ou consigne d’un professionnel.
3. **Régler Effort et Temps** avec les mêmes carrés extensibles. L’engagement ne mesure ni la sévérité cutanée ni la tolérance à un acte médical. Une préférence « plus vite » ne déclenche pas un traitement plus agressif.
4. **Proposer peu de briques** : routine choisie, photoprotection lorsque pertinente, observation de tolérance, consultation ou suivi de consignes existantes. Nutrition, compléments et photos restent facultatifs ; aucune cure de beauté imposée.
5. **Configurer par matrices** : `Zone → Brique → Soin/produit connu → Paramètres utiles → Aperçu`. Un carré portant une valeur s’étend sur deux ou trois unités puis se referme. Quantité, fréquence et durée proviennent d’une déclaration, d’une notice pertinente ou d’une consigne professionnelle vérifiée ; sinon ne pas les inventer.
6. **Valider chaque brique**, puis l’ensemble et son budget. Une routine de test « deux minutes, trois jours choisis » illustre le calendrier, pas une prescription de soin.
7. **Planifier et exécuter** dans le calendrier et l’outil d’activité communs : rappel, ouverture autorisée, soin déclaré effectué, pause/report/correction. Un rappel n’atteste pas la réalisation.
8. **Conserver les résultats** : confort/tolérance déclarés, documents du praticien, dates et photos consenties. Réutiliser le carnet pour les documents de santé et le Moniteur seulement sur données autorisées.
9. **Faire un bilan** sur ce qui a été réalisé, la tolérance et la satisfaction personnelle, sans promettre un résultat esthétique ou un âge gagné. L’amélioration perçue et une observation instrumentée restent distinctes.
10. **Adapter après accord** : simplifier, suspendre un produit gênant, reprendre les consignes du professionnel ou proposer une consultation. Ne pas inventer un protocole de traitement.

## 52.3. Photos et comparaison

La photo est optionnelle, jamais obligatoire pour entrer dans cet objectif. Conserver original, date, zone déclarée et conditions de prise si connues. Proposer une prise comparable en cadrage, éclairage et distance, sans retouche ni filtre sur les images de suivi. Tout changement d’image dérivée conserve l’original et sa provenance. Aucune reconnaissance médicale, notation de beauté, inférence de défauts ou publication avant/après implicite.

Les photographies du corps restent privées et n’alimentent pas la recherche de personnes partageant l’objectif. Partage avec un professionnel : sélection explicite, aperçu et confirmation du destinataire. Une copie déjà transmise ne peut pas être réputée effacée par la simple révocation d’un lien.

## 52.4. Soins courants et actes professionnels

Séparer les routines de confort, l’information sur une technique, la consultation, un acte professionnel effectivement prescrit/réalisé et les consignes de suivi documentées. Un choix dans le catalogue n’est ni une indication médicale, ni un consentement opératoire, ni une réservation.

**Exigence de sécurité produit :** ne pas fournir dans ces écrans des dosages injectables, réglages de laser, profondeurs d’aiguille ou procédures invasives à exécuter soi-même. Les conseils et orientations cliniques nécessitent une revue compétente. Les pratiques d’injection/perforation comportent des risques et sont encadrées : référence institutionnelle [N03]. La photoprotection dispose d’une information de référence publique [N04], mais ses modalités personnelles ne sont pas décidées par le curseur Effort.

## 52.5. Tests spécifiques

Créer le parcours Esthétique sans photos ni compléments ; refuser le réseau ; accepter une seule routine ; planifier, déclarer puis corriger une réalisation ; importer un compte rendu ; rattacher la même photoprotection à OBJ-10 et OBJ-13 sans doublon. Vérifier séparément absence de dose d’acte médical automatique, confidentialité des images et capacité à retirer une autorisation.
