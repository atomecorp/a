# OBJ-12 — Prendre soin de sa santé mentale

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P066.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.18. OBJ-12 — Prendre soin de sa santé mentale

**Matrice** : `Santé mentale → Mon besoin [Stress / Humeur / Anxiété ressentie / Isolement / Difficulté persistante / Je cherche de l'aide] → Besoin urgent ? → Effort → Temps → [Soutien / Routine / Journal sélectif / Activité agréable / Professionnel] → Planifier`.

**Point de départ essentiel :** l'application pose seulement les questions indispensables pour distinguer **soutien de bien-être ordinaire** et **nécessité d'aide clinique**. Elle permet de dire `je préfère ne pas répondre`. Ne jamais inférer dépression, bipolarité, trouble anxieux ou risque suicidaire à partir d'un score de montre, d'une habitude ou d'un texte intime. Si elle propose un questionnaire de dépistage reconnu, le présenter comme **dépistage facultatif**, avec limites, interprétation professionnelle et consentement ; **un score ne décide pas seul d'une orientation ou d'un niveau de risque** [S16].

**Sécurité prioritaire** : détresse aiguë, danger immédiat ou intention de se faire du mal → **afficher des possibilités de contact humain/urgence adaptées à la localisation**, accessibles et discrètes, sans demander d'attendre le prochain rappel. En France : **15 / 112** en cas de danger immédiat ; le **3114** est une ressource de prévention du suicide à vérifier au moment de l'implémentation. Le système n'essaie ni de gérer une crise grave par méditation, ni de prédire les comportements individuels.

**Briques au choix** : `BR-MEN-07` rendez-vous avec médecin/psychologue/structure d'aide ; `BR-MEN-06` micro-actions/plaisirs/activation comportementale si appropriées ; `BR-VIE-04` soutien d'un proche **sur initiative explicite** ; `BR-SOM-01` sommeil si lien vécu ; `BR-ACT-01` mouvement accessible si souhaité ; `BR-MEN-02/03` détente facultative ; `BR-MEN-05` notes d'humeur **volontaires** ; `BR-MEN-08` plan de sécurité dans le cadre adapté. **Aucune modification de traitement, arrêt de psychotrope ou supplément psychotrope par l'IA**.

**Programme** : effort 1 = prendre rendez-vous ou choisir **une seule action de soutien très accessible** ; effort 2 = contact/soutien + routine légère ; effort 3–5 = activités supplémentaires **sur demande**, sans remplacer un traitement nécessaire par « davantage d'effort ». L'IA ne dit jamais qu'une personne va mieux parce qu'elle a validé des cases. Les rendez-vous, tâches prescrites par le praticien et observations déclarées sont datés séparément.

**Exécution** : lien vers contact/rendez-vous, activité choisie, bouton `arrêter/passer`, accès rapide à l'aide. **Résultats** : ressenti volontaire, retentissement au quotidien, accès aux soins, préférence pour ajuster, avec confidentialité renforcée (pas de notification révélant un diagnostic ni analyse automatique d'un journal privé). Évaluation et traitements relèvent des professionnels ; NICE NG222 et OMS [S11, S12].
