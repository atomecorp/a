# OBJ-06 — Préserver du temps pour soi

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P060.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.12. OBJ-06 — Préserver du temps pour soi

**Matrice** : `Temps pour soi → Sources d'encombrement → Effort → Budget de temps → [Repos / Activité plaisante / Limites / Organisation] → Créneau → Valider`.

**Départ** : demander à quels moments la personne souhaite être disponible ou indisponible ; ne pas supposer des problèmes psychologiques. Option pour repérer des engagements non déplaçables, aidance familiale, travail, contraintes de transport.

**Briques** : `BR-VIE-01` espace personnel ; `BR-VIE-02` loisir/création ; `BR-VIE-05` limites à poser ; `BR-VIE-06` simplifier une routine ; `BR-MEN-04` pause facultative ; `BR-VIE-04` relation choisie. Exemples UI : **5, 10, 15, 30 ou 60 min**, valeurs librement ajustables.

**Parcours** : effort 1 → un créneau de **5–10 min, une fois dans la semaine** ; effort 2 → quelques courtes pauses ; effort 3+ → créneaux structurés avec choix d'activités, sans surestimer du temps disponible. `Activité → Musique / Lecture / Promenade / Ne rien faire / Autre` ouvre la matrice native correspondante. `Ne rien faire` est une **activité valide**, pas une omission fautive.

**Agenda/exécution** : proposition de réservation douce et révocable, rappel facultatif ; si le temps est réaffecté, l'app demande si la personne préfère reporter, jamais considérer cela comme un échec. **Résultat** : satisfaction, temps réellement protégé, ressenti de contrôle, contraintes découvertes ; la synthèse reste privée, sans mesure clinique imposée.
