# OBJ-11 — Améliorer son bien-être

**Statut : scénario à intégrer par assemblage, non implémenté dans ce paquet.** Prompt associé : P065.

## Socle obligatoire commun à ce scénario

Choisir l’objectif → proposition sociale facultative (Oui / Non / Plus tard) → état de départ minimal et autorisé → Effort → Temps → briques acceptées une à une → aperçu de charge → calendrier/Dashboard → outil réel d’activité → résultats et carnet selon permissions → Moniteur → adaptation consentie.

Le carnet est transversal et indépendant ; aucune lecture de tout le dossier, analyse du journal ou publication dans le réseau n’est automatique. En situation urgente, l’accès humain approprié passe avant les étapes facultatives.

Les valeurs de la source sont classées selon `../../pilotage/Politique_des_valeurs.md`. Chaque nouvel écran de ce parcours s’arrête pour validation de Jeezs, même si d’autres écrans du socle ont déjà été validés.

## Scénario détaillé de référence

## 51.17. OBJ-11 — Améliorer son bien-être

**Matrice** : `Bien-être → Ce qui manque [Repos / Plaisir / Social / Énergie / Mouvement / Temps libre] → Effort → Temps → Choix de 2–3 briques → Calendrier`.

**Départ** : question libre `Qu'est-ce qui rendrait vos journées meilleures ?` ; option `Bien-être ressenti aujourd'hui 0–10` clairement **subjective**, sans se substituer à une échelle clinique. Éviter de médicaliser automatiquement solitude, fatigue ordinaire ou baisse de motivation.

**Briques** : `BR-VIE-01` temps personnel, `BR-VIE-02` activité plaisante, `BR-VIE-04` lien social choisi, `BR-ACT-01/12` mouvement, `BR-SOM-02` rythme si besoin, `BR-MEN-04` pauses, `BR-NUT-03` cuisine plaisir/qualité, `BR-MEN-05` notes subjectives. L'utilisateur peut sélectionner **une activité sociale, créative, corporelle ou contemplative**, sans plan stéréotypé.

**Programme** : palier 1 = **une activité appréciée** et facile ; paliers 2–3 = une activité et un créneau de récupération ; paliers 4–5 = un programme varié mais compatible avec les autres projets. `Social → Appeler un ami / Partager un moment / Autre → Quand` : ne jamais contacter un tiers sans acte explicite. `Création → Musique / Vidéo / Graphisme → Outil natif`.

**Bilan** : utilité ressentie, satisfaction et désir de poursuivre ; le Moniteur peut rapprocher le bien-être et les autres objectifs avec accord, sans affirmer l'effet de chaque brique. Si tristesse, anxiété ou altération fonctionnelle persistantes, proposer un accompagnement adapté et `OBJ-12`, pas augmenter le nombre de loisirs comme traitement automatique. Les relations sociales font partie du bien-être global [S15].
